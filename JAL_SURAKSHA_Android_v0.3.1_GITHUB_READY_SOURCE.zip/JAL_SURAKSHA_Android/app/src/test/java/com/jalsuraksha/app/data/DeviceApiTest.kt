package com.jalsuraksha.app.data

import kotlinx.coroutines.runBlocking
import okhttp3.OkHttpClient
import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class DeviceApiTest {
    private lateinit var server: MockWebServer
    private val api = DeviceApi(client = OkHttpClient(), hostPolicy = { true })

    @Before fun setUp() { server = MockWebServer(); server.start() }
    @After fun tearDown() { server.shutdown() }

    private fun endpoint(token: String? = null, basicAuth: BasicAuthCredentials? = null) = Endpoint(
        server.hostName, server.port,
        credentials = token?.let { DeviceCredentials(it) },
        basicAuth = basicAuth,
    )
    private fun statusBody() = """{"fa":1.5,"fb":1.2,"diff":0.3,"state":"NORMAL","pump":false,"tokOk":true,"relayOk":true}"""

    @Test fun fetchStatusUsesFirmwareStatusRouteWithoutBasicAuth() {
        server.enqueue(MockResponse().setBody(statusBody()))
        val result = runBlocking { api.fetchStatus(endpoint("secret-token-123")) }
        assertTrue("was $result", result is ApiOutcome.Success)
        val request = server.takeRequest()
        assertEquals("GET", request.method)
        assertEquals("/api/status", request.path)
        assertNull(request.getHeader("Authorization"))
    }

    @Test fun statusCanBeReadWithoutControlToken() {
        server.enqueue(MockResponse().setBody(statusBody()))
        val result = runBlocking { api.fetchStatus(endpoint()) }
        assertTrue(result is ApiOutcome.Success)
    }

    @Test fun unauthorizedStatusIsReportedAsBasicAuthRequired() {
        server.enqueue(MockResponse().setResponseCode(401).setBody("no"))
        val result = runBlocking { api.fetchStatus(endpoint()) }
        assertTrue(result is ApiOutcome.Failure && (result as ApiOutcome.Failure).error is ApiError.BasicAuthRequired)
    }

    @Test fun basicAuthCredentialsAreSentAsAuthorizationHeader() {
        server.enqueue(MockResponse().setBody(statusBody()))
        val creds = BasicAuthCredentials("device-user", "private-password")
        val result = runBlocking { api.fetchStatus(endpoint(basicAuth = creds)) }
        assertTrue(result is ApiOutcome.Success)
        val request = server.takeRequest()
        assertEquals(okhttp3.Credentials.basic("device-user", "private-password"), request.getHeader("Authorization"))
        assertTrue(!creds.toString().contains("private-password"))
    }

    @Test fun serverErrorMapsToHttpError() {
        server.enqueue(MockResponse().setResponseCode(500).setBody("boom"))
        val result = runBlocking { api.fetchStatus(endpoint()) }
        assertTrue(result is ApiOutcome.Failure)
        val error = (result as ApiOutcome.Failure).error
        assertTrue(error is ApiError.HttpError && error.code == 500)
    }

    @Test fun garbageBodyMapsToBadResponse() {
        server.enqueue(MockResponse().setBody("<html>not the device</html>"))
        val result = runBlocking { api.fetchStatus(endpoint()) }
        assertTrue(result is ApiOutcome.Failure && (result as ApiOutcome.Failure).error is ApiError.BadResponse)
    }

    @Test fun startCommandPostsTokenAndCommandAsFormFields() {
        server.enqueue(MockResponse().setBody("""{"ok":true,"msg":"START accepted: pump settling"}"""))
        val result = runBlocking { api.sendCommand(endpoint("secret-token-123"), "start") }
        assertTrue(result is ApiOutcome.Success)
        val request = server.takeRequest()
        assertEquals("POST", request.method)
        assertEquals("/api/cmd", request.path)
        assertTrue(request.getHeader("Content-Type")!!.startsWith("application/x-www-form-urlencoded"))
        val body = request.body.readUtf8()
        assertTrue(body.contains("t=secret-token-123"))
        assertTrue(body.contains("c=start"))
        assertNull(request.getHeader("Authorization"))
    }

    @Test fun commandWithoutTokenIsBlockedBeforeNetworkRequest() {
        val result = runBlocking { api.sendCommand(endpoint(), "start") }
        assertTrue(result is ApiOutcome.Failure && (result as ApiOutcome.Failure).error is ApiError.FirmwareControlLocked)
        assertEquals(0, server.requestCount)
    }

    @Test fun http200WithOkFalseIsTreatedAsFirmwareRejection() {
        server.enqueue(MockResponse().setBody("""{"ok":false,"msg":"Relay polarity not verified"}"""))
        val result = runBlocking { api.sendCommand(endpoint("secret-token-123"), "start") }
        assertTrue(result is ApiOutcome.Failure)
        val error = (result as ApiOutcome.Failure).error
        assertTrue(error is ApiError.BadResponse && error.reason.contains("Relay polarity not verified"))
    }

    @Test fun tokenUnauthorizedMapsToAuthRequired() {
        server.enqueue(MockResponse().setResponseCode(401).setBody("""{"ok":false,"msg":"Wrong password"}"""))
        val result = runBlocking { api.sendCommand(endpoint("wrong-token-123"), "start") }
        assertTrue(result is ApiOutcome.Failure && (result as ApiOutcome.Failure).error is ApiError.AuthRequired)
    }

    @Test fun fetchEventsUsesFirmwareEventsRoute() {
        server.enqueue(MockResponse().setBody("""[{"t":1731400000,"u":12,"c":4,"m":"Leak detected"}]"""))
        val result = runBlocking { api.fetchEvents(endpoint()) }
        assertTrue(result is ApiOutcome.Success)
        val req = server.takeRequest()
        assertEquals("GET", req.method)
        assertEquals("/api/events", req.path)
        assertEquals("Leak detected", (result as ApiOutcome.Success).value.single().message)
    }

    @Test fun publicHostsAreRefusedBeforeRequest() {
        val strict = DeviceApi(client = OkHttpClient())
        val ep = Endpoint("8.8.8.8", 80)
        val result = runBlocking { strict.fetchStatus(ep) }
        assertTrue(result is ApiOutcome.Failure && (result as ApiOutcome.Failure).error is ApiError.InvalidEndpoint)
        assertEquals(0, server.requestCount)
    }

    @Test fun commandDoesNotSendDisallowedFormParameters() {
        server.enqueue(MockResponse().setBody("""{"ok":true,"msg":"Done"}"""))
        val result = runBlocking {
            api.sendCommand(endpoint("secret-token-123"), "set", mapOf("kA" to "455.0", "unknown" to "inject"))
        }
        assertTrue(result is ApiOutcome.Success)
        val body = server.takeRequest().body.readUtf8()
        assertTrue(body.contains("kA=455.0"))
        assertTrue(!body.contains("unknown"))
        assertTrue(!body.contains("inject"))
    }

    @Test fun commandNotFoundIsReportedAsHttp400() {
        server.enqueue(MockResponse().setResponseCode(400).setBody("Unknown command"))
        val result = runBlocking { api.sendCommand(endpoint("secret-token-123"), "invalid") }
        assertTrue(result is ApiOutcome.Failure && (result as ApiOutcome.Failure).error is ApiError.HttpError)
    }

    @Test fun controlTokenNeverAppearsInToString() {
        val creds = DeviceCredentials("secret-token-123")
        assertTrue(!creds.toString().contains("secret-token-123"))
        assertTrue(!endpoint("secret-token-123").toString().contains("secret-token-123"))
    }
}
