package com.jalsuraksha.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class StatusParserTest {
    private fun body(extra: String = "") = """{"fa":1.5,"fb":1.2,"diff":0.3,"pct":20.0,"ra":12.0,"rb":10.0,"va":12.5,"vb":11.9,"pa":500,"pb":480,"cpa":50,"cpb":48,"state":"NORMAL","sev":0,"latch":"none","loc":"Between A & B","pump":false,"muted":false,"cal":true,"bl":false,"sens":"OK","wifi":"CONNECTED","rssi":-61,"ip":"192.168.1.50","cloud":"OFF","up":120,"note":"Ready","stop":"","tokOk":true,"apDef":false,"relayOk":true,"ev":13,"cfg":{"kA":450.0,"kB":440.0,"win":2000,"zero":0.05,"abs":0.2,"rel":10.0,"pers":3,"base":0.0}$extra}"""

    private fun ok(json: String): DeviceStatus {
        val r = StatusParser.parse(json, 1_000L)
        assertTrue("expected Ok but was $r", r is ParseResult.Ok)
        return (r as ParseResult.Ok).status
    }

    private fun invalid(json: String): String {
        val r = StatusParser.parse(json, 1_000L)
        assertTrue("expected Invalid but was $r", r is ParseResult.Invalid)
        return (r as ParseResult.Invalid).reason
    }


    @Test fun parsesLegacyV2StatusAsReadOnlyAndKeepsFirmwareLock() {
        val legacy = """{"wifi":"Connected","ip":"10.136.231.207","rssi":-36,"pump":false,"pumpAvailable":false,"flowLpm":0,"totalLiters":0}"""
        val status = ok(legacy)
        assertEquals(2, status.apiVersion)
        assertEquals("Connected", status.wifi)
        assertEquals("10.136.231.207", status.ip)
        assertEquals(-36, status.rssiDbm)
        assertEquals(PumpState.OFF, status.pump)
        assertEquals(FirmwarePumpPermission.LOCKED, status.pumpPermission)
        assertEquals(0.0, status.flowLpm!!, 0.0)
        assertEquals(0.0, status.totalLiters!!, 0.0)
        assertNull(status.flowBLpm)
        assertTrue(status.warnings.any { it.contains("read-only", ignoreCase = true) || it.contains("Pump commands remain disabled") })
    }

    @Test fun legacyV2PumpAvailableTrueDoesNotGrantControlPermission() {
        val legacy = """{"wifi":"Connected","ip":"10.136.231.207","rssi":-36,"pump":false,"pumpAvailable":true,"flowLpm":1.25,"totalLiters":4.5}"""
        val status = ok(legacy)
        assertEquals(2, status.apiVersion)
        assertEquals(FirmwarePumpPermission.UNKNOWN, status.pumpPermission)
    }

    @Test fun malformedLegacyV2PayloadIsRejected() {
        val legacy = """{"wifi":"Connected","ip":"10.136.231.207","rssi":-36,"pump":false,"pumpAvailable":false,"flowLpm":"zero","totalLiters":0}"""
        val reason = invalid(legacy)
        assertTrue(reason.contains("legacy V2", ignoreCase = true))
    }

    @Test fun parsesFullDualSensorStatus() {
        val s = ok(body())
        assertEquals(1.5, s.flowALpm!!, 1e-9)
        assertEquals(1.2, s.flowBLpm!!, 1e-9)
        assertEquals(0.3, s.differenceLpm!!, 1e-9)
        assertEquals(20.0, s.differencePercent!!, 1e-9)
        assertEquals(12.5, s.volumeALiters!!, 1e-9)
        assertEquals(11.9, s.volumeBLiters!!, 1e-9)
        assertEquals(500L, s.pulsesA)
        assertEquals(48L, s.calibrationPulsesB)
        assertEquals(PumpState.OFF, s.pump)
        assertEquals(FirmwarePumpPermission.ENABLED, s.pumpPermission)
        assertEquals("NORMAL", s.systemState)
        assertEquals("192.168.1.50", s.ip)
        assertEquals(-61, s.rssiDbm)
        assertTrue(s.calibrated == true)
        assertEquals(450.0, s.firmwareConfig?.kA!!, 1e-9)
        assertTrue(s.warnings.isEmpty())
    }

    @Test fun relayNotVerifiedLocksStartPermission() {
        val s = ok(body().replace("\"relayOk\":true", "\"relayOk\":false"))
        assertEquals(FirmwarePumpPermission.LOCKED, s.pumpPermission)
        assertEquals(false, s.relayPolarityVerified)
    }

    @Test fun placeholderTokenLocksControlPermission() {
        val s = ok(body().replace("\"tokOk\":true", "\"tokOk\":false"))
        assertEquals(FirmwarePumpPermission.LOCKED, s.pumpPermission)
        assertEquals(false, s.tokenConfigured)
    }

    @Test fun unknownPermissionWhenSafetyFlagsAreMissing() {
        val s = ok(body().replace(",\"tokOk\":true,\"apDef\":false,\"relayOk\":true", ""))
        assertEquals(FirmwarePumpPermission.UNKNOWN, s.pumpPermission)
    }

    @Test fun pumpRemainsOnEvenWhenManualStartPermissionIsLocked() {
        val s = ok(body().replace("\"pump\":false", "\"pump\":true").replace("\"relayOk\":true", "\"relayOk\":false"))
        assertEquals(PumpState.ON, s.pump)
        assertEquals(FirmwarePumpPermission.LOCKED, s.pumpPermission)
        assertFalse(s.contradictoryPump)
    }

    @Test fun sensorBFlowIsNotInventedWhenNull() {
        val s = ok(body().replace("\"fb\":1.2", "\"fb\":null"))
        assertNull(s.flowBLpm)
        assertEquals(1.5, s.flowALpm!!, 1e-9)
    }

    @Test fun wrongMetricTypesAreIgnoredWithWarnings() {
        val s = ok(body().replace("\"fa\":1.5", "\"fa\":\"fast\"").replace("\"fb\":1.2", "\"fb\":true"))
        assertNull(s.flowALpm)
        assertNull(s.flowBLpm)
        assertTrue(s.warnings.size >= 2)
    }

    @Test fun negativeFlowIsIgnored() {
        val s = ok(body().replace("\"fa\":1.5", "\"fa\":-3.0"))
        assertNull(s.flowALpm)
        assertTrue(s.warnings.any { it.contains("fa") })
    }

    @Test fun pumpWithWrongTypeIsUnknown() {
        val s = ok(body().replace("\"pump\":false", "\"pump\":\"off\""))
        assertEquals(PumpState.UNKNOWN, s.pump)
    }

    @Test fun wifiAndIpWrongTypesAreIgnored() {
        val s = ok(body().replace("\"wifi\":\"CONNECTED\"", "\"wifi\":2").replace("\"ip\":\"192.168.1.50\"", "\"ip\":false"))
        assertNull(s.wifi)
        assertNull(s.ip)
    }

    @Test fun rssiOutsideRangeIsIgnored() {
        assertNull(ok(body().replace("\"rssi\":-61", "\"rssi\":12")).rssiDbm)
        assertNull(ok(body().replace("\"rssi\":-61", "\"rssi\":-300")).rssiDbm)
        assertEquals(-70, ok(body().replace("\"rssi\":-61", "\"rssi\":-70")).rssiDbm)
    }

    @Test fun invalidStatusSchemaIsRejected() {
        assertTrue(invalid("<html>login</html>").contains("not a JSON"))
        assertTrue(invalid("[1,2]").contains("not a JSON object"))
        assertTrue(invalid("{}") .contains("dual-sensor"))
    }

    @Test fun parsesFirmwareEventsArray() {
        val events = StatusParser.parseEvents("""[{"t":1731400000,"u":25,"c":4,"m":"Leak detected"},{"t":0,"u":30,"c":14,"m":"Rejected"}]""", 5_000L)
        assertEquals(2, events.size)
        assertEquals(1_731_400_000_000L, events.first().timeMs)
        assertEquals(4, events.first().code)
        assertEquals("Rejected", events.last().message)
    }

    @Test fun malformedEventsArrayThrowsReadableError() {
        try {
            StatusParser.parseEvents("{}", 0L)
            throw AssertionError("expected invalid events response")
        } catch (e: IllegalArgumentException) {
            assertTrue(e.message!!.contains("array"))
        }
    }

    @Test fun uncalibratedFirmwareDoesNotDisplayZeroFlowOrVolumeAsMeasurements() {
        val s = ok(body().replace("\"cal\":true", "\"cal\":false"))
        assertNull(s.flowALpm)
        assertNull(s.flowBLpm)
        assertNull(s.volumeALiters)
        assertNull(s.volumeBLiters)
        assertEquals(12.0, s.rateAHz!!, 1e-9)
        assertEquals(10.0, s.rateBHz!!, 1e-9)
        assertTrue(s.warnings.any { it.contains("not active") })
    }

    @Test fun acceptsNegativeFirmwareBaselineAndRecognizesPossibleLeakLatch() {
        val s = ok(body()
            .replace("\"latch\":\"none\"", "\"latch\":\"possible_leak\"")
            .replace("\"loc\":\"Between A & B\"", "\"loc\":\"Between A & B (checking)\"")
            .replace("\"base\":0.0", "\"base\":-0.35")
            .replace("\"state\":\"NORMAL\"", "\"state\":\"POSSIBLE LEAK / SENSOR B CHECK\""))
        assertEquals(-0.35, s.firmwareConfig?.baseline!!, 1e-9)
        assertTrue(s.isPossibleLeak)
        assertTrue(!s.isLeaking)

        val outOfRange = ok(body().replace("\"base\":0.0", "\"base\":5.5"))
        assertNull(outOfRange.firmwareConfig?.baseline)
        assertTrue(outOfRange.warnings.any { it.contains("-5..5") })
    }

    @Test fun keepsAliasFieldsPointingToSensorA() {
        val s = ok(body())
        assertEquals(s.flowALpm, s.flowLpm)
        assertEquals(s.volumeALiters, s.totalLiters)
    }
}
