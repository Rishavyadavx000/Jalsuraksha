package com.jalsuraksha.app.domain

import com.jalsuraksha.app.data.ApiError
import com.jalsuraksha.app.data.DeviceStatus
import com.jalsuraksha.app.data.EventType
import com.jalsuraksha.app.data.FirmwarePumpPermission
import com.jalsuraksha.app.data.PumpState
import com.jalsuraksha.app.data.Severity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AlertEngineTest {

    private val t = AlertThresholds(
        highFlowLpm = 20.0,
        noFlowGraceSec = 20,
        flowWhileOffLpm = 0.5,
        flowWhileOffGraceSec = 15,
        weakSignalDbm = -80,
        staleAfterSec = 10,
    )

    private fun status(
        pump: PumpState = PumpState.OFF,
        flow: Double? = 0.0,
        total: Double? = 0.0,
        permission: FirmwarePumpPermission = FirmwarePumpPermission.ENABLED,
        rssi: Int? = -50,
        contradictory: Boolean = false,
        calibrated: Boolean? = true,
    ) = DeviceStatus(
        wifi = null, ip = null, rssiDbm = rssi,
        pump = pump, pumpPermission = permission,
        flowLpm = flow, totalLiters = total,
        deviceId = null, apiVersion = null, receivedAtMs = 0L,
        contradictoryPump = contradictory,
        calibrated = calibrated,
    )

    private fun eventsFor(statuses: List<Pair<Long, DeviceStatus>>): List<NewEvent> {
        var st = AlertState()
        val out = mutableListOf<NewEvent>()
        for ((now, s) in statuses) {
            val step = AlertEngine.onStatus(st, s, now, t)
            st = step.state
            out += step.events
        }
        return out
    }

    @Test
    fun noFlowWhilePumpOnRaisesOneHeuristicWarningAfterTheGracePeriod() {
        val seq = (0..40 step 2).map { sec -> sec * 1000L to status(PumpState.ON, flow = 0.0) }
        val events = eventsFor(seq).filter { it.type == EventType.NO_FLOW_WHILE_ON }
        assertEquals(1, events.size)
        assertEquals(Severity.WARNING, events[0].severity)
        assertTrue(events[0].message.contains("heuristic"))
    }

    @Test
    fun noFlowIsNotRaisedBeforeTheGracePeriod() {
        val seq = (0..16 step 2).map { sec -> sec * 1000L to status(PumpState.ON, flow = 0.0) }
        assertTrue(eventsFor(seq).none { it.type == EventType.NO_FLOW_WHILE_ON })
    }

    @Test
    fun noFlowEpisodeResetsWhenFlowReturns() {
        val seq = listOf(
            0L to status(PumpState.ON, 0.0),
            10_000L to status(PumpState.ON, 3.0),
            25_000L to status(PumpState.ON, 0.0),
            40_000L to status(PumpState.ON, 0.0),
        )
        assertTrue(eventsFor(seq).none { it.type == EventType.NO_FLOW_WHILE_ON })
    }

    @Test
    fun flowWhilePumpOffRaisesOneWarning() {
        val seq = (0..40 step 5).map { sec -> sec * 1000L to status(PumpState.OFF, flow = 2.0) }
        val events = eventsFor(seq).filter { it.type == EventType.FLOW_WHILE_OFF }
        assertEquals(1, events.size)
    }

    @Test
    fun highFlowRaisesOnceThenRearmsAfterItDrops() {
        val seq = listOf(
            0L to status(PumpState.ON, 25.0),
            3_000L to status(PumpState.ON, 25.0),
            6_000L to status(PumpState.ON, 5.0),
            9_000L to status(PumpState.ON, 25.0),
        )
        assertEquals(2, eventsFor(seq).count { it.type == EventType.HIGH_FLOW })
    }

    @Test
    fun counterGoingBackwardsIsReportedAsARestart() {
        val seq = listOf(
            0L to status(total = 100.0),
            3_000L to status(total = 2.0),
        )
        assertEquals(1, eventsFor(seq).count { it.type == EventType.DEVICE_REBOOT })
    }

    @Test
    fun pumpStateChangeIsLogged() {
        val seq = listOf(
            0L to status(PumpState.OFF),
            3_000L to status(PumpState.ON, flow = 4.0),
        )
        val e = eventsFor(seq).filter { it.type == EventType.PUMP_STATE_CHANGED }
        assertEquals(1, e.size)
        assertTrue(e[0].message.contains("ON"))
    }

    @Test
    fun enablingPumpControlIsAWarningAndLockingIsInfo() {
        val seq = listOf(
            0L to status(permission = FirmwarePumpPermission.LOCKED),
            3_000L to status(permission = FirmwarePumpPermission.ENABLED),
            6_000L to status(permission = FirmwarePumpPermission.LOCKED),
        )
        val e = eventsFor(seq).filter { it.type == EventType.PUMP_LOCK_CHANGED }
        assertEquals(listOf(Severity.WARNING, Severity.INFO), e.map { it.severity })
    }

    @Test
    fun contradictoryPumpStatusIsCriticalAndRaisedOnce() {
        val seq = listOf(
            0L to status(PumpState.UNKNOWN, permission = FirmwarePumpPermission.LOCKED, contradictory = true),
            3_000L to status(PumpState.UNKNOWN, permission = FirmwarePumpPermission.LOCKED, contradictory = true),
        )
        val e = eventsFor(seq).filter { it.type == EventType.PUMP_STATUS_CONTRADICTION }
        assertEquals(1, e.size)
        assertEquals(Severity.CRITICAL, e[0].severity)
    }

    @Test
    fun missingFlowRaisesASensorWarningOnce() {
        val seq = listOf(0L to status(flow = null), 3_000L to status(flow = null))
        assertEquals(1, eventsFor(seq).count { it.type == EventType.SENSOR_UNAVAILABLE })
    }


    @Test
    fun uncalibratedZeroPlaceholdersDoNotRaiseSensorOrFlowWarnings() {
        val seq = (0..60 step 5).map { sec ->
            sec * 1000L to status(PumpState.ON, flow = null, total = null, calibrated = false)
        }
        val events = eventsFor(seq)
        assertTrue(events.none {
            it.type == EventType.SENSOR_UNAVAILABLE ||
                it.type == EventType.NO_FLOW_WHILE_ON ||
                it.type == EventType.FLOW_WHILE_OFF ||
                it.type == EventType.HIGH_FLOW
        })
    }

    @Test
    fun weakSignalIsInfoAndRaisedOnce() {
        val seq = listOf(0L to status(rssi = -85), 3_000L to status(rssi = -86))
        val e = eventsFor(seq).filter { it.type == EventType.WEAK_SIGNAL }
        assertEquals(1, e.size)
        assertEquals(Severity.INFO, e[0].severity)
    }

    @Test
    fun deviceIsOfflineAfterThreeFailuresAndRecoversWithOneEventEach() {
        var st = AlertState()
        val events = mutableListOf<NewEvent>()
        for (i in 1..4) {
            val step = AlertEngine.onFailure(st, ApiError.Timeout, i, null, i * 3_000L, t)
            st = step.state
            events += step.events
        }
        assertEquals(1, events.count { it.type == EventType.DEVICE_OFFLINE })

        val back = AlertEngine.onStatus(st, status(), 20_000L, t)
        assertEquals(1, back.events.count { it.type == EventType.DEVICE_ONLINE })

        val again = AlertEngine.onStatus(back.state, status(), 23_000L, t)
        assertTrue(again.events.none { it.type == EventType.DEVICE_ONLINE })
    }

    @Test
    fun staleDataIsReportedOnceOnceTheLastReadingIsOldEnough() {
        var st = AlertState()
        val events = mutableListOf<NewEvent>()
        for (i in 1..3) {
            val step = AlertEngine.onFailure(st, ApiError.Timeout, i, 1_000L, 1_000L + i * 6_000L, t)
            st = step.state
            events += step.events
        }
        assertEquals(1, events.count { it.type == EventType.DATA_STALE })
    }

    @Test
    fun authFailureIsRaisedOnce() {
        var st = AlertState()
        val events = mutableListOf<NewEvent>()
        for (i in 1..3) {
            val step = AlertEngine.onFailure(st, ApiError.AuthRequired, i, null, i * 3_000L, t)
            st = step.state
            events += step.events
        }
        assertEquals(1, events.count { it.type == EventType.AUTH_FAILED })
    }
}
