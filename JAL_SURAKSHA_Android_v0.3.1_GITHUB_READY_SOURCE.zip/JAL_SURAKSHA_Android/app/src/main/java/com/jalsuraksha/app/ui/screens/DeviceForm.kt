package com.jalsuraksha.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import com.jalsuraksha.app.data.AppSettings
import com.jalsuraksha.app.data.ApiContract
import com.jalsuraksha.app.data.EndpointValidator
import com.jalsuraksha.app.ui.DeviceInput
import com.jalsuraksha.app.ui.TestKind
import com.jalsuraksha.app.ui.TestUi
import com.jalsuraksha.app.ui.components.InfoBanner
import com.jalsuraksha.app.ui.components.JalButton
import com.jalsuraksha.app.ui.components.JalOutlinedButton
import com.jalsuraksha.app.ui.components.Tone
import com.jalsuraksha.app.ui.theme.JalShapes
import com.jalsuraksha.app.ui.theme.JalSpacing

@Composable
fun DeviceSetupForm(
    initial: AppSettings,
    hasPassword: Boolean,
    hasBasicAuthPassword: Boolean,
    test: TestUi,
    saveLabel: String,
    saveError: String?,
    onTest: (DeviceInput) -> Unit,
    onSave: (DeviceInput) -> Unit,
    modifier: Modifier = Modifier,
) {
    var name by rememberSaveable { mutableStateOf(initial.deviceName) }
    var address by rememberSaveable { mutableStateOf(initial.addressDisplay) }
    var controlToken by remember { mutableStateOf("") }
    var showToken by remember { mutableStateOf(false) }
    var clearToken by remember { mutableStateOf(false) }
    var basicAuthUsername by rememberSaveable { mutableStateOf(initial.username) }
    var basicAuthPassword by remember { mutableStateOf("") }
    var showBasicAuthPassword by remember { mutableStateOf(false) }
    var clearBasicAuthPassword by remember { mutableStateOf(false) }
    var advanced by rememberSaveable { mutableStateOf(false) }
    var statusPath by rememberSaveable { mutableStateOf(initial.statusPath) }
    var eventsPath by rememberSaveable { mutableStateOf(initial.eventsPath) }
    var commandPath by rememberSaveable { mutableStateOf(initial.commandPath) }

    val parsed = EndpointValidator.parse(address)
    val addressError = if (address.isNotBlank() && parsed is EndpointValidator.Result.Invalid) parsed.reason else null
    val addressOk = parsed is EndpointValidator.Result.Valid
    val pathsOk = listOf(statusPath, eventsPath, commandPath).all { EndpointValidator.isValidPath(it) }

    fun buildInput() = DeviceInput(
        name = name,
        address = address,
        controlToken = controlToken.ifEmpty { null },
        clearControlToken = clearToken,
        statusPath = statusPath,
        eventsPath = eventsPath,
        commandPath = commandPath,
        basicAuthUsername = basicAuthUsername,
        basicAuthPassword = basicAuthPassword.ifEmpty { null },
        clearBasicAuthPassword = clearBasicAuthPassword,
    )

    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(JalSpacing.md)) {
        OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            label = { Text("Device name") },
            singleLine = true,
            shape = JalShapes.field,
            modifier = Modifier.fillMaxWidth(),
            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(imeAction = ImeAction.Next),
        )
        OutlinedTextField(
            value = address,
            onValueChange = { address = it },
            label = { Text("ESP32 address") },
            placeholder = { Text("192.168.1.50") },
            singleLine = true,
            isError = addressError != null,
            supportingText = { Text(addressError ?: "Phone and ESP32 must share the same hotspot/Wi-Fi. Add :port only if not using port 80.") },
            shape = JalShapes.field,
            modifier = Modifier.fillMaxWidth(),
            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Next),
        )
        Text("Legacy V2 HTTP Basic Auth (optional)", style = MaterialTheme.typography.titleMedium)
        Text(
            "Use WEB_USER and WEB_PASSWORD from the ESP32 sketch only when /api/status returns HTTP 401. These are separate from the firmware control token. Leave both blank for the newer dual-sensor firmware.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        OutlinedTextField(
            value = basicAuthUsername,
            onValueChange = { basicAuthUsername = it; if (it.isBlank()) clearBasicAuthPassword = true else clearBasicAuthPassword = false },
            label = { Text("Firmware WEB_USER (Basic Auth)") },
            singleLine = true,
            shape = JalShapes.field,
            modifier = Modifier.fillMaxWidth(),
            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(imeAction = ImeAction.Next),
        )
        OutlinedTextField(
            value = basicAuthPassword,
            onValueChange = { basicAuthPassword = it; if (it.isNotEmpty()) clearBasicAuthPassword = false },
            label = { Text("Firmware WEB_PASSWORD (Basic Auth)") },
            singleLine = true,
            visualTransformation = if (showBasicAuthPassword) VisualTransformation.None else PasswordVisualTransformation(),
            trailingIcon = {
                IconButton(onClick = { showBasicAuthPassword = !showBasicAuthPassword }) {
                    Icon(if (showBasicAuthPassword) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                        contentDescription = if (showBasicAuthPassword) "Hide Basic Auth password" else "Show Basic Auth password")
                }
            },
            supportingText = {
                Text(when {
                    clearBasicAuthPassword -> "Saved Basic Auth password will be removed when you save."
                    hasBasicAuthPassword -> "A Basic Auth password is saved securely. Leave blank to keep it."
                    else -> "Optional. Stored encrypted with Android Keystore; never written to logs or source code."
                })
            },
            shape = JalShapes.field,
            modifier = Modifier.fillMaxWidth(),
            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Next),
        )
        if (hasBasicAuthPassword) {
            Row {
                if (clearBasicAuthPassword) TextButton(onClick = { clearBasicAuthPassword = false }) { Text("Keep saved Basic Auth password") }
                else TextButton(onClick = { clearBasicAuthPassword = true; basicAuthPassword = "" }) { Text("Remove Basic Auth password") }
            }
        }
        OutlinedTextField(
            value = controlToken,
            onValueChange = { controlToken = it; if (it.isNotEmpty()) clearToken = false },
            label = { Text("Firmware control token (optional for read-only monitoring)") },
            singleLine = true,
            visualTransformation = if (showToken) VisualTransformation.None else PasswordVisualTransformation(),
            trailingIcon = {
                IconButton(onClick = { showToken = !showToken }) {
                    Icon(if (showToken) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                        contentDescription = if (showToken) "Hide control token" else "Show control token")
                }
            },
            supportingText = {
                Text(when {
                    clearToken -> "Saved control token will be removed when you save."
                    hasPassword -> "A token is already saved securely. Leave blank to keep it."
                    else -> "Required only for control commands. Configure a unique 8+ character CONTROL_TOKEN in the ESP32 sketch first."
                })
            },
            shape = JalShapes.field,
            modifier = Modifier.fillMaxWidth(),
            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done),
        )
        if (hasPassword) {
            Row {
                if (clearToken) TextButton(onClick = { clearToken = false }) { Text("Keep saved token") }
                else TextButton(onClick = { clearToken = true; controlToken = "" }) { Text("Remove saved token") }
            }
        }
        InfoBanner(
            tone = Tone.INFO,
            title = "Local ESP32 API",
            message = "Older JAL-SURAKSHA V2 sketches can require WEB_USER / WEB_PASSWORD (HTTP Basic Auth) for GET /api/status. Newer dual-sensor firmware uses a separate control token only for POST /api/cmd. Basic Auth over local HTTP is not encrypted; use only your trusted private hotspot.",
            icon = Icons.Filled.Lock,
        )
        TextButton(onClick = { advanced = !advanced }) {
            Text(if (advanced) "Hide API paths" else "Advanced: API paths")
        }
        if (advanced) {
            Text("Defaults: /api/status, /api/events and /api/cmd. Legacy V2 compatibility uses its single-sensor status response in read-only mode.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            PathField("Status path", statusPath) { statusPath = it }
            PathField("Events path", eventsPath) { eventsPath = it }
            PathField("Command path", commandPath) { commandPath = it }
        }
        JalOutlinedButton(
            text = if (test is TestUi.Running) "Testing..." else "Test connection",
            onClick = { onTest(buildInput()) },
            enabled = addressOk && pathsOk && test !is TestUi.Running,
            modifier = Modifier.fillMaxWidth(),
        )
        when (test) {
            is TestUi.Idle -> Unit
            is TestUi.Running -> LinearProgressIndicator(Modifier.fillMaxWidth())
            is TestUi.Done -> TestResultBanner(test)
        }
        if (saveError != null) InfoBanner(Tone.DANGER, "Could not save", saveError, icon = Icons.Filled.Error)
        JalButton(
            text = saveLabel,
            onClick = { onSave(buildInput()) },
            enabled = addressOk && pathsOk,
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(JalSpacing.lg))
    }
}

@Composable
private fun PathField(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = true,
        isError = !EndpointValidator.isValidPath(value),
        shape = JalShapes.field,
        modifier = Modifier.fillMaxWidth(),
        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Next),
    )
}

@Composable
private fun TestResultBanner(result: TestUi.Done) {
    val tone = when (result.kind) {
        TestKind.OK -> Tone.SUCCESS
        TestKind.BASIC_AUTH, TestKind.AUTH, TestKind.UNSUPPORTED -> Tone.WARNING
        TestKind.TIMEOUT, TestKind.UNREACHABLE, TestKind.INVALID, TestKind.HTTP -> Tone.DANGER
    }
    val title = when (result.kind) {
        TestKind.OK -> "ESP32 connected"
        TestKind.BASIC_AUTH -> "HTTP Basic Auth required"
        TestKind.AUTH -> "Control token / firmware lock"
        TestKind.UNSUPPORTED -> "Unsupported response"
        TestKind.TIMEOUT -> "No answer"
        TestKind.UNREACHABLE -> "Cannot reach the device"
        TestKind.INVALID -> "Check the address"
        TestKind.HTTP -> "Unexpected reply"
    }
    val icon = when (tone) {
        Tone.SUCCESS -> Icons.Filled.Info
        Tone.WARNING -> Icons.Filled.Info
        Tone.DANGER -> Icons.Filled.Error
        else -> Icons.Filled.Info
    }
    InfoBanner(
        tone = tone,
        title = title,
        message = if (result.detail != null) "${result.message}\n${result.detail}" else result.message,
        icon = icon,
    )
}
