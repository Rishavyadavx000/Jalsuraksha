package com.jalsuraksha.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.jalsuraksha.app.data.Severity
import com.jalsuraksha.app.data.FirmwareEvent
import com.jalsuraksha.app.data.EventRecord
import com.jalsuraksha.app.data.EventType
import com.jalsuraksha.app.ui.AppViewModel
import com.jalsuraksha.app.ui.ExportKind
import com.jalsuraksha.app.ui.HistoryRange
import com.jalsuraksha.app.ui.UiSnapshot
import com.jalsuraksha.app.ui.components.ChipRow
import com.jalsuraksha.app.ui.components.EmptyState
import com.jalsuraksha.app.ui.components.JalOutlinedButton
import com.jalsuraksha.app.ui.components.ScreenHeader
import com.jalsuraksha.app.ui.theme.JalSpacing
import kotlinx.coroutines.launch

@Composable
fun EventsScreen(vm: AppViewModel, ui: UiSnapshot) {
    var filter by rememberSaveable { mutableStateOf(0) }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    val filtered = when (filter) {
        1 -> ui.events.filter { it.severity != Severity.INFO }
        2 -> ui.events.filter { it.severity == Severity.INFO }
        else -> ui.events
    }
    val padding = Modifier.padding(horizontal = JalSpacing.lg)

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(JalSpacing.md),
        contentPadding = PaddingValues(bottom = JalSpacing.xl),
    ) {
        item {
            ScreenHeader(
                title = "Events",
                subtitle = "Advisory alerts and pump activity",
            )
        }
        item {
            ChipRow(
                options = listOf("All" to 0, "Needs attention" to 1, "Info" to 2),
                selected = filter,
                onSelect = { filter = it },
                modifier = padding,
            )
        }
        item {
            Row(modifier = padding.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(JalSpacing.sm)) {
                TextButton(
                    onClick = { vm.acknowledgeAll() },
                    enabled = ui.events.any { !it.acknowledged },
                ) { Text("Acknowledge all") }
                JalOutlinedButton(
                    text = "Export CSV",
                    onClick = {
                        scope.launch {
                            val intent = vm.buildExportIntent(ExportKind.EVENTS, HistoryRange.D30)
                            if (intent != null) context.startActivity(intent)
                        }
                    },
                    icon = Icons.Filled.Share,
                    enabled = ui.events.isNotEmpty(),
                )
            }
        }
        if (filtered.isEmpty() && ui.firmwareEvents.isEmpty()) {
            item {
                EmptyState(
                    icon = Icons.Filled.Notifications,
                    title = "No events here",
                    message = "Alerts appear when the device goes offline, readings look unusual or the pump state changes. They are advisory and only work while this app is open.",
                )
            }
        } else {
            items(filtered, key = { "app-${it.id}" }) { e ->
                EventCard(
                    event = e,
                    modifier = padding,
                    onAcknowledge = { vm.acknowledge(e.id) },
                )
            }
        }
        if (ui.firmwareEvents.isNotEmpty()) {
            item { Text("Events reported by the ESP32", style = MaterialTheme.typography.titleMedium, modifier = padding) }
            items(ui.firmwareEvents, key = { "fw-${it.id}" }) { firmwareEvent ->
                EventCard(
                    event = firmwareEvent.toEventRecord(ui.nowMs),
                    modifier = padding,
                    showSuggestion = false,
                )
            }
        }
        item {
            Text(
                "Firmware events come from the ESP32's own ring buffer. App-generated alerts are separate and only observe periods when this app is connected. Neither replaces local firmware interlocks or a physical power cutoff.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = padding,
            )
        }
    }
}


private fun FirmwareEvent.toEventRecord(nowMs: Long): EventRecord {
    val severity = when (code) {
        4, 6 -> Severity.CRITICAL
        5, 7, 14 -> Severity.WARNING
        else -> Severity.INFO
    }
    val type = when (code) {
        1 -> EventType.FIRMWARE_BOOT
        2, 3 -> EventType.PUMP_STATE_CHANGED
        4 -> EventType.FIRMWARE_LEAK
        5 -> EventType.FIRMWARE_WARNING
        6 -> EventType.FIRMWARE_SENSOR_FAULT
        7 -> EventType.FIRMWARE_WARNING
        8 -> EventType.FIRMWARE_ACKNOWLEDGED
        9 -> EventType.FIRMWARE_RESET
        10 -> EventType.FIRMWARE_WIFI
        11 -> EventType.FIRMWARE_SETTINGS
        12 -> EventType.CALIBRATION_SAVED
        13 -> EventType.FIRMWARE_INFO
        14 -> EventType.FIRMWARE_COMMAND_REJECTED
        else -> EventType.FIRMWARE_INFO
    }
    val timestamp = timeMs ?: (nowMs - uptimeSeconds * 1_000L).coerceAtLeast(0L)
    return EventRecord(id = id, tMs = timestamp, severity = severity, type = type, message = message.ifBlank { "Firmware event code $code" })
}
