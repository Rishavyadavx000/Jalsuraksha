package com.jalsuraksha.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import com.jalsuraksha.app.data.ApiContract
import com.jalsuraksha.app.data.LinkState
import com.jalsuraksha.app.data.PumpState
import com.jalsuraksha.app.ui.AppViewModel
import com.jalsuraksha.app.ui.PumpCommandUi
import com.jalsuraksha.app.ui.UiSnapshot
import com.jalsuraksha.app.ui.components.InfoBanner
import com.jalsuraksha.app.ui.components.JalButton
import com.jalsuraksha.app.ui.components.JalCard
import com.jalsuraksha.app.ui.components.ScreenHeader
import com.jalsuraksha.app.ui.components.Tone
import com.jalsuraksha.app.ui.theme.JalSpacing

/** Firmware-owned dual-sensor calibration. This screen never starts the pump. */
@Composable
fun CalibrationScreen(vm: AppViewModel, ui: UiSnapshot, onBack: () -> Unit) {
    var litresText by rememberSaveable { mutableStateOf("5.0") }
    val st = ui.status
    val live = ui.link == LinkState.ONLINE && st != null
    val pumpOff = st?.pump == PumpState.OFF
    val tokenReady = st?.tokenConfigured == true
    val appControlEnabled = ui.settings.pumpRequestsEnabled
    val pulsesA = st?.calibrationPulsesA ?: 0L
    val pulsesB = st?.calibrationPulsesB ?: 0L
    val litres = litresText.replace(',', '.').toDoubleOrNull()
    val done = ui.pumpCommand as? PumpCommandUi.Done

    Column(
        Modifier.fillMaxSize().imePadding().verticalScroll(rememberScrollState()),
    ) {
        ScreenHeader(title = "Dual-sensor calibration", subtitle = "Set K_A and K_B inside the ESP32 firmware", onBack = onBack)
        Column(Modifier.padding(horizontal = JalSpacing.lg), verticalArrangement = Arrangement.spacedBy(JalSpacing.md)) {
            InfoBanner(
                tone = Tone.WARNING,
                title = "Pump must remain OFF during flow calibration",
                message = "The sketch requires the pump to be OFF before saving calibration. Pass a measured amount of water through both sensors using the approved manual/gravity test procedure. Do not run the pump from this wizard.",
                icon = Icons.Filled.Warning,
            )
            if (!live) {
                InfoBanner(Tone.WARNING, "ESP32 connection required", "Connect to the same hotspot and wait for a fresh status before sending calibration commands.", icon = Icons.Filled.Warning)
            }
            if (!tokenReady) {
                InfoBanner(Tone.DANGER, "Firmware command lock is active", "Set a unique CONTROL_TOKEN of at least 8 characters in the ESP32 sketch, upload that firmware, then save the same token under Device Settings.", icon = Icons.Filled.Warning)
            }
            if (!appControlEnabled) {
                InfoBanner(Tone.INFO, "App command switch is OFF", "Enable device commands in Settings only after checking the relay and firmware safety instructions. The firmware still checks every command.", icon = Icons.Filled.Info)
            }
            JalCard {
                Text("Current firmware calibration", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(JalSpacing.sm))
                StatRow("Calibration status", if (st?.calibrated == true) "Calibrated" else "Not calibrated")
                StatRow("Sensor A K", st?.firmwareConfig?.kA?.let { String.format(java.util.Locale.US, "%.1f pulses/L", it) } ?: "--")
                StatRow("Sensor B K", st?.firmwareConfig?.kB?.let { String.format(java.util.Locale.US, "%.1f pulses/L", it) } ?: "--")
                StatRow("Sensor A pulses since zero", pulsesA.toString())
                StatRow("Sensor B pulses since zero", pulsesB.toString())
                StatRow("Pump state", st?.pump?.name ?: "UNKNOWN")
            }
            JalCard {
                Text("Step 1 · Zero pulse counters", style = MaterialTheme.typography.titleMedium)
                Text(
                    "Stop the pump and close the test leak path. Press ZERO, then pass the known water volume through both sensors. The firmware snapshots both pulse counters.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                JalButton(
                    text = "1. Zero counters on ESP32",
                    onClick = { vm.sendFirmwareCommand(ApiContract.COMMAND_CAL_ZERO) },
                    enabled = live && pumpOff == true && tokenReady && appControlEnabled,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            JalCard {
                Text("Step 2 · Measure a known volume", style = MaterialTheme.typography.titleMedium)
                Text(
                    "After zeroing, pass the exact measured volume through Sensor A and Sensor B. The firmware needs at least 50 pulses from each sensor and requires the pump to be OFF.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                OutlinedTextField(
                    value = litresText,
                    onValueChange = { litresText = it },
                    label = { Text("Known water volume (litres)") },
                    singleLine = true,
                    isError = litres == null || litres !in 0.2..100.0,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth(),
                )
                Row(horizontalArrangement = Arrangement.spacedBy(JalSpacing.md), modifier = Modifier.fillMaxWidth()) {
                    StatRow("A pulses", "$pulsesA / 50 minimum", Modifier.weight(1f))
                    StatRow("B pulses", "$pulsesB / 50 minimum", Modifier.weight(1f))
                }
                JalButton(
                    text = "2. Compute and save K_A + K_B",
                    onClick = { litres?.let { vm.sendFirmwareCommand(ApiContract.COMMAND_CAL_SAVE, mapOf("l" to java.lang.String.format(java.util.Locale.US, "%.3f", it))) } },
                    enabled = live && pumpOff == true && tokenReady && appControlEnabled && litres != null && litres in 0.2..100.0 && pulsesA >= 50 && pulsesB >= 50,
                    modifier = Modifier.fillMaxWidth(),
                )
                if (pulsesA < 50 || pulsesB < 50) {
                    Text("Calibration is not ready: both sensors must each register at least 50 pulses.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            JalCard {
                Text("Step 3 · Capture the no-leak baseline", style = MaterialTheme.typography.titleMedium)
                Text(
                    "After both K values are saved, close the leak path, start the pump from the Pump screen, wait for stable flow, and then request baseline capture. The firmware requires a calibrated system, pump ON and no latched alarm.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                StatRow("Baseline capture", if (st?.baselineActive == true) "In progress" else "Not running")
                StatRow("Saved baseline", st?.firmwareConfig?.baseline?.let { String.format(java.util.Locale.US, "%.3f L/min", it) } ?: "--")
                JalButton(
                    text = "3. Capture no-leak baseline",
                    onClick = { vm.sendFirmwareCommand(ApiContract.COMMAND_BASELINE) },
                    enabled = live && st?.calibrated == true && st.pump == PumpState.ON && tokenReady && appControlEnabled && (st.latch.isNullOrBlank() || st.latch.equals("none", true)),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            if (done != null && ui.nowMs - done.atMs < 120_000L) {
                InfoBanner(
                    tone = when (done.outcome) {
                        com.jalsuraksha.app.ui.CommandOutcome.CONFIRMED -> Tone.SUCCESS
                        com.jalsuraksha.app.ui.CommandOutcome.BLOCKED -> Tone.INFO
                        else -> Tone.WARNING
                    },
                    title = when (done.outcome) {
                        com.jalsuraksha.app.ui.CommandOutcome.CONFIRMED -> "Firmware accepted command"
                        com.jalsuraksha.app.ui.CommandOutcome.BLOCKED -> "Command not sent"
                        else -> "Firmware command response"
                    },
                    message = done.message,
                    icon = if (done.outcome == com.jalsuraksha.app.ui.CommandOutcome.CONFIRMED) Icons.Filled.CheckCircle else Icons.Filled.Info,
                )
            }
            Text(
                "Calibration changes are persisted by the ESP32. Android does not invent or overwrite K_A / K_B values. Check the status again after the firmware responds with cal=true.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}
