package com.jalsuraksha.app.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.jalsuraksha.app.ui.screens.CalibrationScreen
import com.jalsuraksha.app.ui.screens.DeviceScreen
import com.jalsuraksha.app.ui.screens.DiagnosticsScreen
import com.jalsuraksha.app.ui.screens.EventsScreen
import com.jalsuraksha.app.ui.screens.HistoryScreen
import com.jalsuraksha.app.ui.screens.HomeScreen
import com.jalsuraksha.app.ui.screens.MonitorScreen
import com.jalsuraksha.app.ui.screens.OnboardingScreen
import com.jalsuraksha.app.ui.screens.PumpScreen
import com.jalsuraksha.app.ui.screens.SettingsScreen
import com.jalsuraksha.app.ui.screens.SplashScreen

object Routes {
    const val ONBOARDING = "onboarding"
    const val HOME = "home"
    const val MONITOR = "monitor"
    const val HISTORY = "history"
    const val EVENTS = "events"
    const val SETTINGS = "settings"
    const val PUMP = "pump"
    const val DEVICE = "device"
    const val CALIBRATION = "calibration"
    const val DIAGNOSTICS = "diagnostics"

    val tabs = listOf(HOME, MONITOR, HISTORY, EVENTS, SETTINGS)
}

private data class NavTab(val route: String, val label: String, val icon: ImageVector)

private val NAV_TABS = listOf(
    NavTab(Routes.HOME, "Home", Icons.Filled.Home),
    NavTab(Routes.MONITOR, "Live", Icons.Filled.Speed),
    NavTab(Routes.HISTORY, "History", Icons.Filled.History),
    NavTab(Routes.EVENTS, "Events", Icons.Filled.Notifications),
    NavTab(Routes.SETTINGS, "Settings", Icons.Filled.Settings),
)

@Composable
fun JalApp(vm: AppViewModel, ui: UiSnapshot) {
    var splashDone by rememberSaveable { mutableStateOf(false) }
    if (!splashDone) {
        SplashScreen(
            ready = ui.settingsLoaded,
            firstLaunch = !ui.settings.onboardingDone,
            onFinished = { splashDone = true },
        )
    } else {
        MainNav(
            vm = vm,
            onboardingDone = ui.settings.onboardingDone,
            attentionCount = ui.attentionCount,
        )
    }
}

/**
 * The NavHost builder must NOT capture the per-second UiSnapshot: a changing capture would rebuild the
 * navigation graph every second. Each destination collects the snapshot itself instead.
 */
@Composable
private fun MainNav(vm: AppViewModel, onboardingDone: Boolean, attentionCount: Int) {
    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val route = backStack?.destination?.route
    val start = remember { if (onboardingDone) Routes.HOME else Routes.ONBOARDING }

    // Keep the screen in step with saved state: after a reset go back to onboarding, and if settings finished
    // loading late (after the first frame) leave onboarding for the dashboard.
    LaunchedEffect(onboardingDone) {
        val current = nav.currentDestination?.route
        if (!onboardingDone && current != Routes.ONBOARDING) {
            nav.navigate(Routes.ONBOARDING) {
                popUpTo(nav.graph.id) { inclusive = true }
            }
        } else if (onboardingDone && current == Routes.ONBOARDING) {
            nav.navigate(Routes.HOME) {
                popUpTo(Routes.ONBOARDING) { inclusive = true }
                launchSingleTop = true
            }
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            if (route != null && route in Routes.tabs) {
                NavigationBar {
                    NAV_TABS.forEach { tab ->
                        NavigationBarItem(
                            selected = route == tab.route,
                            onClick = { navigateTab(nav, tab.route) },
                            icon = {
                                if (tab.route == Routes.EVENTS && attentionCount > 0) {
                                    BadgedBox(
                                        badge = {
                                            Badge { Text(attentionCount.coerceAtMost(99).toString()) }
                                        },
                                    ) {
                                        Icon(tab.icon, contentDescription = null)
                                    }
                                } else {
                                    Icon(tab.icon, contentDescription = null)
                                }
                            },
                            label = { Text(tab.label) },
                        )
                    }
                }
            }
        },
    ) { padding ->
        NavHost(
            navController = nav,
            startDestination = start,
            modifier = Modifier.padding(padding),
        ) {
            composable(Routes.ONBOARDING) {
                val ui by vm.ui.collectAsStateWithLifecycle()
                OnboardingScreen(
                    vm = vm,
                    hasPassword = ui.hasPassword,
                    hasBasicAuthPassword = ui.hasBasicAuth,
                    onDone = {
                        nav.navigate(Routes.HOME) {
                            popUpTo(Routes.ONBOARDING) { inclusive = true }
                            launchSingleTop = true
                        }
                    },
                )
            }
            composable(Routes.HOME) {
                val ui by vm.ui.collectAsStateWithLifecycle()
                HomeScreen(
                    ui = ui,
                    onRefresh = { vm.refreshNow() },
                    onRequestPump = { on -> vm.requestPump(on) },
                    onOpenPump = { nav.navigate(Routes.PUMP) },
                    onOpenEvents = { navigateTab(nav, Routes.EVENTS) },
                    onSetupDevice = { nav.navigate(Routes.DEVICE) },
                    onOpenDiagnostics = { nav.navigate(Routes.DIAGNOSTICS) },
                )
            }
            composable(Routes.MONITOR) {
                val ui by vm.ui.collectAsStateWithLifecycle()
                MonitorScreen(
                    ui = ui,
                    onOpenCalibration = { nav.navigate(Routes.CALIBRATION) },
                )
            }
            composable(Routes.HISTORY) {
                val ui by vm.ui.collectAsStateWithLifecycle()
                HistoryScreen(vm = vm, ui = ui)
            }
            composable(Routes.EVENTS) {
                val ui by vm.ui.collectAsStateWithLifecycle()
                EventsScreen(vm = vm, ui = ui)
            }
            composable(Routes.SETTINGS) {
                val ui by vm.ui.collectAsStateWithLifecycle()
                SettingsScreen(
                    vm = vm,
                    ui = ui,
                    onOpenDevice = { nav.navigate(Routes.DEVICE) },
                    onOpenCalibration = { nav.navigate(Routes.CALIBRATION) },
                    onOpenDiagnostics = { nav.navigate(Routes.DIAGNOSTICS) },
                )
            }
            composable(Routes.PUMP) {
                val ui by vm.ui.collectAsStateWithLifecycle()
                PumpScreen(
                    ui = ui,
                    onRequestPump = { on -> vm.requestPump(on) },
                    onSendFirmwareCommand = { command -> vm.sendFirmwareCommand(command) },
                    onDismissResult = { vm.dismissPumpResult() },
                    onBack = { nav.popBackStack() },
                )
            }
            composable(Routes.DEVICE) {
                val ui by vm.ui.collectAsStateWithLifecycle()
                DeviceScreen(
                    vm = vm,
                    ui = ui,
                    onBack = { nav.popBackStack() },
                )
            }
            composable(Routes.CALIBRATION) {
                val ui by vm.ui.collectAsStateWithLifecycle()
                CalibrationScreen(
                    vm = vm,
                    ui = ui,
                    onBack = { nav.popBackStack() },
                )
            }
            composable(Routes.DIAGNOSTICS) {
                val ui by vm.ui.collectAsStateWithLifecycle()
                DiagnosticsScreen(
                    vm = vm,
                    ui = ui,
                    onBack = { nav.popBackStack() },
                )
            }
        }
    }
}

private fun navigateTab(nav: NavHostController, route: String) {
    nav.navigate(route) {
        popUpTo(Routes.HOME) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}
