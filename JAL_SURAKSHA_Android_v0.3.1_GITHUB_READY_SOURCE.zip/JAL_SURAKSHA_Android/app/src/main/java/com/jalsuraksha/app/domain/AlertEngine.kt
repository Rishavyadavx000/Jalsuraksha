package com.jalsuraksha.app.domain

import com.jalsuraksha.app.data.ApiError
import com.jalsuraksha.app.data.DeviceStatus
import com.jalsuraksha.app.data.EventType
import com.jalsuraksha.app.data.FirmwarePumpPermission
import com.jalsuraksha.app.data.PumpState
import com.jalsuraksha.app.data.Severity
import com.jalsuraksha.app.data.shortLabel
import java.util.Locale

data class NewEvent(val severity: Severity, val type: EventType, val message: String)

data class AlertThresholds(
    val highFlowLpm: Double,
    val noFlowGraceSec: Int,
    val flowWhileOffLpm: Double,
    val flowWhileOffGraceSec: Int,
    val weakSignalDbm: Int,
    val staleAfterSec: Int,
)

/** Episode tracking so each condition raises ONE event until it clears. */
data class AlertState(
    val prev: DeviceStatus? = null,
    val offlineFlagged: Boolean = false,
    val authFlagged: Boolean = false,
    val unsupportedFlagged: Boolean = false,
    val staleFlagged: Boolean = false,
    val noFlowSinceMs: Long? = null,
    val noFlowFlagged: Boolean = false,
    val flowOffSinceMs: Long? = null,
    val flowOffFlagged: Boolean = false,
    val highFlowFlagged: Boolean = false,
    val weakSignalFlagged: Boolean = false,
    val contradictionFlagged: Boolean = false,
    val sensorFlagged: Boolean = false,
)

/**
 * App-side advisory rules over what the app has observed. They are NOT a protection system:
 * they only work while the app is open and connected, and the flow rules are heuristics.
 */
object AlertEngine {
    const val NO_FLOW_LPM = 0.05
    const val COUNTER_RESET_EPSILON_L = 0.05

    data class Step(val state: AlertState, val events: List<NewEvent>)

    fun onStatus(state: AlertState, s: DeviceStatus, nowMs: Long, t: AlertThresholds): Step {
        val events = mutableListOf<NewEvent>()
        var st = state
        val prev = state.prev

        if (st.offlineFlagged || st.authFlagged || st.unsupportedFlagged || st.staleFlagged) {
            events += NewEvent(Severity.INFO, EventType.DEVICE_ONLINE, "The connection to the device is working again.")
            st = st.copy(offlineFlagged = false, authFlagged = false, unsupportedFlagged = false, staleFlagged = false)
        }

        val prevTotal = prev?.totalLiters
        val total = s.totalLiters
        if (prevTotal != null && total != null && total < prevTotal - COUNTER_RESET_EPSILON_L) {
            events += NewEvent(
                Severity.INFO,
                EventType.DEVICE_REBOOT,
                "The total volume went backwards (${one(prevTotal)} L to ${one(total)} L). The device probably restarted. Usage is not counted across the reset.",
            )
        }

        if (prev != null &&
            prev.pump != PumpState.UNKNOWN &&
            s.pump != PumpState.UNKNOWN &&
            prev.pump != s.pump
        ) {
            events += NewEvent(Severity.INFO, EventType.PUMP_STATE_CHANGED, "The device now reports the pump ${s.pump.name}.")
        }

        if (prev != null &&
            prev.pumpPermission != FirmwarePumpPermission.UNKNOWN &&
            s.pumpPermission != FirmwarePumpPermission.UNKNOWN &&
            prev.pumpPermission != s.pumpPermission
        ) {
            val enabled = s.pumpPermission == FirmwarePumpPermission.ENABLED
            events += NewEvent(
                if (enabled) Severity.WARNING else Severity.INFO,
                EventType.PUMP_LOCK_CHANGED,
                if (enabled) "The firmware has enabled pump control." else "The firmware has locked pump control.",
            )
        }

        if (s.contradictoryPump) {
            if (!st.contradictionFlagged) {
                events += NewEvent(
                    Severity.CRITICAL,
                    EventType.PUMP_STATUS_CONTRADICTION,
                    "The device reports the pump ON while pump control is locked. The pump state is shown as unknown. Check the hardware.",
                )
                st = st.copy(contradictionFlagged = true)
            }
        } else if (st.contradictionFlagged) {
            st = st.copy(contradictionFlagged = false)
        }

        // The supplied firmware writes zero placeholders to fa/fb/va/vb before both
        // sensors are calibrated. Those values are deliberately represented as null by
        // StatusParser. Do not turn the expected uncalibrated state into a sensor fault or
        // infer leak/no-flow/high-flow alerts from uncalibrated values.
        val calibrated = s.calibrated == true
        val flow = s.flowLpm.takeIf { calibrated }

        if (!calibrated) {
            st = st.copy(
                sensorFlagged = false,
                noFlowSinceMs = null,
                noFlowFlagged = false,
                flowOffSinceMs = null,
                flowOffFlagged = false,
                highFlowFlagged = false,
            )
        } else {
            if (flow == null) {
                if (!st.sensorFlagged) {
                    events += NewEvent(Severity.WARNING, EventType.SENSOR_UNAVAILABLE, "The firmware is calibrated but did not provide a valid flow reading.")
                    st = st.copy(sensorFlagged = true)
                }
            } else if (st.sensorFlagged) {
                st = st.copy(sensorFlagged = false)
            }

            if (s.pump == PumpState.ON && flow != null && flow < NO_FLOW_LPM) {
                val since = st.noFlowSinceMs ?: nowMs
                st = st.copy(noFlowSinceMs = since)
                if (!st.noFlowFlagged && nowMs - since >= t.noFlowGraceSec * 1000L) {
                    events += NewEvent(
                        Severity.WARNING,
                        EventType.NO_FLOW_WHILE_ON,
                        "No flow for ${t.noFlowGraceSec} s while the pump is reported ON. This is a heuristic: it could be a dry run, a blockage, or a sensor or wiring fault.",
                    )
                    st = st.copy(noFlowFlagged = true)
                }
            } else if (st.noFlowSinceMs != null || st.noFlowFlagged) {
                st = st.copy(noFlowSinceMs = null, noFlowFlagged = false)
            }

            if (s.pump == PumpState.OFF && flow != null && flow >= t.flowWhileOffLpm) {
                val since = st.flowOffSinceMs ?: nowMs
                st = st.copy(flowOffSinceMs = since)
                if (!st.flowOffFlagged && nowMs - since >= t.flowWhileOffGraceSec * 1000L) {
                    events += NewEvent(
                        Severity.WARNING,
                        EventType.FLOW_WHILE_OFF,
                        "Flow of ${one(flow)} L/min for ${t.flowWhileOffGraceSec} s while the pump is reported OFF. This is a heuristic: it could be a leak, a bypass, gravity flow or sensor noise.",
                    )
                    st = st.copy(flowOffFlagged = true)
                }
            } else if (st.flowOffSinceMs != null || st.flowOffFlagged) {
                st = st.copy(flowOffSinceMs = null, flowOffFlagged = false)
            }

            if (flow != null && flow >= t.highFlowLpm) {
                if (!st.highFlowFlagged) {
                    events += NewEvent(
                        Severity.WARNING,
                        EventType.HIGH_FLOW,
                        "Flow reached ${one(flow)} L/min, above your limit of ${one(t.highFlowLpm)} L/min.",
                    )
                    st = st.copy(highFlowFlagged = true)
                }
            } else if (st.highFlowFlagged && (flow == null || flow < t.highFlowLpm * 0.9)) {
                st = st.copy(highFlowFlagged = false)
            }
        }

        val rssi = s.rssiDbm
        if (rssi != null && rssi <= t.weakSignalDbm) {
            if (!st.weakSignalFlagged) {
                events += NewEvent(
                    Severity.INFO,
                    EventType.WEAK_SIGNAL,
                    "The ESP32's Wi-Fi signal is weak ($rssi dBm). Connection drops are more likely.",
                )
                st = st.copy(weakSignalFlagged = true)
            }
        } else if (st.weakSignalFlagged && rssi != null && rssi > t.weakSignalDbm + 5) {
            st = st.copy(weakSignalFlagged = false)
        }

        return Step(st.copy(prev = s), events)
    }

    fun onFailure(
        state: AlertState,
        error: ApiError,
        consecutiveFailures: Int,
        lastSuccessMs: Long?,
        nowMs: Long,
        t: AlertThresholds,
    ): Step {
        val events = mutableListOf<NewEvent>()
        var st = state

        when (error) {
            is ApiError.AuthRequired -> {
                if (!st.authFlagged) {
                    events += NewEvent(
                        Severity.WARNING,
                        EventType.AUTH_FAILED,
                        "The firmware rejected the control token (HTTP 401). Check the token saved in Settings > Device.",
                    )
                    st = st.copy(authFlagged = true)
                }
            }
            is ApiError.BadResponse -> {
                if (!st.unsupportedFlagged) {
                    events += NewEvent(
                        Severity.WARNING,
                        EventType.UNSUPPORTED_API,
                        "The device answered with something the app does not understand: ${error.reason}.",
                    )
                    st = st.copy(unsupportedFlagged = true)
                }
            }
            is ApiError.NotConfigured, is ApiError.InvalidEndpoint, is ApiError.FirmwareControlLocked -> Unit
            is ApiError.Timeout, is ApiError.Unreachable, is ApiError.HttpError -> {
                val age = if (lastSuccessMs != null) nowMs - lastSuccessMs else null
                if (!st.staleFlagged && age != null && age > t.staleAfterSec * 1000L) {
                    events += NewEvent(
                        Severity.WARNING,
                        EventType.DATA_STALE,
                        "No fresh data for ${age / 1000} s. Displayed values are the last known readings.",
                    )
                    st = st.copy(staleFlagged = true)
                }
                if (!st.offlineFlagged && consecutiveFailures >= LinkDeriver.OFFLINE_AFTER_FAILURES) {
                    events += NewEvent(
                        Severity.WARNING,
                        EventType.DEVICE_OFFLINE,
                        "The device is not responding (${error.shortLabel()}).",
                    )
                    st = st.copy(offlineFlagged = true)
                }
            }
        }

        // Flow cannot be observed while disconnected, so flow episodes restart on reconnect.
        st = st.copy(noFlowSinceMs = null, noFlowFlagged = false, flowOffSinceMs = null, flowOffFlagged = false)
        return Step(st, events)
    }

    private fun one(v: Double): String = String.format(Locale.US, "%.1f", v)
}
