package com.jalsuraksha.app.data

sealed interface ApiError {
    data object NotConfigured : ApiError
    data class InvalidEndpoint(val reason: String) : ApiError
    data object Timeout : ApiError
    data class Unreachable(val detail: String) : ApiError
    data object AuthRequired : ApiError
    data object BasicAuthRequired : ApiError
    data object FirmwareControlLocked : ApiError
    data class HttpError(val code: Int, val bodySnippet: String) : ApiError
    data class BadResponse(val reason: String) : ApiError
}

sealed interface ApiOutcome<out T> {
    data class Success<out T>(val value: T, val httpCode: Int, val latencyMs: Long) : ApiOutcome<T>
    data class Failure(val error: ApiError) : ApiOutcome<Nothing>
}

fun ApiError.userMessage(): String = when (this) {
    is ApiError.NotConfigured -> "No ESP32 address is saved yet. Add the device address first."
    is ApiError.InvalidEndpoint -> reason
    is ApiError.Timeout -> "The ESP32 did not answer in time. Check that the phone and ESP32 are on the same hotspot or Wi-Fi."
    is ApiError.Unreachable -> "Could not reach the ESP32 ($detail). Its hotspot IP may have changed."
    is ApiError.AuthRequired -> "The firmware rejected the control token. Check CONTROL_TOKEN in the firmware."
    is ApiError.BasicAuthRequired -> "HTTP 401: this firmware requires HTTP Basic Auth. Enter WEB_USER and WEB_PASSWORD from the ESP32 sketch in the separate Basic Auth fields."
    is ApiError.FirmwareControlLocked -> "Firmware control is locked. Set a unique CONTROL_TOKEN and verify relay polarity in the sketch before enabling control."
    is ApiError.HttpError -> "The ESP32 answered with HTTP $code."
    is ApiError.BadResponse -> "The ESP32 answered, but the response was not understood: $reason"
}

fun ApiError.shortLabel(): String = when (this) {
    is ApiError.NotConfigured -> "Not configured"
    is ApiError.InvalidEndpoint -> "Invalid address"
    is ApiError.Timeout -> "Timeout"
    is ApiError.Unreachable -> "Unreachable"
    is ApiError.AuthRequired -> "Control token rejected"
    is ApiError.BasicAuthRequired -> "Basic Auth required"
    is ApiError.FirmwareControlLocked -> "Firmware control locked"
    is ApiError.HttpError -> "HTTP $code"
    is ApiError.BadResponse -> "Unsupported response"
}
