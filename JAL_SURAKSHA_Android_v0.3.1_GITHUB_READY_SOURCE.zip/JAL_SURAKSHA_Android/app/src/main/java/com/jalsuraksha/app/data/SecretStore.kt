package com.jalsuraksha.app.data

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** AES-256-GCM encrypted firmware command token. Existing v0.2 ciphertext key is retained for migration. */
class SecretStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    @Volatile
    var lastError: String? = null
        private set

    @Synchronized fun hasControlToken(): Boolean = prefs.contains(KEY_SECRET)

    @Synchronized
    fun getControlToken(): String? {
        val stored = prefs.getString(KEY_SECRET, null) ?: return null
        return try {
            val raw = Base64.decode(stored, Base64.NO_WRAP)
            if (raw.size <= IV_BYTES) {
                lastError = "The saved control token is corrupt. Enter it again in Settings."
                return null
            }
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.DECRYPT_MODE, secretKey(), GCMParameterSpec(TAG_BITS, raw.copyOfRange(0, IV_BYTES)))
            String(cipher.doFinal(raw, IV_BYTES, raw.size - IV_BYTES), Charsets.UTF_8)
        } catch (e: Exception) {
            lastError = "Could not decrypt the saved control token (${e.javaClass.simpleName}). Enter it again in Settings."
            null
        }
    }

    @Synchronized
    fun setControlToken(token: String?): Boolean {
        if (token.isNullOrEmpty()) {
            prefs.edit().remove(KEY_SECRET).apply()
            return true
        }
        return try {
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.ENCRYPT_MODE, secretKey())
            val sealed = cipher.iv + cipher.doFinal(token.toByteArray(Charsets.UTF_8))
            prefs.edit().putString(KEY_SECRET, Base64.encodeToString(sealed, Base64.NO_WRAP)).apply()
            lastError = null
            true
        } catch (e: Exception) {
            lastError = "Could not encrypt the control token (${e.javaClass.simpleName}); it was not saved."
            false
        }
    }

    @Synchronized fun hasBasicAuthPassword(): Boolean = prefs.contains(KEY_BASIC_AUTH_SECRET)

    @Synchronized
    fun getBasicAuthPassword(): String? {
        val stored = prefs.getString(KEY_BASIC_AUTH_SECRET, null) ?: return null
        return try {
            val raw = Base64.decode(stored, Base64.NO_WRAP)
            if (raw.size <= IV_BYTES) {
                lastError = "The saved Basic Auth password is corrupt. Enter it again in Device settings."
                return null
            }
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.DECRYPT_MODE, secretKey(), GCMParameterSpec(TAG_BITS, raw.copyOfRange(0, IV_BYTES)))
            String(cipher.doFinal(raw, IV_BYTES, raw.size - IV_BYTES), Charsets.UTF_8)
        } catch (e: Exception) {
            lastError = "Could not decrypt the saved Basic Auth password (${e.javaClass.simpleName}). Enter it again in Device settings."
            null
        }
    }

    @Synchronized
    fun setBasicAuthPassword(password: String?): Boolean {
        if (password.isNullOrEmpty()) {
            prefs.edit().remove(KEY_BASIC_AUTH_SECRET).apply()
            lastError = null
            return true
        }
        return try {
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.ENCRYPT_MODE, secretKey())
            val sealed = cipher.iv + cipher.doFinal(password.toByteArray(Charsets.UTF_8))
            prefs.edit().putString(KEY_BASIC_AUTH_SECRET, Base64.encodeToString(sealed, Base64.NO_WRAP)).apply()
            lastError = null
            true
        } catch (e: Exception) {
            lastError = "Could not encrypt the Basic Auth password (${e.javaClass.simpleName}); it was not saved."
            false
        }
    }

    /** v0.2 migration aliases. The old password slot is interpreted as the v1 firmware control token. */
    @Deprecated("Use getControlToken") @Synchronized fun getPassword(): String? = getControlToken()
    @Deprecated("Use hasControlToken") @Synchronized fun hasPassword(): Boolean = hasControlToken()
    @Deprecated("Use setControlToken") @Synchronized fun setPassword(value: String?): Boolean = setControlToken(value)

    @Synchronized
    fun clear() {
        prefs.edit().clear().apply()
        try {
            val ks = KeyStore.getInstance(KEYSTORE).apply { load(null) }
            if (ks.containsAlias(KEY_ALIAS)) ks.deleteEntry(KEY_ALIAS)
        } catch (e: Exception) {
            lastError = "Could not remove the keystore key (${e.javaClass.simpleName})."
        }
    }

    private fun secretKey(): SecretKey {
        val ks = KeyStore.getInstance(KEYSTORE).apply { load(null) }
        val existing = ks.getKey(KEY_ALIAS, null)
        if (existing is SecretKey) return existing
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, KEYSTORE)
        generator.init(
            KeyGenParameterSpec.Builder(KEY_ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build(),
        )
        return generator.generateKey()
    }

    private companion object {
        const val PREFS_NAME = "jal_secrets"
        const val KEY_SECRET = "device_password" // preserve ciphertext created by v0.2
        const val KEY_BASIC_AUTH_SECRET = "basic_auth_password_v1"
        const val KEYSTORE = "AndroidKeyStore"
        const val KEY_ALIAS = "jal_suraksha_credentials_v1"
        const val TRANSFORMATION = "AES/GCM/NoPadding"
        const val IV_BYTES = 12
        const val TAG_BITS = 128
    }
}
