package com.jalsuraksha.app.data

/** Pump state as reported by the ESP32. UNKNOWN is the safe value for missing or invalid data. */
enum class PumpState { ON, OFF, UNKNOWN }

/** Permission derived from the sketch's tokenConfigured && RELAY_POLARITY_VERIFIED flags. */
enum class FirmwarePumpPermission { ENABLED, LOCKED, UNKNOWN }

data class FirmwareConfig(
    val kA: Double? = null,
    val kB: Double? = null,
    val windowMs: Long? = null,
    val zeroLpm: Double? = null,
    val minAbs: Double? = null,
    val relativePercent: Double? = null,
    val persistence: Int? = null,
    val baseline: Double? = null,
)

data class FirmwareEvent(
    val id: Long,
    val timeMs: Long?,
    val uptimeSeconds: Long,
    val code: Int,
    val message: String,
)

/** One validated status reading from the dual-flow-sensor JAL-SURAKSHA firmware. */
data class DeviceStatus(
    val wifi: String?,
    val ip: String?,
    val rssiDbm: Int?,
    val pump: PumpState,
    val pumpPermission: FirmwarePumpPermission,
    /** Legacy-compatible aliases: the main chart and basic metric continue to use Sensor A. */
    val flowLpm: Double?,
    val totalLiters: Double?,
    val deviceId: String?,
    val apiVersion: Int?,
    val receivedAtMs: Long,
    val contradictoryPump: Boolean = false,
    val warnings: List<String> = emptyList(),
    val flowALpm: Double? = flowLpm,
    val flowBLpm: Double? = null,
    val differenceLpm: Double? = null,
    val differencePercent: Double? = null,
    val rateAHz: Double? = null,
    val rateBHz: Double? = null,
    val volumeALiters: Double? = totalLiters,
    val volumeBLiters: Double? = null,
    val pulsesA: Long? = null,
    val pulsesB: Long? = null,
    val calibrationPulsesA: Long? = null,
    val calibrationPulsesB: Long? = null,
    val systemState: String? = null,
    val severityLevel: Int? = null,
    val latch: String? = null,
    val locationEstimate: String? = null,
    val muted: Boolean? = null,
    val calibrated: Boolean? = null,
    val baselineActive: Boolean? = null,
    val sensorHealth: String? = null,
    val cloudState: String? = null,
    val uptimeSeconds: Long? = null,
    val note: String? = null,
    val stopReason: String? = null,
    val tokenConfigured: Boolean? = null,
    val accessPointPasswordDefault: Boolean? = null,
    val relayPolarityVerified: Boolean? = null,
    val firmwareEventCode: Int? = null,
    val firmwareConfig: FirmwareConfig? = null,
) {
    val sensorAFlowLpm: Double? get() = flowALpm ?: flowLpm
    val sensorBFlowLpm: Double? get() = flowBLpm
    val sensorATotalLiters: Double? get() = volumeALiters ?: totalLiters
    val sensorBTotalLiters: Double? get() = volumeBLiters
    /** True only for the firmware's confirmed leak latch/state, not for sensor faults. */
    val isLeaking: Boolean get() = latch.equals("leak", true) || systemState?.startsWith("LEAK", true) == true

    /** Matches the exact firmware values `possible_leak` and `POSSIBLE LEAK / SENSOR B CHECK`. */
    val isPossibleLeak: Boolean get() =
        latch.equals("possible_leak", true) || systemState?.contains("POSSIBLE LEAK", true) == true
}

data class Sample(
    val tMs: Long,
    val flowLpm: Double?,
    val totalLiters: Double?,
    val pump: PumpState,
    val rssiDbm: Int?,
    val flowBLpm: Double? = null,
    val totalBLiters: Double? = null,
    val differenceLpm: Double? = null,
)

enum class Severity { INFO, WARNING, CRITICAL }

enum class EventType {
    DEVICE_OFFLINE,
    DEVICE_ONLINE,
    AUTH_FAILED,
    DATA_STALE,
    UNSUPPORTED_API,
    SENSOR_UNAVAILABLE,
    NO_FLOW_WHILE_ON,
    FLOW_WHILE_OFF,
    HIGH_FLOW,
    WEAK_SIGNAL,
    DEVICE_REBOOT,
    PUMP_STATE_CHANGED,
    PUMP_LOCK_CHANGED,
    PUMP_STATUS_CONTRADICTION,
    PUMP_COMMAND,
    CALIBRATION_SAVED,
    FIRMWARE_BOOT,
    FIRMWARE_WARNING,
    FIRMWARE_LEAK,
    FIRMWARE_SENSOR_FAULT,
    FIRMWARE_ACKNOWLEDGED,
    FIRMWARE_RESET,
    FIRMWARE_SETTINGS,
    FIRMWARE_WIFI,
    FIRMWARE_COMMAND_REJECTED,
    FIRMWARE_INFO,
}

data class EventRecord(
    val id: Long,
    val tMs: Long,
    val severity: Severity,
    val type: EventType,
    val message: String,
    val acknowledged: Boolean = false,
)

enum class ThemeMode { SYSTEM, LIGHT, DARK }
enum class VolumeUnit { LITERS, US_GALLONS }
enum class LinkState { NOT_CONFIGURED, CONNECTING, ONLINE, STALE, OFFLINE, AUTH_REQUIRED, UNSUPPORTED }

data class DeviceSnapshot(
    val status: DeviceStatus? = null,
    val lastSuccessMs: Long? = null,
    val lastAttemptMs: Long? = null,
    val consecutiveFailures: Int = 0,
    val lastError: ApiError? = null,
    val lastLatencyMs: Long? = null,
    val successCount: Int = 0,
    val failureCount: Int = 0,
    val internalError: String? = null,
    val firmwareEvents: List<FirmwareEvent> = emptyList(),
)
