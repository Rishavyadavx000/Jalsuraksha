package com.jalsuraksha.app.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.MutablePreferences
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.doublePreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import java.io.IOException

private val Context.jalDataStore: DataStore<Preferences> by preferencesDataStore(name = "jal_settings")

/** Non-secret preferences. The password is NOT here; see SecretStore. */
data class AppSettings(
    val onboardingDone: Boolean = false,
    val deviceName: String = "JAL-SURAKSHA",
    val host: String = "",
    val port: Int = EndpointValidator.DEFAULT_PORT,
    /** Optional HTTP Basic Auth username for legacy V2 firmware; blank disables Basic Auth. */
    val username: String = "",
    val statusPath: String = ApiContract.DEFAULT_STATUS_PATH,
    val eventsPath: String = ApiContract.DEFAULT_EVENTS_PATH,
    val commandPath: String = ApiContract.DEFAULT_COMMAND_PATH,
    /** Legacy v0.2 fields retained only for DataStore migration; v0.3 firmware uses commandPath. */
    val pumpOnPath: String = ApiContract.DEFAULT_COMMAND_PATH,
    val pumpOffPath: String = ApiContract.DEFAULT_COMMAND_PATH,
    val pollIntervalSec: Int = 3,
    val staleAfterSec: Int = 10,
    val historyIntervalSec: Int = 10,
    val retentionDays: Int = 7,
    val highFlowLpm: Double = 20.0,
    val noFlowGraceSec: Int = 20,
    val flowWhileOffLpm: Double = 0.5,
    val flowWhileOffGraceSec: Int = 15,
    val weakSignalDbm: Int = -80,
    val theme: ThemeMode = ThemeMode.SYSTEM,
    val unit: VolumeUnit = VolumeUnit.LITERS,
    /**
     * App-side precondition for sending any pump request (ON or OFF). Off by default: the person turns it on
     * only after checking the firmware API and bench-testing the pump. It never overrides the firmware's own lock.
     */
    val pumpRequestsEnabled: Boolean = false,
    /** App-side correction factor from the calibration wizard (measured / reported). */
    val calFactor: Double = 1.0,
    val calApplied: Boolean = false,
    val calDateMs: Long = 0L,
    /** Legacy v0.2 migration field only. Firmware v1 owns separate K_A and K_B calibration values. */
    val calFirmwarePpl: Double = 0.0,
    val calSuggestedPpl: Double = 0.0,
) {
    val isConfigured: Boolean get() = host.isNotBlank()

    /** 1.0 unless the person chose to apply the app-side calibration to displayed values. */
    val calibrationFactorInUse: Double
        get() = if (calApplied && calFactor in 0.2..5.0) calFactor else 1.0

    val addressDisplay: String
        get() = if (host.isBlank()) "" else EndpointValidator.displayAddress(host, port)
}

/** Clamps stored values so a corrupted preference can never produce a zero poll interval or similar. */
fun AppSettings.sanitized(): AppSettings = copy(
    port = port.coerceIn(1, 65535),
    pollIntervalSec = pollIntervalSec.coerceIn(1, 60),
    staleAfterSec = staleAfterSec.coerceIn(5, 300),
    historyIntervalSec = historyIntervalSec.coerceIn(2, 600),
    retentionDays = retentionDays.coerceIn(1, 90),
    highFlowLpm = highFlowLpm.coerceIn(0.5, 100.0),
    noFlowGraceSec = noFlowGraceSec.coerceIn(5, 600),
    flowWhileOffLpm = flowWhileOffLpm.coerceIn(0.05, 20.0),
    flowWhileOffGraceSec = flowWhileOffGraceSec.coerceIn(5, 600),
    weakSignalDbm = weakSignalDbm.coerceIn(-100, -40),
    calFirmwarePpl = if (calFirmwarePpl.isFinite() && calFirmwarePpl >= 0.0) calFirmwarePpl else 0.0,
)

private object Keys {
    val ONBOARDING_DONE = booleanPreferencesKey("onboarding_done")
    val DEVICE_NAME = stringPreferencesKey("device_name")
    val HOST = stringPreferencesKey("host")
    val PORT = intPreferencesKey("port")
    val USERNAME = stringPreferencesKey("username")
    val STATUS_PATH = stringPreferencesKey("status_path")
    val EVENTS_PATH = stringPreferencesKey("events_path")
    val COMMAND_PATH = stringPreferencesKey("command_path")
    val PUMP_ON_PATH = stringPreferencesKey("pump_on_path")
    val PUMP_OFF_PATH = stringPreferencesKey("pump_off_path")
    val POLL_INTERVAL = intPreferencesKey("poll_interval_sec")
    val STALE_AFTER = intPreferencesKey("stale_after_sec")
    val HISTORY_INTERVAL = intPreferencesKey("history_interval_sec")
    val RETENTION_DAYS = intPreferencesKey("retention_days")
    val HIGH_FLOW = doublePreferencesKey("high_flow_lpm")
    val NO_FLOW_GRACE = intPreferencesKey("no_flow_grace_sec")
    val FLOW_OFF_LPM = doublePreferencesKey("flow_while_off_lpm")
    val FLOW_OFF_GRACE = intPreferencesKey("flow_while_off_grace_sec")
    val WEAK_SIGNAL = intPreferencesKey("weak_signal_dbm")
    val THEME = stringPreferencesKey("theme")
    val UNIT = stringPreferencesKey("unit")
    val PUMP_REQUESTS = booleanPreferencesKey("pump_requests_enabled")
    val CAL_FACTOR = doublePreferencesKey("cal_factor")
    val CAL_APPLIED = booleanPreferencesKey("cal_applied")
    val CAL_DATE = longPreferencesKey("cal_date_ms")
    val CAL_FW_PPL = doublePreferencesKey("cal_firmware_ppl")
    val CAL_SUGGESTED_PPL = doublePreferencesKey("cal_suggested_ppl")
}

private inline fun <reified E : Enum<E>> Preferences.enumOr(key: Preferences.Key<String>, default: E): E {
    val raw = this[key] ?: return default
    return enumValues<E>().firstOrNull { it.name == raw } ?: default
}

private fun Preferences.toSettings(): AppSettings {
    val d = AppSettings()
    return AppSettings(
        onboardingDone = this[Keys.ONBOARDING_DONE] ?: d.onboardingDone,
        deviceName = this[Keys.DEVICE_NAME] ?: d.deviceName,
        host = this[Keys.HOST] ?: d.host,
        port = this[Keys.PORT] ?: d.port,
        username = this[Keys.USERNAME] ?: d.username,
        statusPath = this[Keys.STATUS_PATH] ?: d.statusPath,
        eventsPath = this[Keys.EVENTS_PATH] ?: d.eventsPath,
        commandPath = this[Keys.COMMAND_PATH] ?: d.commandPath,
        pumpOnPath = this[Keys.PUMP_ON_PATH] ?: d.pumpOnPath,
        pumpOffPath = this[Keys.PUMP_OFF_PATH] ?: d.pumpOffPath,
        pollIntervalSec = this[Keys.POLL_INTERVAL] ?: d.pollIntervalSec,
        staleAfterSec = this[Keys.STALE_AFTER] ?: d.staleAfterSec,
        historyIntervalSec = this[Keys.HISTORY_INTERVAL] ?: d.historyIntervalSec,
        retentionDays = this[Keys.RETENTION_DAYS] ?: d.retentionDays,
        highFlowLpm = this[Keys.HIGH_FLOW] ?: d.highFlowLpm,
        noFlowGraceSec = this[Keys.NO_FLOW_GRACE] ?: d.noFlowGraceSec,
        flowWhileOffLpm = this[Keys.FLOW_OFF_LPM] ?: d.flowWhileOffLpm,
        flowWhileOffGraceSec = this[Keys.FLOW_OFF_GRACE] ?: d.flowWhileOffGraceSec,
        weakSignalDbm = this[Keys.WEAK_SIGNAL] ?: d.weakSignalDbm,
        theme = enumOr(Keys.THEME, d.theme),
        unit = enumOr(Keys.UNIT, d.unit),
        pumpRequestsEnabled = this[Keys.PUMP_REQUESTS] ?: d.pumpRequestsEnabled,
        calFactor = this[Keys.CAL_FACTOR] ?: d.calFactor,
        calApplied = this[Keys.CAL_APPLIED] ?: d.calApplied,
        calDateMs = this[Keys.CAL_DATE] ?: d.calDateMs,
        calFirmwarePpl = this[Keys.CAL_FW_PPL] ?: d.calFirmwarePpl,
        calSuggestedPpl = this[Keys.CAL_SUGGESTED_PPL] ?: d.calSuggestedPpl,
    ).sanitized()
}

private fun MutablePreferences.write(s: AppSettings) {
    this[Keys.ONBOARDING_DONE] = s.onboardingDone
    this[Keys.DEVICE_NAME] = s.deviceName
    this[Keys.HOST] = s.host
    this[Keys.PORT] = s.port
    this[Keys.USERNAME] = s.username
    this[Keys.STATUS_PATH] = s.statusPath
    this[Keys.EVENTS_PATH] = s.eventsPath
    this[Keys.COMMAND_PATH] = s.commandPath
    this[Keys.PUMP_ON_PATH] = s.pumpOnPath
    this[Keys.PUMP_OFF_PATH] = s.pumpOffPath
    this[Keys.POLL_INTERVAL] = s.pollIntervalSec
    this[Keys.STALE_AFTER] = s.staleAfterSec
    this[Keys.HISTORY_INTERVAL] = s.historyIntervalSec
    this[Keys.RETENTION_DAYS] = s.retentionDays
    this[Keys.HIGH_FLOW] = s.highFlowLpm
    this[Keys.NO_FLOW_GRACE] = s.noFlowGraceSec
    this[Keys.FLOW_OFF_LPM] = s.flowWhileOffLpm
    this[Keys.FLOW_OFF_GRACE] = s.flowWhileOffGraceSec
    this[Keys.WEAK_SIGNAL] = s.weakSignalDbm
    this[Keys.THEME] = s.theme.name
    this[Keys.UNIT] = s.unit.name
    this[Keys.PUMP_REQUESTS] = s.pumpRequestsEnabled
    this[Keys.CAL_FACTOR] = s.calFactor
    this[Keys.CAL_APPLIED] = s.calApplied
    this[Keys.CAL_DATE] = s.calDateMs
    this[Keys.CAL_FW_PPL] = s.calFirmwarePpl
    this[Keys.CAL_SUGGESTED_PPL] = s.calSuggestedPpl
}

class SettingsRepository(context: Context) {
    private val store: DataStore<Preferences> = context.applicationContext.jalDataStore

    val settings: Flow<AppSettings> = store.data
        .catch { e ->
            if (e is IOException) emit(emptyPreferences()) else throw e
        }
        .map { it.toSettings() }
        .distinctUntilChanged()

    suspend fun update(transform: (AppSettings) -> AppSettings) {
        store.edit { prefs -> prefs.write(transform(prefs.toSettings()).sanitized()) }
    }

    suspend fun reset() {
        store.edit { it.clear() }
    }
}
