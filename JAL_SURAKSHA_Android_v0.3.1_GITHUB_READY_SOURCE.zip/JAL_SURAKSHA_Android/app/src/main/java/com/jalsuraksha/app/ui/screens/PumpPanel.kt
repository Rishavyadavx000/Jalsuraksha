package com.jalsuraksha.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.selection.toggleable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import com.jalsuraksha.app.data.FirmwarePumpPermission
import com.jalsuraksha.app.data.LinkState
import com.jalsuraksha.app.data.PumpState
import com.jalsuraksha.app.domain.Formats
import com.jalsuraksha.app.domain.PumpGatePolicy
import com.jalsuraksha.app.ui.CommandOutcome
import com.jalsuraksha.app.ui.PumpCommandUi
import com.jalsuraksha.app.ui.UiSnapshot
import com.jalsuraksha.app.ui.components.InfoBanner
import com.jalsuraksha.app.ui.components.InterlockChain
import com.jalsuraksha.app.ui.components.JalButton
import com.jalsuraksha.app.ui.components.JalCard
import com.jalsuraksha.app.ui.components.JalDangerButton
import com.jalsuraksha.app.ui.components.StatusChip
import com.jalsuraksha.app.ui.components.Tone
import com.jalsuraksha.app.ui.theme.JalSpacing

/**
 * Pump state, firmware permission and the two requests. ON needs: fresh data, firmware permission
 * ENABLED, a known pump state, and an explicit confirmation. The panel only ever says "requested";
 * it reports success only after the device itself reports the new state.
 */
@Composable
fun PumpControlPanel(
    ui: UiSnapshot,
    onRequest: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
    showChain: Boolean = false,
    onDismissResult: (() -> Unit)? = null,
) {
    val status = ui.status
    val pump = status?.pump ?: PumpState.UNKNOWN
    val permission = status?.pumpPermission ?: FirmwarePumpPermission.UNKNOWN
    val inProgress = ui.pumpCommand is PumpCommandUi.InProgress
    val gate = PumpGatePolicy.evaluate(ui.link, status, inProgress, ui.settings.pumpRequestsEnabled)
    val live = ui.link == LinkState.ONLINE
    var confirmOn by rememberSaveable { mutableStateOf(false) }

    LaunchedEffect(gate.canRequestOn) {
        if (!gate.canRequestOn) confirmOn = false
    }

    // Stale, offline or missing data is never shown as a pump state: the headline becomes UNKNOWN.
    val shownPump = if (live) pump else PumpState.UNKNOWN
    val stateLabel = when (shownPump) {
        PumpState.ON -> "Pump ON"
        PumpState.OFF -> "Pump OFF"
        PumpState.UNKNOWN -> "Pump state unknown"
    }

    JalCard(modifier) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Pump", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
            when (permission) {
                FirmwarePumpPermission.ENABLED ->
                    StatusChip("Control enabled", Tone.SUCCESS, icon = Icons.Filled.LockOpen)
                FirmwarePumpPermission.LOCKED ->
                    StatusChip("Control locked", Tone.NEUTRAL, icon = Icons.Filled.Lock)
                FirmwarePumpPermission.UNKNOWN ->
                    StatusChip("Permission unknown", Tone.WARNING, icon = Icons.Filled.Warning)
            }
        }
        Spacer(Modifier.height(JalSpacing.sm))
        Text(
            stateLabel,
            style = MaterialTheme.typography.headlineMedium,
            color = if (live) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
        )
        if (!live) {
            val age = ui.ageMs
            val lastReported = if (status != null && age != null) {
                "Last reported ${pump.name} ${Formats.age(age)}. "
            } else {
                ""
            }
            Text(
                "${lastReported}Connection: ${Formats.linkLabel(ui.link).lowercase()}.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        if (status?.calibrated != true) {
            Spacer(Modifier.height(JalSpacing.sm))
            InfoBanner(
                tone = Tone.WARNING,
                title = "Leak comparison not calibrated",
                message = "The firmware reports cal=false. It permits a limited uncalibrated run after START, but leak-detection comparison is unavailable. Calibrate both sensors before normal use.",
                icon = Icons.Filled.Warning,
            )
        }
        if (!status?.stopReason.isNullOrBlank()) {
            Spacer(Modifier.height(JalSpacing.xs))
            Text("Last stop: ${status?.stopReason}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (showChain) {
            Spacer(Modifier.height(JalSpacing.lg))
            InterlockChain(gate.checks)
        }

        Spacer(Modifier.height(JalSpacing.lg))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(JalSpacing.md),
        ) {
            JalButton(
                text = "Turn on",
                onClick = { confirmOn = true },
                enabled = gate.canRequestOn,
                icon = Icons.Filled.PowerSettingsNew,
                modifier = Modifier.weight(1f).testTag("pump_on_button"),
            )
            JalDangerButton(
                text = "Turn off",
                onClick = { onRequest(false) },
                enabled = gate.canRequestOff,
                icon = Icons.Filled.PowerSettingsNew,
                modifier = Modifier.weight(1f).testTag("pump_off_button"),
            )
        }

        val onReason = gate.onBlockedReason
        if (!gate.canRequestOn && onReason != null) {
            Spacer(Modifier.height(JalSpacing.sm))
            Row(verticalAlignment = Alignment.Top) {
                Icon(
                    Icons.Filled.Lock,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(16.dp),
                )
                Spacer(Modifier.width(6.dp))
                Text(
                    onReason,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.testTag("pump_on_reason"),
                )
            }
        }
        val offReason = gate.offBlockedReason
        if (!gate.canRequestOff && offReason != null) {
            Spacer(Modifier.height(4.dp))
            Text(
                offReason,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        when (val cmd = ui.pumpCommand) {
            is PumpCommandUi.Idle -> Unit
            is PumpCommandUi.InProgress -> {
                Spacer(Modifier.height(JalSpacing.md))
                LinearProgressIndicator(Modifier.fillMaxWidth())
                Spacer(Modifier.height(4.dp))
                Text(
                    "${cmd.actionLabel}: waiting for a fresh device status...",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            is PumpCommandUi.Done -> {
                if (ui.nowMs - cmd.atMs < RESULT_VISIBLE_MS) {
                    Spacer(Modifier.height(JalSpacing.md))
                    val (tone, title, icon) = when (cmd.outcome) {
                        CommandOutcome.CONFIRMED -> Triple(Tone.SUCCESS, "${cmd.actionLabel}: verified", Icons.Filled.CheckCircle)
                        CommandOutcome.NOT_CONFIRMED -> Triple(Tone.WARNING, "${cmd.actionLabel}: not confirmed", Icons.Filled.Warning)
                        CommandOutcome.REJECTED -> Triple(Tone.WARNING, "${cmd.actionLabel}: rejected", Icons.Filled.Warning)
                        CommandOutcome.FAILED -> Triple(Tone.DANGER, "${cmd.actionLabel}: failed", Icons.Filled.Error)
                        CommandOutcome.BLOCKED -> Triple(Tone.INFO, "${cmd.actionLabel}: blocked", Icons.Filled.Info)
                    }
                    InfoBanner(
                        tone = tone,
                        title = title,
                        message = cmd.message,
                        icon = icon,
                        action = if (onDismissResult != null) {
                            { TextButton(onClick = onDismissResult) { Text("Dismiss") } }
                        } else {
                            null
                        },
                    )
                }
            }
        }
    }

    if (confirmOn) {
        ConfirmStartDialog(
            onConfirm = {
                confirmOn = false
                onRequest(true)
            },
            onCancel = { confirmOn = false },
        )
    }
}

@Composable
private fun ConfirmStartDialog(onConfirm: () -> Unit, onCancel: () -> Unit) {
    var verified by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onCancel,
        title = { Text("Request the pump to start?") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(JalSpacing.md)) {
                Text(
                    "Your firmware confirms that the control token is set, relay polarity is verified and pump state is OFF. " +
                        "Running a pump without water can damage it. This app cannot stop the pump if the phone or Wi-Fi disconnects. Keep a physical power cutoff available.",
                    style = MaterialTheme.typography.bodyMedium,
                )
                Row(
                    modifier = Modifier.toggleable(
                        value = verified,
                        onValueChange = { verified = it },
                        role = Role.Checkbox,
                    ),
                    verticalAlignment = Alignment.Top,
                ) {
                    Checkbox(checked = verified, onCheckedChange = null)
                    Spacer(Modifier.width(JalSpacing.sm))
                    Text(
                        "I have checked the wiring and water supply, and I can switch the pump off at its power supply.",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onConfirm, enabled = verified) { Text("Request ON") }
        },
        dismissButton = {
            TextButton(onClick = onCancel) { Text("Cancel") }
        },
    )
}

private const val RESULT_VISIBLE_MS = 120_000L
