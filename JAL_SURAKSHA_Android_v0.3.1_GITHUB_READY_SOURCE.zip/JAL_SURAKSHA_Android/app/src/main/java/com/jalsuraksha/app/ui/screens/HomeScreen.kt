package com.jalsuraksha.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.jalsuraksha.app.data.LinkState
import com.jalsuraksha.app.data.Severity
import com.jalsuraksha.app.data.userMessage
import com.jalsuraksha.app.domain.ChartPoint
import com.jalsuraksha.app.domain.Formats
import com.jalsuraksha.app.domain.FlowSeries
import com.jalsuraksha.app.ui.EventText
import com.jalsuraksha.app.ui.UiSnapshot
import com.jalsuraksha.app.ui.components.InfoBanner
import com.jalsuraksha.app.ui.components.JalButton
import com.jalsuraksha.app.ui.components.JalCard
import com.jalsuraksha.app.ui.components.JalOutlinedButton
import com.jalsuraksha.app.ui.components.LineChart
import com.jalsuraksha.app.ui.components.MetricTile
import com.jalsuraksha.app.ui.components.ScreenHeader
import com.jalsuraksha.app.ui.components.Tone
import com.jalsuraksha.app.ui.theme.Jal
import com.jalsuraksha.app.ui.theme.JalShapes
import com.jalsuraksha.app.ui.theme.JalSpacing

@Composable
fun HomeScreen(
    ui: UiSnapshot,
    onRefresh: () -> Unit,
    onRequestPump: (Boolean) -> Unit,
    onOpenPump: () -> Unit,
    onOpenEvents: () -> Unit,
    onSetupDevice: () -> Unit,
    onOpenDiagnostics: () -> Unit,
) {
    val unit = ui.settings.unit
    val stale = ui.link != LinkState.ONLINE

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
    ) {
        ScreenHeader(
            title = "JAL-SURAKSHA",
            subtitle = if (ui.settings.isConfigured) ui.settings.deviceName else "Smart water management",
            trailing = {
                IconButton(onClick = onOpenEvents) {
                    BadgedBox(badge = { if (ui.attentionCount > 0) Badge() }) {
                        Icon(Icons.Filled.Notifications, contentDescription = "Events")
                    }
                }
            },
        )
        Column(
            modifier = Modifier.padding(horizontal = JalSpacing.lg),
            verticalArrangement = Arrangement.spacedBy(JalSpacing.md),
        ) {
            ConnectionHero(ui, onClick = onOpenDiagnostics)

            StatusBanners(ui, onSetupDevice = onSetupDevice, onOpenEvents = onOpenEvents)

            Row(horizontalArrangement = Arrangement.spacedBy(JalSpacing.md)) {
                MetricTile(
                    label = if (ui.status?.calibrated == true) "Sensor A flow" else "Sensor A pulse rate",
                    value = if (ui.status?.calibrated == true) Formats.flow(ui.flowLpm, unit) else Formats.decimal(ui.rateAHz, 1),
                    unit = if (ui.status?.calibrated == true) Formats.flowUnit(unit) else "Hz",
                    modifier = Modifier.weight(1f),
                    caption = metricCaption(ui, ui.flowLpm != null),
                    dimmed = stale,
                )
                MetricTile(
                    label = if (ui.status?.calibrated == true) "Sensor B flow" else "Sensor B pulse rate",
                    value = if (ui.status?.calibrated == true) Formats.flow(ui.flowBLpm, unit) else Formats.decimal(ui.rateBHz, 1),
                    unit = if (ui.status?.calibrated == true) Formats.flowUnit(unit) else "Hz",
                    modifier = Modifier.weight(1f),
                    caption = metricCaption(ui, ui.flowBLpm != null),
                    dimmed = stale,
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(JalSpacing.md)) {
                MetricTile(
                    label = "Sensor A volume",
                    value = Formats.volume(ui.totalLiters, unit),
                    unit = Formats.volumeUnit(unit),
                    modifier = Modifier.weight(1f),
                    caption = metricCaption(ui, ui.totalLiters != null),
                    dimmed = stale,
                )
                MetricTile(
                    label = "Sensor B volume",
                    value = Formats.volume(ui.totalBLiters, unit),
                    unit = Formats.volumeUnit(unit),
                    modifier = Modifier.weight(1f),
                    caption = metricCaption(ui, ui.totalBLiters != null),
                    dimmed = stale,
                )
            }
            PipelineStatusCard(ui)
            LiveFlowCard(ui)

            PumpControlPanel(ui = ui, onRequest = onRequestPump)
            TextButton(onClick = onOpenPump) { Text("Pump details and safety checks") }

            Row(horizontalArrangement = Arrangement.spacedBy(JalSpacing.md)) {
                JalOutlinedButton(
                    text = "Refresh now",
                    onClick = onRefresh,
                    icon = Icons.Filled.Refresh,
                    modifier = Modifier.weight(1f),
                )
                JalOutlinedButton(
                    text = "Diagnostics",
                    onClick = onOpenDiagnostics,
                    icon = Icons.Filled.Build,
                    modifier = Modifier.weight(1f),
                )
            }
            Spacer(Modifier.height(JalSpacing.lg))
        }
    }
}

private fun metricCaption(ui: UiSnapshot, hasValue: Boolean): String? = when {
    !hasValue && ui.link == LinkState.ONLINE -> "The device sent no valid value"
    !hasValue -> "No reading yet"
    ui.link != LinkState.ONLINE -> "Last known value (stale)"
    else -> null
}

private fun heroDot(link: LinkState): Color = when (link) {
    LinkState.ONLINE -> Color(0xFF4ADE80)
    LinkState.CONNECTING, LinkState.STALE -> Color(0xFFFBBF24)
    LinkState.OFFLINE, LinkState.AUTH_REQUIRED, LinkState.UNSUPPORTED -> Color(0xFFF87171)
    LinkState.NOT_CONFIGURED -> Color(0xFFB6C8DB)
}

@Composable
private fun ConnectionHero(ui: UiSnapshot, onClick: () -> Unit) {
    val c = Jal.colors
    val age = ui.ageMs
    val freshness = when {
        age != null -> "Updated ${Formats.age(age)}"
        ui.link == LinkState.NOT_CONFIGURED -> "Add your ESP32 to start monitoring"
        ui.link == LinkState.CONNECTING -> "Waiting for the first reading"
        else -> "No reading received yet"
    }
    JalCard(
        onClick = onClick,
        shape = JalShapes.hero,
        containerColor = c.hero,
        borderColor = c.hero,
        contentPadding = 20.dp,
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(10.dp)
                    .background(heroDot(ui.link), CircleShape),
            )
            Spacer(Modifier.width(10.dp))
            Text(
                Formats.linkLabel(ui.link),
                style = MaterialTheme.typography.titleLarge,
                color = c.onHero,
            )
        }
        Spacer(Modifier.height(4.dp))
        Text(freshness, style = MaterialTheme.typography.bodyMedium, color = c.onHeroMuted)
        Spacer(Modifier.height(JalSpacing.lg))
        Row(Modifier.fillMaxWidth()) {
            HeroFact(
                "Signal",
                ui.status?.rssiDbm?.let { "${Formats.signalQuality(it)} ($it dBm)" } ?: "--",
                Modifier.weight(1f),
            )
            HeroFact(
                if (ui.status?.ip != null) "Device IP" else "Configured address",
                ui.status?.ip ?: ui.settings.addressDisplay.ifEmpty { "--" },
                Modifier.weight(1f),
            )
            HeroFact(
                "Response",
                ui.device.lastLatencyMs?.let { "$it ms" } ?: "--",
                Modifier.weight(1f),
            )
        }
    }
}

@Composable
private fun HeroFact(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = Jal.colors.onHeroMuted)
        Text(
            value,
            style = MaterialTheme.typography.bodyMedium,
            color = Jal.colors.onHero,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

@Composable
private fun StatusBanners(ui: UiSnapshot, onSetupDevice: () -> Unit, onOpenEvents: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(JalSpacing.sm)) {
        when (ui.link) {
            LinkState.NOT_CONFIGURED -> InfoBanner(
                tone = Tone.INFO,
                title = "No device set up",
                message = "Add your ESP32's address to start monitoring.",
                action = { JalButton("Set up device", onClick = onSetupDevice) },
            )
            LinkState.AUTH_REQUIRED -> InfoBanner(
                tone = Tone.WARNING,
                title = "Control token rejected",
                message = "The ESP32 rejected the CONTROL_TOKEN or temporarily locked commands after repeated wrong attempts.",
                icon = Icons.Filled.Warning,
                action = { TextButton(onClick = onSetupDevice) { Text("Edit control token") } },
            )
            LinkState.UNSUPPORTED -> InfoBanner(
                tone = Tone.WARNING,
                title = "Unsupported response",
                message = ui.device.lastError?.userMessage() ?: "The device did not answer in the expected format.",
                icon = Icons.Filled.Warning,
            )
            LinkState.OFFLINE -> InfoBanner(
                tone = Tone.WARNING,
                title = "Device offline",
                message = "Values below are the last known readings. If the pump might be running, switch it off at its power supply.",
                icon = Icons.Filled.Warning,
            )
            LinkState.STALE -> InfoBanner(
                tone = Tone.WARNING,
                title = "Data is stale",
                message = "Waiting for a fresh reading. Do not rely on the values below.",
                icon = Icons.Filled.Warning,
            )
            LinkState.CONNECTING, LinkState.ONLINE -> Unit
        }

        val status = ui.status
        if (ui.link == LinkState.ONLINE && status != null) {
            if (status.contradictoryPump) {
                InfoBanner(
                    tone = Tone.DANGER,
                    title = "Contradictory pump status",
                    message = "The device reports the pump ON while control is locked. The state is shown as unknown. Check the hardware.",
                    icon = Icons.Filled.Error,
                )
            }
            if (status.flowLpm == null) {
                InfoBanner(
                    tone = Tone.WARNING,
                    title = "Flow sensor not reporting",
                    message = "The device did not send a valid flow value.",
                    icon = Icons.Filled.Warning,
                )
            }
        }

        val attention = ui.events
            .filter { !it.acknowledged && it.severity != Severity.INFO }
            .take(2)
        for (e in attention) {
            InfoBanner(
                tone = EventText.severityTone(e.severity),
                title = EventText.title(e.type),
                message = e.message,
                icon = if (e.severity == Severity.CRITICAL) Icons.Filled.Error else Icons.Filled.Warning,
                action = { TextButton(onClick = onOpenEvents) { Text("View events") } },
            )
        }
    }
}

@Composable
private fun LiveFlowCard(ui: UiSnapshot) {
    val unit = ui.settings.unit
    val windowMs = 10L * 60_000L
    val start = ui.nowMs - windowMs
    val points = ui.recent.mapNotNull { s ->
        val f = s.flowLpm
        if (f != null && s.tMs >= start) ChartPoint(s.tMs, Formats.flowValue(f, unit)) else null
    }
    val gapMs = maxOf(ui.settings.pollIntervalSec * 3_000L, 12_000L)
    JalCard {
        Text("Flow, last 10 minutes", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(JalSpacing.sm))
        LineChart(
            series = FlowSeries(points, gapMs),
            startMs = start,
            endMs = ui.nowMs,
            unit = Formats.flowUnit(unit),
            description = "Line chart of flow rate over the last 10 minutes",
            startLabel = "10 min ago",
            endLabel = "now",
        )
        Spacer(Modifier.height(4.dp))
        Text(
            "Real readings only. A break in the line means the app received nothing.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}
