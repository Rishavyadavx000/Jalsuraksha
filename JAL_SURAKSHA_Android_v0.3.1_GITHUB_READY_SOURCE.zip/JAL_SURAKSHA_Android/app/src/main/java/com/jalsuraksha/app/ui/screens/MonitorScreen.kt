package com.jalsuraksha.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.jalsuraksha.app.data.LinkState
import com.jalsuraksha.app.domain.ChartPoint
import com.jalsuraksha.app.domain.Formats
import com.jalsuraksha.app.domain.FlowSeries
import com.jalsuraksha.app.ui.UiSnapshot
import com.jalsuraksha.app.ui.components.ChipRow
import com.jalsuraksha.app.ui.components.JalCard
import com.jalsuraksha.app.ui.components.JalOutlinedButton
import com.jalsuraksha.app.ui.components.LineChart
import com.jalsuraksha.app.ui.components.MetricTile
import com.jalsuraksha.app.ui.components.ScreenHeader
import com.jalsuraksha.app.ui.components.StatusChip
import com.jalsuraksha.app.ui.components.Tone
import com.jalsuraksha.app.ui.theme.JalSpacing

private val RANGES = listOf(
    "5 min" to 5L * 60_000L,
    "15 min" to 15L * 60_000L,
    "30 min" to 30L * 60_000L,
    "1 hour" to 60L * 60_000L,
)

@Composable
fun MonitorScreen(ui: UiSnapshot, onOpenCalibration: () -> Unit) {
    var rangeIndex by rememberSaveable { mutableStateOf(1) }
    val unit = ui.settings.unit
    val stale = ui.link != LinkState.ONLINE
    val rangeMs = RANGES[rangeIndex].second
    val start = ui.nowMs - rangeMs

    val window = ui.recent.filter { it.tMs >= start }
    val calibrated = ui.status?.calibrated == true
    val points = window.mapNotNull { sample ->
        val f = if (calibrated) sample.flowLpm else null
        if (f != null) ChartPoint(sample.tMs, Formats.flowValue(f, unit)) else null
    }
    val flows = window.mapNotNull { it.flowLpm }
    val average = if (flows.isEmpty()) null else flows.average()
    val peak = flows.maxOrNull()
    val gapMs = maxOf(ui.settings.pollIntervalSec * 3_000L, 12_000L)

    val linkTone = when (ui.link) {
        LinkState.ONLINE -> Tone.SUCCESS
        LinkState.CONNECTING, LinkState.STALE -> Tone.WARNING
        LinkState.OFFLINE, LinkState.AUTH_REQUIRED, LinkState.UNSUPPORTED -> Tone.DANGER
        LinkState.NOT_CONFIGURED -> Tone.NEUTRAL
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
    ) {
        ScreenHeader(
            title = "Live monitor",
            subtitle = ui.ageMs?.let { "Updated ${Formats.age(it)}" } ?: "No reading yet",
            trailing = { StatusChip(Formats.linkLabel(ui.link), linkTone) },
        )
        Column(
            modifier = Modifier.padding(horizontal = JalSpacing.lg),
            verticalArrangement = Arrangement.spacedBy(JalSpacing.md),
        ) {
            ChipRow(
                options = RANGES.mapIndexed { i, r -> r.first to i },
                selected = rangeIndex,
                onSelect = { rangeIndex = it },
            )

            JalCard {
                Text(if (calibrated) "Dual-sensor flow rate" else "Sensor pulse frequency (uncalibrated)", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(JalSpacing.sm))
                if (calibrated) {
                    LineChart(
                        series = FlowSeries(points, gapMs),
                        startMs = start,
                        endMs = ui.nowMs,
                        unit = Formats.flowUnit(unit),
                        description = "Line chart of Sensor A flow rate over the last ${RANGES[rangeIndex].first}",
                        startLabel = Formats.shortClock(start),
                        endLabel = Formats.shortClock(ui.nowMs),
                        height = 220.dp,
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Real readings only. A break in the line means the app received nothing.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                } else {
                    Text(
                        "L/min chart unavailable until both sensors are calibrated in the ESP32. Current live pulse rates are shown below in Hz.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(JalSpacing.md)) {
                MetricTile(
                    label = if (calibrated) "Sensor A now" else "Sensor A rate",
                    value = if (calibrated) Formats.flow(ui.flowLpm, unit) else Formats.decimal(ui.rateAHz, 1),
                    unit = if (calibrated) Formats.flowUnit(unit) else "Hz",
                    modifier = Modifier.weight(1f),
                    caption = if (stale) "Last known (stale)" else null,
                    dimmed = stale,
                )
                MetricTile(
                    label = if (calibrated) "Average A" else "Sensor B rate",
                    value = if (calibrated) Formats.flow(average, unit) else Formats.decimal(ui.rateBHz, 1),
                    unit = if (calibrated) Formats.flowUnit(unit) else "Hz",
                    modifier = Modifier.weight(1f),
                    caption = "This window",
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(JalSpacing.md)) {
                MetricTile(
                    label = if (calibrated) "Peak A" else "Calibration",
                    value = if (calibrated) Formats.flow(peak, unit) else "Required",
                    unit = if (calibrated) Formats.flowUnit(unit) else "",
                    modifier = Modifier.weight(1f),
                    caption = "This window",
                )
                MetricTile(
                    label = "Sensor A total volume",
                    value = Formats.volume(ui.totalLiters, unit),
                    unit = Formats.volumeUnit(unit),
                    modifier = Modifier.weight(1f),
                    caption = "Device counter",
                    dimmed = stale,
                )
            }

            JalCard {
                Text("Sensor and signal", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(JalSpacing.sm))
                val status = ui.status
                StatRow("Sensor A flow", status?.flowALpm?.let { Formats.flow(it, unit) } ?: "No valid reading")
                StatRow("Sensor B flow", status?.flowBLpm?.let { Formats.flow(it, unit) } ?: "No valid reading")
                StatRow("A − B difference", status?.differenceLpm?.let { Formats.flow(it, unit) } ?: "--")
                StatRow("Relative difference", status?.differencePercent?.let { String.format(java.util.Locale.US, "%.1f%%", it) } ?: "--")
                StatRow("Monitored segment", status?.locationEstimate?.takeUnless { it == "-" } ?: "--")
                StatRow("Firmware state", status?.systemState ?: "--")
                StatRow("Leak latch", status?.latch?.takeUnless { it == "none" } ?: "None")
                StatRow("Calibration", if (status?.calibrated == true) "Both sensors calibrated" else "Not calibrated")
                StatRow("Sensor health", status?.sensorHealth ?: "Unknown")
                StatRow("Sensor A / B total", "${Formats.volume(status?.volumeALiters, unit)} / ${Formats.volume(status?.volumeBLiters, unit)}")
                StatRow(
                    "Wi-Fi signal",
                    status?.rssiDbm?.let { "${Formats.signalQuality(it)} ($it dBm)" } ?: "--",
                )
                StatRow("Pulse count", "Not provided by the firmware API")
            }

            JalCard {
                Text("Firmware calibration", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(4.dp))
                val status = ui.status
                Text(
                    when {
                        status?.calibrated == true -> "Both flow sensors have firmware-owned calibration values. K_A=${status.firmwareConfig?.kA?.let { String.format(java.util.Locale.US, "%.1f", it) } ?: "--"} pulses/L, K_B=${status.firmwareConfig?.kB?.let { String.format(java.util.Locale.US, "%.1f", it) } ?: "--"} pulses/L."
                        status == null -> "Connect to the ESP32 to read Sensor A and Sensor B calibration values."
                        else -> "The firmware reports that flow calibration is incomplete. Leak comparison remains disabled until both sensors are calibrated."
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(JalSpacing.md))
                JalOutlinedButton(
                    text = "Calibration wizard",
                    onClick = onOpenCalibration,
                    icon = Icons.Filled.Build,
                )
            }
            Spacer(Modifier.height(JalSpacing.lg))
        }
    }
}
