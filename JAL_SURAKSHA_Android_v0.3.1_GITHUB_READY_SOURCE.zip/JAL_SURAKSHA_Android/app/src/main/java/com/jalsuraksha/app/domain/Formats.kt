package com.jalsuraksha.app.domain

import com.jalsuraksha.app.data.LinkState
import com.jalsuraksha.app.data.VolumeUnit
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Display formatting. Missing values are always "--", never "0". */
object Formats {
    const val LITERS_PER_US_GALLON = 3.785411784

    fun flowValue(lpm: Double, unit: VolumeUnit): Double =
        if (unit == VolumeUnit.LITERS) lpm else lpm / LITERS_PER_US_GALLON

    fun volumeValue(liters: Double, unit: VolumeUnit): Double =
        if (unit == VolumeUnit.LITERS) liters else liters / LITERS_PER_US_GALLON

    fun flowUnit(unit: VolumeUnit): String = if (unit == VolumeUnit.LITERS) "L/min" else "gal/min"

    fun volumeUnit(unit: VolumeUnit): String = if (unit == VolumeUnit.LITERS) "L" else "gal"

    fun flow(lpm: Double?, unit: VolumeUnit, locale: Locale = Locale.getDefault()): String =
        if (lpm == null) "--" else String.format(locale, "%.2f", flowValue(lpm, unit))

    fun decimal(value: Double?, places: Int = 1, locale: Locale = Locale.getDefault()): String =
        if (value == null || !value.isFinite()) "--" else String.format(locale, "%1$.${places.coerceIn(0, 4)}f", value)

    fun volume(liters: Double?, unit: VolumeUnit, locale: Locale = Locale.getDefault()): String {
        if (liters == null) return "--"
        val v = volumeValue(liters, unit)
        // 3 decimals matches the sensor's pulse resolution; large totals drop to 1 decimal.
        return String.format(locale, if (v >= 1000.0) "%.1f" else "%.3f", v)
    }

    fun age(ms: Long): String {
        val s = ms / 1000
        return when {
            s < 1 -> "just now"
            s < 60 -> "$s s ago"
            s < 3600 -> "${s / 60} min ago"
            s < 86400 -> "${s / 3600} h ago"
            else -> "${s / 86400} d ago"
        }
    }

    fun duration(ms: Long): String {
        val totalSec = ms / 1000
        val h = totalSec / 3600
        val m = (totalSec % 3600) / 60
        val s = totalSec % 60
        return when {
            h > 0 -> "$h h ${m.toString().padStart(2, '0')} min"
            m > 0 -> "$m min ${s.toString().padStart(2, '0')} s"
            else -> "$s s"
        }
    }

    fun clock(tMs: Long, locale: Locale = Locale.getDefault()): String =
        SimpleDateFormat("HH:mm:ss", locale).format(Date(tMs))

    fun shortClock(tMs: Long, locale: Locale = Locale.getDefault()): String =
        SimpleDateFormat("HH:mm", locale).format(Date(tMs))

    fun dateTime(tMs: Long, locale: Locale = Locale.getDefault()): String =
        SimpleDateFormat("d MMM, HH:mm", locale).format(Date(tMs))

    fun day(tMs: Long, locale: Locale = Locale.getDefault()): String =
        SimpleDateFormat("d MMM", locale).format(Date(tMs))

    fun signalQuality(dbm: Int?): String = when {
        dbm == null -> "Unknown"
        dbm >= -60 -> "Excellent"
        dbm >= -70 -> "Good"
        dbm >= -80 -> "Fair"
        else -> "Weak"
    }

    fun linkLabel(link: LinkState): String = when (link) {
        LinkState.NOT_CONFIGURED -> "No device set up"
        LinkState.CONNECTING -> "Connecting"
        LinkState.ONLINE -> "Online"
        LinkState.STALE -> "Data is stale"
        LinkState.OFFLINE -> "Offline"
        LinkState.AUTH_REQUIRED -> "Control token rejected"
        LinkState.UNSUPPORTED -> "Unsupported response"
    }
}
