package com.jalsuraksha.app.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.Call
import okhttp3.Credentials
import okhttp3.Callback
import okhttp3.Dns
import okhttp3.FormBody
import okhttp3.HttpUrl
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import java.io.IOException
import java.io.InterruptedIOException
import java.net.InetAddress
import java.net.UnknownHostException
import java.util.concurrent.TimeUnit
import kotlin.coroutines.cancellation.CancellationException
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** Control token is kept only in memory while a request is built; logs/toString never reveal it. */
class DeviceCredentials(val controlToken: String) {
    val isUsable: Boolean get() = controlToken.length >= 8 && controlToken != "CHANGE_ME_TOKEN"
    override fun toString(): String = "DeviceCredentials(controlToken=<redacted>, usable=$isUsable)"
}

/** HTTP Basic credentials for the older V2 dashboard firmware; never included in logs. */
class BasicAuthCredentials(val username: String, val password: String) {
    val isUsable: Boolean get() = username.isNotBlank() && password.isNotEmpty()
    override fun toString(): String = "BasicAuthCredentials(username=<redacted>, password=<redacted>, usable=$isUsable)"
}

class Endpoint(
    val host: String,
    val port: Int,
    val statusPath: String = ApiContract.DEFAULT_STATUS_PATH,
    val eventsPath: String = ApiContract.DEFAULT_EVENTS_PATH,
    val commandPath: String = ApiContract.DEFAULT_COMMAND_PATH,
    val credentials: DeviceCredentials? = null,
    val basicAuth: BasicAuthCredentials? = null,
) {
    override fun toString(): String =
        "Endpoint(${EndpointValidator.baseUrl(host, port)}, hasControlToken=${credentials?.isUsable == true}, hasBasicAuth=${basicAuth?.isUsable == true})"
}

data class FirmwareCommandReply(val accepted: Boolean, val message: String)

object LocalOnlyDns : Dns {
    override fun lookup(hostname: String): List<InetAddress> {
        val local = Dns.SYSTEM.lookup(hostname).filter { EndpointValidator.isLocalAddress(it) }
        if (local.isEmpty()) throw UnknownHostException("$hostname did not resolve to a private or link-local address")
        return local
    }
}

/** HTTP client for bundled Firmware 1.0 plus legacy V2 read-only compatibility.
 * Basic Auth is optional and separate from the V1 POST /api/cmd form control token. */
class DeviceApi(
    client: OkHttpClient = defaultClient(),
    private val hostPolicy: (String) -> Boolean = { EndpointValidator.isAllowedHost(it) },
) {
    private val readClient = client.newBuilder().callTimeout(6, TimeUnit.SECONDS).build()
    private val commandClient = client.newBuilder().callTimeout(8, TimeUnit.SECONDS)
        .retryOnConnectionFailure(false).build()

    suspend fun fetchStatus(ep: Endpoint, clock: () -> Long = { System.currentTimeMillis() }): ApiOutcome<DeviceStatus> =
        when (val raw = request(ep, ep.statusPath, null, readClient)) {
            is Raw.Fail -> ApiOutcome.Failure(raw.error)
            is Raw.Reply -> when {
                raw.code in 200..299 -> when (val parsed = StatusParser.parse(raw.body, clock())) {
                    is ParseResult.Ok -> ApiOutcome.Success(parsed.status, raw.code, raw.latencyMs)
                    is ParseResult.Invalid -> ApiOutcome.Failure(ApiError.BadResponse(parsed.reason))
                }
                // V2 dashboard firmware protects GET /api/status with HTTP Basic Auth.
                // The control token is unrelated and is only used by the V1 command route.
                raw.code == 401 -> ApiOutcome.Failure(ApiError.BasicAuthRequired)
                else -> ApiOutcome.Failure(ApiError.HttpError(raw.code, raw.body.take(200)))
            }
        }

    suspend fun fetchEvents(ep: Endpoint): ApiOutcome<List<FirmwareEvent>> =
        when (val raw = request(ep, ep.eventsPath, null, readClient)) {
            is Raw.Fail -> ApiOutcome.Failure(raw.error)
            is Raw.Reply -> when {
                raw.code in 200..299 -> try {
                    ApiOutcome.Success(StatusParser.parseEvents(raw.body, System.currentTimeMillis()), raw.code, raw.latencyMs)
                } catch (e: IllegalArgumentException) {
                    ApiOutcome.Failure(ApiError.BadResponse(e.message ?: "Invalid event list"))
                }
                raw.code == 401 -> ApiOutcome.Failure(ApiError.BasicAuthRequired)
                else -> ApiOutcome.Failure(ApiError.HttpError(raw.code, raw.body.take(200)))
            }
        }

    suspend fun sendCommand(
        ep: Endpoint,
        command: String,
        params: Map<String, String> = emptyMap(),
    ): ApiOutcome<FirmwareCommandReply> {
        val token = ep.credentials?.controlToken
        if (token.isNullOrBlank() || !ep.credentials.isUsable) {
            return ApiOutcome.Failure(ApiError.FirmwareControlLocked)
        }
        val form = FormBody.Builder()
            .add("t", token)
            .add("c", command)
        params.forEach { (key, value) ->
            if (key in ALLOWED_COMMAND_PARAMS) form.add(key, value)
        }
        return when (val raw = request(ep, ep.commandPath, form.build(), commandClient)) {
            is Raw.Fail -> ApiOutcome.Failure(raw.error)
            is Raw.Reply -> when {
                raw.code == 401 -> ApiOutcome.Failure(ApiError.AuthRequired)
                raw.code == 403 -> ApiOutcome.Failure(ApiError.FirmwareControlLocked)
                raw.code !in 200..299 -> ApiOutcome.Failure(ApiError.HttpError(raw.code, raw.body.take(200)))
                else -> when (val parsed = CommandReplyParser.parse(raw.body)) {
                    is CommandParseResult.Ok -> if (parsed.accepted) {
                        ApiOutcome.Success(FirmwareCommandReply(true, parsed.message), raw.code, raw.latencyMs)
                    } else {
                        ApiOutcome.Failure(ApiError.BadResponse("Firmware rejected '$command': ${parsed.message}"))
                    }
                    is CommandParseResult.Invalid -> ApiOutcome.Failure(ApiError.BadResponse(parsed.reason))
                }
            }
        }
    }

    private sealed interface Raw {
        data class Reply(val code: Int, val body: String, val latencyMs: Long) : Raw
        data class Fail(val error: ApiError) : Raw
    }

    private suspend fun request(ep: Endpoint, path: String, body: okhttp3.RequestBody?, client: OkHttpClient): Raw {
        if (!hostPolicy(ep.host)) return Raw.Fail(ApiError.InvalidEndpoint("${ep.host} is not a private/local network address."))
        val url = try {
            HttpUrl.Builder().scheme("http").host(ep.host).port(ep.port).encodedPath(path).build()
        } catch (_: IllegalArgumentException) {
            return Raw.Fail(ApiError.InvalidEndpoint("The address or API path is not valid."))
        }
        val requestBuilder = Request.Builder().url(url).header("Accept", "application/json")
        ep.basicAuth?.takeIf { it.isUsable }?.let {
            requestBuilder.header("Authorization", Credentials.basic(it.username, it.password))
        }
        if (body == null) requestBuilder.get() else requestBuilder.post(body)
        val startedNs = System.nanoTime()
        return try {
            val response = client.newCall(requestBuilder.build()).await()
            withContext(Dispatchers.IO) {
                response.use { r ->
                    val text = r.peekBody(ApiContract.MAX_BODY_BYTES).string()
                    Raw.Reply(r.code, text, (System.nanoTime() - startedNs) / 1_000_000L)
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (_: InterruptedIOException) {
            Raw.Fail(ApiError.Timeout)
        } catch (_: UnknownHostException) {
            Raw.Fail(ApiError.Unreachable("the host did not resolve to a private/local address"))
        } catch (e: IOException) {
            Raw.Fail(ApiError.Unreachable(e.message ?: e.javaClass.simpleName))
        }
    }

    companion object {
        private val ALLOWED_COMMAND_PARAMS = setOf(
            "l", "kA", "kB", "win", "zero", "abs", "rel", "pers", "base", "ssid", "pass",
        )
        fun defaultClient(): OkHttpClient = OkHttpClient.Builder()
            .connectTimeout(3, TimeUnit.SECONDS)
            .readTimeout(4, TimeUnit.SECONDS)
            .writeTimeout(4, TimeUnit.SECONDS)
            .followRedirects(false)
            .followSslRedirects(false)
            .dns(LocalOnlyDns)
            .build()
    }
}

private suspend fun Call.await(): Response = suspendCancellableCoroutine { cont ->
    cont.invokeOnCancellation { cancel() }
    enqueue(object : Callback {
        override fun onResponse(call: Call, response: Response) {
            if (cont.isActive) cont.resume(response) else response.close()
        }
        override fun onFailure(call: Call, e: IOException) {
            if (cont.isActive) cont.resumeWithException(e)
        }
    })
}
