package com.jalsuraksha.app.domain

/**
 * Flow-sensor calibration maths.
 *
 *   reported = pulses / firmwarePulsesPerLiter
 *   true     = pulses / truePulsesPerLiter
 *   factor   = measured / reported
 *   truePulsesPerLiter = firmwarePulsesPerLiter * reported / measured = firmwarePulsesPerLiter / factor
 *
 * Legacy generic helper for comparing a reported value against an independently measured value.
 * It is not the current dual-sensor firmware calibration path. The active app sends `calzero`
 * and `calsave` to the ESP32, which computes K_A and K_B from actual pulse counters.
 */
object Calibration {
    // No default pulses-per-litre constant is provided: Sensor A and B are calibrated
    // independently by the current ESP32 firmware and must not inherit a draft assumption.

    data class Result(
        val factor: Double,
        val suggestedPulsesPerLiter: Double,
        /** False when the correction is outside 0.5x..2x, which usually means a mistake rather than drift. */
        val plausible: Boolean,
    )

    fun compute(reportedLiters: Double, measuredLiters: Double, firmwarePulsesPerLiter: Double): Result? {
        if (!reportedLiters.isFinite() || !measuredLiters.isFinite() || !firmwarePulsesPerLiter.isFinite()) return null
        if (reportedLiters <= 0.0 || measuredLiters <= 0.0 || firmwarePulsesPerLiter <= 0.0) return null
        val factor = measuredLiters / reportedLiters
        return Result(
            factor = factor,
            suggestedPulsesPerLiter = firmwarePulsesPerLiter / factor,
            plausible = factor in 0.5..2.0,
        )
    }
}
