# JAL-SURAKSHA Android v0.3.1 — legacy V2 HTTP 401 correction

## User-observed issue

- Android `Test connection` returned HTTP 401 for `GET /api/status` at the ESP32 address.
- Chrome on the same address returned JSON containing `wifi`, `ip`, `rssi`, `pump`, `pumpAvailable`, `flowLpm`, and `totalLiters`.
- The Serial USB Terminal screenshot displayed firmware banner `JAL-SURAKSHA V2`.

## Root-cause assessment

The app's previous `DeviceApi` sent no HTTP Authorization header for `GET /api/status`. The earlier V2 firmware draft used `server.authenticate(WEB_USER, WEB_PASSWORD)` on status/dashboard routes. This explains the difference when the browser has cached Basic Auth credentials and the Android app does not. The exact V2 `.ino` currently flashed is not available in this workspace, so this is a strong, evidence-based diagnosis but still needs confirmation against that exact sketch.

## Changes in v0.3.1

- Added optional, separate Basic Auth username/password fields to Device Setup and Settings.
- Encrypted the Basic Auth password with Android Keystore AES-GCM, separately stored from the V1 control token.
- Send the Authorization header only when the user configured both values.
- Map status/events HTTP 401 to `BasicAuthRequired`; continue mapping POST command 401 to `AuthRequired` (control token).
- Parse the observed V2 single-sensor JSON in a strict read-only compatibility path. Skip V1-only `/api/events` polling for V2.
- Keep pump control fail-closed: V2 `pumpAvailable=false` is LOCKED; true is UNKNOWN and never enables commands.
- Add 4 JVM test cases; inventory now 106 JVM + 6 instrumented UI tests.
- Bump app version to 0.3.1 / versionCode 4.

## Verification status

Static test inventory (106 + 6), Kotlin/XML structural check, Firmware 1.0 static contract check and ZIP integrity pass. This environment has no installed Gradle executable/Android SDK, so full Gradle compilation, JVM execution, emulator test execution and APK assembly have not been run for v0.3.1. The exact current V2 `.ino` and credentials also remain unverified.

Do not publish or paste `WEB_USER`, `WEB_PASSWORD`, Wi-Fi credentials or `CONTROL_TOKEN`. Keep V2 compatibility read-only and pump power disconnected until relay/wiring/safety verification is complete.

---

# JAL-SURAKSHA Android v0.3.0 — integration change report

**Prepared:** 12 November 2026
**Android source:** retained v0.2.0 native Kotlin/Jetpack Compose project
**Firmware source reviewed:** `JAL_SURAKSHA (1).ino`, Firmware 1.0, supplied from the user's Library

## Executive summary

The Android project was updated to target the supplied dual-sensor ESP32 firmware rather than the earlier single-flow, Basic-Auth draft. The firmware source is included unchanged under `firmware/JAL_SURAKSHA_Firmware_v1.0.ino`. The Android integration maps status, events and token-protected command routes; it does not modify GPIO assignments, relay flags, secrets or calibration constants in firmware.

The project is **source-integrated, but not yet release-verified against physical hardware**. GitHub Run #19 only verifies the older v0.2.0 checkpoint. v0.3.0 requires its own Actions results.

## Confirmed firmware contract from the supplied sketch

- ESP32 Arduino `WebServer` on port 80.
- `GET /api/status` and `GET /api/events` are unauthenticated read endpoints.
- `POST /api/cmd` is protected by form fields `t` (control token) and `c` (command); it is not HTTP Basic Auth.
- Commands: `start`, `stop`, `ack`, `reset`, `calzero`, `calsave`, `baseline`, `set`, `wifi`.
- Status contains two sensor readings (`fa`, `fb`), difference (`diff`, `pct`), pulse rates (`ra`, `rb`), totals (`va`, `vb`), raw and calibration pulses, state/severity/latch, pump state, calibration flags, Wi-Fi/RSSI/IP and `cfg`.
- The exact sketch defaults to `CONTROL_TOKEN="CHANGE_ME_TOKEN"`, `RELAY_POLARITY_VERIFIED=0`, `DEFAULT_K_A=0`, `DEFAULT_K_B=0`; pump START is therefore locked by firmware by default.
- `PUMP_MAX_RUN_MS=0` means no calibrated maximum run-time limit.

## GitHub Actions Run #22 failure and correction

- Run #22 failed in `:app:compileDebugKotlin` at `HomeScreen.kt:130` with `Unresolved reference: PipelineStatusCard`. The same source compile failure also stopped the emulator UI-test job before the six UI tests ran.
- Added `ui/screens/PipelineStatusCard.kt`, which presents the firmware's own reported state, sensor-health string, leak segment, calibrated flow difference and baseline-capture state. It labels stale values and does not interpret a flow difference alone as a confirmed leak.
- Added the same component as `.github/ci-overrides/PipelineStatusCard.kt` in the GitHub repository and updated all three Gradle jobs in the active `main.yml` to overlay it onto the extracted source before Gradle runs. This lets CI verify the corrected component even while the repository's existing binary source archive is awaiting replacement.
- No pump command, GPIO, relay polarity, calibration constant, firmware safety flag or secret was changed.

## GitHub Actions Run #24 unit-test finding

- After applying the missing `PipelineStatusCard`, the build advanced through compilation. The JVM suite ran 102 tests and reported one failure: `DeviceApiTest.unauthorizedStatusIsReportedAsHttpErrorNotBasicAuthChallenge`.
- Firmware 1.0 specifies unauthenticated `GET /api/status` and `GET /api/events`; the control token is sent only with `POST /api/cmd`. `DeviceApi.fetchStatus()` therefore no longer maps HTTP 401 to `AuthRequired`; it maps all non-2xx status responses to `HttpError`. The command endpoint's HTTP 401 mapping to `AuthRequired` remains unchanged.

## Android changes

- Replaced the old draft API defaults with the actual `GET /api/status`, `GET /api/events`, `POST /api/cmd` routes.
- Implemented dual-sensor JSON parsing, uncalibrated Hz-only display, firmware event parsing, command token handling, `ok:false` rejection handling and status read-back.
- Added firmware calibration wizard based on raw sensor pulse counters and measured litres; no generic pulses-per-litre calibration is assumed.
- Kept existing premium Compose screens, history, event handling, diagnostics and dashboard.
- Kept the app-side pump-request setting OFF by default. The app cannot override the firmware relay/token gate.
- Corrected signed baseline parsing (`cfg.base`) and possible-leak classification; added a regression test.
- Corrected `CommandReplyParser.parse()` from an expression body with illegal non-local `return` to a valid block body after a targeted Kotlin syntax compile caught the error.

## Verification performed locally

| Check | Result |
|---|---|
| Test inventory | 102 JVM + 6 UI test annotations found |
| Kotlin/XML structural checker | 50 Kotlin files, no findings after CI fix |
| Partial pure-Kotlin compile | PASS: 10 pure Kotlin data/domain files with kotlinc 1.9.0, JVM target 17 |
| API parser syntax compile | PASS: Models + ApiModels + ApiContract compiled using temporary JSON API stubs; not a full dependency/runtime test |
| Full Gradle Android build | Not run locally; Gradle and Android SDK are absent |
| JVM test execution | Not run locally |
| UI emulator test execution | Not run locally |
| APK build | Not run locally |
| Firmware Arduino compile | Not run |
| ESP32 / relay / pump hardware test | Not run |

The GitHub workflow is configured to run JVM tests, structural checks, lint, Kotlin compilation, instrumented emulator tests, and then build/upload a Debug APK only if both test jobs succeed. The v0.3.0 Actions run is the acceptance evidence.

## Safety boundary

Do not change `RELAY_POLARITY_VERIFIED`, `CONTROL_TOKEN`, `DEFAULT_K_A`, `DEFAULT_K_B`, relay polarity or GPIO values by assumption. The firmware header itself states that the supplied sketch was not compiled with the real board toolchain and was not hardware-tested. `PUMP_MAX_RUN_MS=0` also needs a finite safe value before unattended or field operation. Keep the pump disconnected until the checklist is completed and keep a physical cutoff available.

## Remaining release actions

1. Push the v0.3.0 source archive and workflows to GitHub.
2. Require `unit-lint-build` and `compose-ui-tests` to pass.
3. Verify the attached JUnit XML shows 102/102 JVM and 6/6 UI tests with no failures, errors or skips.
4. Collect the Debug APK artifact produced by the dependent build job; verify SHA-256 and install manually on an Android phone.
5. Confirm the exact firmware version flashed to ESP32 and test GET-only status/events first with pump power disconnected.
6. Complete relay, sensor-voltage, water/electrical isolation, calibration and controlled bench tests before unlocking pump START.

**Current status:** native app and source-level firmware API integration prepared; v0.3.0 CI/APK and physical hardware verification still pending.

## Final GitHub Actions Run #27 — verified results

- Run URL: https://github.com/Rishavyadavx000/Jalsuraksha/actions/runs/43354216432
- Overall workflow: SUCCESS; all three jobs succeeded: JVM/structural/lint/compile, Compose UI emulator tests, and Debug APK build.
- JUnit XML: 102 JVM tests passed, 0 failed, 0 errors, 0 skipped.
- Instrumented XML: 6 UI tests passed, 0 failed, 0 errors, 0 skipped.
- `clean testDebugUnitTest lintDebug compileDebugKotlin`, `connectedDebugAndroidTest`, and `assembleDebug` all succeeded.
- Android Lint: 12 warnings, 4 informational notices; no errors. Warnings include newer target/dependency suggestions, local cleartext HTTP configuration, Android backup/data-extraction guidance, and launcher monochrome icon.
- Debug APK uploaded as `JAL-SURAKSHA-v0.3.0-debug-apk`; SHA-256: `9ac5109d4b2bc5d054b03f8bee2b59bd916e0fa54170eb370b35fa8a2c747974`.
- The APK was built with the CI-applied `PipelineStatusCard` component and public status-401 mapping correction. The corrected source archive now contains both changes directly.
- ESP32 firmware/API static contract check passed; physical hardware, actual flashed-sketch identity, flow-sensor calibration and relay/pump behavior remain unverified.
