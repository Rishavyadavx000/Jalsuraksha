# ESP32 Firmware audit — supplied `JAL_SURAKSHA (1).ino`

- Firmware header version: 1.0.
- Size reviewed: 66,998 bytes.
- The sketch itself states: not compiled with the actual ESP32 toolchain and not tested on hardware at the time supplied.
- Android integration v0.3.1 targets this sketch's dual-sensor API and command protocol.
- Pins: Sensor A GPIO27, Sensor B GPIO26, Relay GPIO25; OLED 21/22, Buzzer23, Button32, LEDs16/17/18.
- Network: HTTP port80, mDNS `jal-suraksha.local`, setup AP `JAL-SURAKSHA-SETUP`.
- API: `GET /api/status`, `GET /api/events`, `POST /api/cmd`.
- Control: form fields `t` and `c`; no Basic Auth.
- Default safety: token placeholder, relay polarity unverified, both sensor calibration constants zero.
- Runtime: uncalibrated cap 180 s, no-flow stop enabled; calibrated maximum run time is not capped while `PUMP_MAX_RUN_MS=0`.

The Android source does not silently modify the firmware's pins, relay polarity, secrets, calibration values, or runtime limits. User must confirm this exact sketch is flashed and run its compile/bench test sequence.
