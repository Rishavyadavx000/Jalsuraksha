# JAL-SURAKSHA App Icon

The launcher icon uses the artwork supplied for JAL-SURAKSHA. The artwork is inset on a navy canvas to reduce clipping by Android launcher masks.

- API 24-25: anydpi layer-list fallback.
- API 26+: adaptive icon with navy background and the supplied artwork as foreground.
- API 33+: monochrome layer for themed launcher icons.
- The Android manifest continues to reference `@mipmap/ic_launcher`.

This change only updates launcher icon resources. It does not change network, authentication, firmware, pump-control or safety behavior.
