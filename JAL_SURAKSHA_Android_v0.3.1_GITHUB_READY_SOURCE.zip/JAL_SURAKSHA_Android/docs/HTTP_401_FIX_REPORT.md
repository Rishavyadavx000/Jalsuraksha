# JAL-SURAKSHA Android v0.3.1 — HTTP 401 fix

## Root cause
The current ESP32 monitor identifies the running firmware as JAL-SURAKSHA V2. The browser successfully read `/api/status` and received the legacy single-sensor JSON, while the old Android v0.3.0 client sent no HTTP Basic Authorization header. The earlier V2 firmware draft uses `server.authenticate(WEB_USER, WEB_PASSWORD)` for dashboard/status routes. This is the strongest explanation for browser JSON vs app HTTP 401; the exact V2 `.ino` currently flashed was not provided for source confirmation.

## Changes
- Added separate optional WEB_USER / WEB_PASSWORD Basic Auth fields in device setup/settings.
- Password stored encrypted with Android Keystore AES-GCM, separately from CONTROL_TOKEN.
- GET status/events requests add Basic Auth header only when credentials are configured.
- Status/events 401 maps to BasicAuthRequired; POST command 401 remains Control Token rejected.
- Added strict read-only parser for observed legacy V2 fields: wifi, ip, rssi, pump, pumpAvailable, flowLpm, totalLiters.
- V2 skips V1-only /api/events polling and all pump commands stay locked. pumpAvailable=false -> LOCKED; true -> UNKNOWN (never enables control).
- App version 0.3.1 (versionCode 4).

## Local checks
- Test inventory: 106 JVM + 6 instrumented UI annotations.
- Kotlin/XML structural checker: 50 Kotlin files, no findings.
- Firmware 1.0 static API contract checker: PASS (3 routes, 33 status keys, 9 commands, 11 parameters, 5 safety defaults).
- Source ZIP integrity: PASS.

## Not yet verified
This environment has no Gradle executable / Android SDK. Full Gradle compilation, execution of 106 JVM tests, execution of 6 UI tests, and APK build must run in GitHub Actions. The exact currently flashed V2 `.ino` has not been supplied, so WEB_USER/WEB_PASSWORD and route guards still need confirmation from that source. This report does not claim physical ESP32, sensor, relay or pump validation.

## Install / configure
After a new Debug APK is built, enter the current IP, then fill the Basic Auth username/password using `WEB_USER` and `WEB_PASSWORD` from the ESP32 sketch. Leave the separate Firmware Control Token blank for read-only monitoring. Do not post credentials in chat or commit them. Keep pump power disconnected and pump control locked.
