# JAL-SURAKSHA Android v0.3.1 — test plan and status

## Source inventory

- JVM unit test annotations: 106 across 9 Kotlin files.
- Instrumented Compose UI test annotations: 6 across 1 Kotlin file.
- Inventory script: `python3 tools/verify_test_inventory.py`.
- Structural checker: `python3 tools/lint_kt.py .`.
- Firmware/API contract guard: `python3 tools/verify_firmware_contract.py`.

The inventory script counts annotations only. It does not run the tests. The structural checker does not replace Kotlin/Gradle compilation. Current inventory is 106 JVM + 6 instrumented UI test cases.

## v0.3.1 test cases added/updated

- Status parser validates the dual-sensor status schema, treats signed baseline offsets as valid, and does not interpret uncalibrated `fa/fb/va/vb` zero placeholders as actual readings.
- API tests cover GET status/events, POST `/api/cmd`, form token, command parameter allow-list, HTTP errors, `ok:false` rejection, and credential redaction.
- Regression test accepts negative signed baseline values and recognises firmware `possible_leak` / `POSSIBLE LEAK / SENSOR B CHECK` values.
- Pump policy tests preserve the firmware permission gate and safe STOP behavior.
- Static contract guard matches all 3 API routes, 33 status JSON keys, 9 commands, 11 command parameters and 5 safety defaults between the included sketch and Android source.
- Instrumented Pump panel tests check firmware lock, app lock, stale/unknown state, explicit START confirmation and STOP action.

## Verification status

The previous GitHub Run #27/#28 verified v0.3.0 only. They do **not** certify these v0.3.1 authentication and legacy-parser changes.

For v0.3.1, run the `JAL-SURAKSHA Main Verification` GitHub Actions workflow after uploading this source. Required outcomes:

- `testDebugUnitTest`: 106 passed, 0 failed, 0 errors, 0 skipped (expected after CI execution).
- `lintDebug`: inspect warnings and ensure no errors.
- `compileDebugKotlin`: successful.
- `connectedDebugAndroidTest`: 6 passed, 0 failed, 0 errors, 0 skipped.

No v0.3.1 test pass is claimed until the actual CI JUnit XML reports show those results.

## Hardware boundary

Neither unit tests nor emulator UI tests verify that the user has flashed this exact `.ino`, that it compiles with the real Arduino-ESP32 toolchain, that GPIO wiring is correct, or that a pump can be safely operated. See `docs/HARDWARE_SAFETY_CHECKLIST.md`.

## v0.3.1 compatibility coverage

- Basic Auth header is sent only when optional legacy V2 credentials are configured; `toString()` redacts both values.
- HTTP 401 from the status endpoint maps to `BasicAuthRequired`, not the V1 form control-token error.
- Legacy V2 `/api/status` JSON is parsed as read-only single-sensor data.
- `pumpAvailable=false` maps to LOCKED; `pumpAvailable=true` maps to UNKNOWN, never ENABLED.
- Malformed legacy JSON is rejected.

This release has not yet been built or tested by CI.
