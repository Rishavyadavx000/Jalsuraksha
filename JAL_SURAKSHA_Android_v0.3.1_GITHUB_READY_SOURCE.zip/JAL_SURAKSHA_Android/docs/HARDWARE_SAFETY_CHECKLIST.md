# JAL-SURAKSHA Firmware 1.0 — Hardware Safety Checklist

**Do not connect or energise the real pump until every applicable item has been verified.** Water and electricity together can be fatal. For mains-powered wiring, use a qualified electrician. The app and ESP32 are educational prototype controls, not a certified safety system. Keep a physical power cutoff available at all times.

## 1. Supplied firmware pin map (verify against the actual board and wiring)

| Function | ESP32 GPIO | Notes |
|---|---:|---|
| Flow sensor A (upstream) | 27 | Pulse input |
| Flow sensor B (downstream) | 26 | Pulse input |
| Relay input | 25 | Active-low by firmware default; polarity not verified |
| OLED SDA | 21 | I²C |
| OLED SCL | 22 | I²C |
| Buzzer | 23 | Active buzzer by default |
| Button | 32 | Button to GND |
| Red LED | 16 | Firmware alarm indication |
| Yellow LED | 17 | Optional; enabled by default |
| Green LED | 18 | Firmware state indication |

## 2. Electrical checks

- [ ] Record the exact ESP32 DevKit V1 board variant and exact relay-module model.
- [ ] Record pump rated voltage, normal current and startup/stall current.
- [ ] Confirm the relay/driver contact rating exceeds the pump's inrush/stall load with a suitable margin.
- [ ] Confirm the relay input is compatible with the ESP32 3.3 V logic.
- [ ] Do not power the pump from an ESP32 GPIO or the ESP32 3.3 V regulator.
- [ ] Use a separate regulated pump supply sized for the load, correctly rated wire and an appropriately sized fuse.
- [ ] Fit a flyback diode across a DC pump when using a transistor/MOSFET driver; follow the relay/driver module's design requirements.
- [ ] Confirm sensor output type and voltage. A 5 V pulse must not be connected directly to a 3.3 V ESP32 GPIO. Use a suitable divider/level shifter or 3.3 V pull-up as required by the sensor datasheet.
- [ ] Confirm sensor GND/reference wiring and whether a common ground is required by the chosen driver design.
- [ ] Keep all water connections away from the ESP32, relay board, supply, connectors and mains wiring.
- [ ] Enclose mains wiring in a correctly rated enclosure with strain relief and RCD/GFCI protection.
- [ ] Confirm GPIO 25 does not create an unwanted relay activation during reset/boot on this board and module.

## 3. Firmware defaults — must remain locked until reviewed

The supplied `JAL_SURAKSHA (1).ino` currently declares:

- [ ] `RELAY_ACTIVE_LOW = 1` and `RELAY_OFF_HIGH_Z = 1` are assumptions, not proof of the module's polarity.
- [ ] `RELAY_POLARITY_VERIFIED = 0`. Do not change it to `1` until the manual's relay test R2 passes with the pump supply disconnected.
- [ ] `CONTROL_TOKEN = "CHANGE_ME_TOKEN"`. Replace locally with a private unique 8+ character token; do not share it in chat, screenshots, source ZIPs or Git commits.
- [ ] `AP_PASSWORD = "CHANGE_ME_AP_PW"`. Replace locally before deployment; do not publish a configured password.
- [ ] `DEFAULT_K_A = 0` and `DEFAULT_K_B = 0`. The system is uncalibrated and leak comparison is disabled until both sensors are measured and calibrated.
- [ ] `UNCAL_RUN_MAX_MS = 180000` (3 minutes) is the uncalibrated run cap.
- [ ] `PUMP_MAX_RUN_MS = 0` means there is no maximum run-time cap in calibrated operation. Configure a finite safe limit in firmware before any unattended or field operation.
- [ ] `NOFLOW_STOP_ENABLED = 1`; it is configured to stop after five no-flow windows. Verify this through a pump-disconnected/safe test and then a controlled bench test.
- [ ] Firmware header itself says it was not compiled with the real ESP32 toolchain and was not hardware-tested when supplied. Compile and review it with the target ESP32 core and required libraries before use.

## 4. Calibration checks

- [ ] Identify and inspect both YF-S201 sensors (or the actual sensor variants) and their flow-direction arrows.
- [ ] Place Sensor A upstream of the leak test point and Sensor B downstream, as required by the firmware's A/B comparison design.
- [ ] Check that neither sensor is installed backwards and that both are sealed against leaks.
- [ ] Perform a known-volume test with the pump OFF and the approved manual/gravity test path.
- [ ] Press `calzero` to snapshot both pulse counters.
- [ ] Pass a measured volume between 0.2 L and 100 L through both sensors. The firmware requires at least 50 pulses from each sensor.
- [ ] Submit `calsave` with the known litres; confirm `cal=true` and non-zero `cfg.kA` / `cfg.kB` in `/api/status`.
- [ ] Repeat the test at least twice and compare the measured totals. Do not copy generic pulses/L values from the internet.
- [ ] With the leak path closed and a stable controlled pump run, capture baseline only after both sensors are calibrated.

## 5. Control and API bench tests (pump power disconnected)

- [ ] Confirm the exact sketch flashed is the supplied firmware version and confirm API paths: `GET /api/status`, `GET /api/events`, `POST /api/cmd`.
- [ ] Confirm status/events are local read-only endpoints; command requests include the `t` control-token form field and `c` command field. They do not use Basic Auth.
- [ ] Confirm placeholder token produces HTTP 403 and a wrong token produces HTTP 401. Do not make five wrong attempts; the sketch locks commands for one minute after five failures.
- [ ] Confirm `start` is rejected while `RELAY_POLARITY_VERIFIED=0`.
- [ ] Confirm `stop` only sends a command and the Android app waits for fresh `pump=false` read-back. It is not a physical emergency stop.
- [ ] Confirm ACK mutes the buzzer but leaves the alarm latch set.
- [ ] Confirm RESET requires pump OFF and at least 5 seconds without sensor pulses; it does not restart the pump.
- [ ] Confirm Android displays unknown/stale telemetry as unavailable and does not assume success from HTTP 200 with `ok:false`.
- [ ] Verify that the Android command request setting remains OFF by default.

## 6. Controlled relay and pump bench sequence

- [ ] With pump disconnected, run relay test R2 using a harmless correctly rated indicator/load. Verify OFF at boot, reset and brown-out.
- [ ] Only after R2 passes, and after a second-person/wiring review, set `RELAY_POLARITY_VERIFIED=1` in the firmware and re-flash.
- [ ] Verify STOP and START using the harmless load before connecting a real pump.
- [ ] Test sensor failure, no-flow stop, alarm latch, ACK, RESET, and Wi-Fi loss behavior.
- [ ] Confirm the pump is primed/wet and the water path is open before a controlled pump run.
- [ ] Confirm a physical switch/plug disconnects pump power independently of Wi-Fi, Android or firmware.
- [ ] Do not conduct unattended testing while `PUMP_MAX_RUN_MS=0`.

## 7. Network security and app behavior

- [ ] Use only a private hotspot or trusted LAN. The current API uses plain HTTP; the control token and Wi-Fi configuration are not encrypted in transit.
- [ ] Do not use a public Wi-Fi network for control.
- [ ] Do not expose port 80 to the public internet and do not configure router port forwarding.
- [ ] The Android app restricts target hosts to private IPv4 / approved `.local` names, but this code restriction does not encrypt local traffic.
- [ ] If the phone's hotspot DHCP address changes, update the IP in Device Settings and re-test status read access.

## 8. Sign-off

| Review | Name | Date | Result / evidence |
|---|---|---|---|
| Electrical review | | | |
| Relay polarity test R2 | | | |
| Sensor wiring / direction | | | |
| Firmware compile and flash | | | |
| Dual-sensor calibration | | | |
| Controlled relay bench test | | | |
| Controlled pump bench test | | | |
| Physical power cutoff verified | | | |
