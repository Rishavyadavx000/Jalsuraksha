# ESP32 Firmware API Contract — JAL-SURAKSHA Firmware 1.0

**Source reviewed:** the user-library file `JAL_SURAKSHA (1).ino` (66,998 bytes; uploaded 10 November 2026).  
**Android implementation:** JAL-SURAKSHA Android v0.3.1.  
**Verification boundary:** this document matches the supplied sketch source. It does **not** prove that this exact sketch is the one currently flashed on the ESP32, that it compiles with the user's installed board package, or that the physical hardware works.

## 1. Network model and authentication

- The ESP32 runs `WebServer` on port `80`.
- The firmware supports station Wi-Fi and a fallback setup access point (`JAL-SURAKSHA-SETUP`) when no saved SSID is available / station setup fails.
- The sketch advertises the mDNS name `jal-suraksha.local`.
- The phone and ESP32 must be reachable on the same local network. The device's DHCP address can change; Android stores a user-configured address and allows it to be edited.
- In the bundled Firmware 1.0 sketch, `GET /api/status` and `GET /api/events` are **not authenticated**.
- In the earlier V2 firmware draft, `server.authenticate(WEB_USER, WEB_PASSWORD)` protected dashboard/status routes. The exact V2 `.ino` currently flashed to the user's board has not been provided; v0.3.1 therefore exposes optional Basic Auth fields for that legacy status-read path.
- Firmware 1.0 control uses a form token, **not HTTP Basic Authentication**. Every `POST /api/cmd` request includes `t=<CONTROL_TOKEN>` and `c=<command>` as `application/x-www-form-urlencoded` fields. The app's Basic Auth password and V1 control token are stored separately.
- The sketch defaults `CONTROL_TOKEN` to `CHANGE_ME_TOKEN`. While it is unchanged, all controls are locked and the handler returns HTTP 403.
- Five incorrect tokens cause a one-minute control lockout. An incorrect token returns HTTP 401.
- Plain HTTP does not encrypt the token, Wi-Fi password, or command parameters. Use a trusted private hotspot only. Never add router port forwarding or expose the ESP32 server to the public internet.

## 1.1 Legacy V2 compatibility (observed device; exact sketch still required)

The currently observed board prints `JAL-SURAKSHA V2` and returns the following `/api/status` body in Chrome:

```json
{"wifi":"Connected","ip":"10.136.231.207","rssi":-36,"pump":false,"pumpAvailable":false,"flowLpm":0,"totalLiters":0}
```

This is a different, older single-sensor schema from the supplied dual-sensor Firmware 1.0 sketch described below. The earlier V2 firmware draft documented `server.authenticate(WEB_USER, WEB_PASSWORD)` on `/api/status`; the Android starter had no Basic Auth header, which is a strong explanation for the app's HTTP 401 while a browser with a cached authenticated session can still show JSON. The exact V2 `.ino` currently flashed has **not** been provided for line-by-line verification. The app therefore exposes optional `WEB_USER` / `WEB_PASSWORD` fields and treats this V2 response as read-only compatibility, not as a verified full firmware contract.

When V2 is detected, the app maps the response to one flow channel only, reports Sensor B / leak segment as unavailable, skips `/api/events` polling, and never unlocks pump commands. `pumpAvailable=false` becomes LOCKED; `pumpAvailable=true` remains UNKNOWN (not permission). Basic Auth password is stored encrypted using Android Keystore AES-GCM. Basic Auth credentials are separate from the V1 `CONTROL_TOKEN`.

## 2. Routes

| Method | Path | Auth | Purpose | Response |
|---|---|---|---|---|
| `GET` | `/` | None | Firmware-hosted browser dashboard | HTML 200 |
| `GET` | `/api/status` | None | Current dual-sensor / pump / leak status | JSON 200 |
| `GET` | `/api/events` | None | Firmware's most recent event ring buffer (up to 20 entries) | JSON array 200 |
| `POST` | `/api/cmd` | `t` form field | Start/stop, alarm ack/reset, calibration, settings, Wi-Fi | JSON `{ "ok": boolean, "msg": string }` |

Android polls `/api/status` while the app is in the foreground and fetches `/api/events` periodically for Firmware 1.0. When the legacy V2 schema is detected, V1-only event polling and all pump commands are disabled. All Android API requests are local-only/private-host restricted; redirects are disabled.

## 3. Status JSON

The status builder returns the following compact JSON keys. Numeric fields are sent as JSON numbers, flags as Booleans, and descriptive fields as strings.

| Key | Meaning | Android handling |
|---|---|---|
| `fa`, `fb` | Sensor A/B flow in L/min when calibrated; firmware deliberately reports zero placeholders while uncalibrated | Android displays as L/min only when `cal=true`; otherwise unavailable |
| `diff` | A minus B flow difference (L/min) | Displayed only as reported |
| `pct` | Relative A/B difference percentage | Displayed only as reported |
| `ra`, `rb` | Sensor A/B pulse frequency in Hz | Shown when uncalibrated |
| `va`, `vb` | Sensor A/B cumulative volume (litres) when calibrated; zero placeholders otherwise | Displayed only when calibrated |
| `pa`, `pb` | Raw pulse totals for Sensor A/B | Diagnostics / calibration context |
| `cpa`, `cpb` | Pulses since the last calibration zero snapshot | Calibration wizard |
| `state` | Firmware state text (e.g. `STARTING`, `READY - PUMP OFF`, `UNCALIBRATED`, `NORMAL`, `LEAK DETECTED`) | Dashboard state |
| `sev` | Firmware severity (0 green, 1 amber, 2 red) | Dashboard state context |
| `latch` | Alarm latch: `none`, `leak`, `possible_leak`, `sensor_fault` | Pump alarm actions |
| `loc` | Segment estimate (e.g. `Between A & B`); not exact point/distance | Displayed as estimated segment only |
| `pump` | Actual relay/pump state Boolean | Tri-state ON/OFF/UNKNOWN if missing or invalid |
| `muted` | Whether buzzer is muted | ACK UI |
| `cal` | Both flow sensors are calibrated | Controls units and calibration UI |
| `bl` | Baseline capture in progress | Calibration UI |
| `sens` | Firmware sensor-health text | Diagnostics / dashboard |
| `wifi` | `CONNECTED`, `AP MODE`, or `OFFLINE` | Connection info |
| `rssi` | Wi-Fi signal in dBm | Signal quality |
| `ip` | Device IP or `-` | Display only; may change |
| `cloud` | MQTT state (optional cloud feature is disabled by default) | Display only |
| `up` | Firmware uptime in seconds | Restart/event context |
| `note`, `stop` | Firmware note and last stop reason | Diagnostics / Pump screen |
| `tokOk` | Whether `CONTROL_TOKEN` differs from placeholder | Not the caller's authentication result; indicates token is configured |
| `apDef` | Whether the fallback AP password remains its default placeholder | Security warning |
| `relayOk` | Compile-time `RELAY_POLARITY_VERIFIED` flag | Firmware START permission |
| `ev` | Most recent firmware event code | Diagnostics |
| `cfg` | Persisted firmware settings object | Calibration / diagnostics |

`cfg` contains: `kA`, `kB` (pulses/litre), `win` (window ms), `zero` (zero-flow threshold L/min), `abs` (minimum absolute difference L/min), `rel` (relative difference percent), `pers` (persistence count), and `base` (signed baseline offset L/min, range −5..+5).

Android accepts signed `cfg.base` values in the firmware range −5..+5 L/min. It classifies `latch=possible_leak` / state text containing `POSSIBLE LEAK` as a possible leak, not as a confirmed leak. Android rejects non-JSON responses and requires `fa`, `fb`, `pump`, and `state` to identify this firmware family. Missing or malformed values stay unavailable; they are not replaced with fabricated zeros.

## 4. Firmware events

`GET /api/events` returns an array of up to 20 entries:

```json
[
  {"t": 1731400000, "u": 120, "c": 4, "m": "Leak detected between sensors"}
]
```

- `t`: Unix epoch seconds; `0` means wall-clock time was unavailable.
- `u`: firmware uptime seconds (used by Android as a fallback timestamp).
- `c`: event code.
- `m`: firmware-authored event message.

| Code | Meaning |
|---:|---|
| 1 | Boot |
| 2 | Pump ON |
| 3 | Pump OFF |
| 4 | Leak latched |
| 5 | Possible leak latched |
| 6 | Sensor fault |
| 7 | No flow while pump ON |
| 8 | Alarm acknowledged / buzzer muted |
| 9 | Alarm reset |
| 10 | Wi-Fi event |
| 11 | Settings changed |
| 12 | Calibration event |
| 13 | Information |
| 14 | Command rejected |

## 5. Command request and response

All control commands are sent as form fields:

- `t`: exact `CONTROL_TOKEN` value configured in the sketch.
- `c`: command name.
- Additional fields are command-specific.

Every response must be interpreted using both the HTTP code and JSON `ok` field. HTTP 200 with `ok:false` is a **rejection**, not success. Android reads back `/api/status` after commands; it does not optimistically change pump state.

| `c` | Additional form fields | Firmware preconditions / effects |
|---|---|---|
| `start` | none | Rejected unless `RELAY_POLARITY_VERIFIED=1`, startup is complete, and no alarm latch exists. A successful reply starts pump settling; Android waits for status `pump=true` before reporting confirmation. |
| `stop` | none | Calls firmware pump-off. Once token auth passes, STOP is the firmware's non-refused command. Android waits for `pump=false` read-back. Physical cutoff remains necessary. |
| `ack` | none | Requires an active alarm latch; mutes buzzer but leaves latch active. |
| `reset` | none | Requires active latch, pump OFF, and at least 5 seconds without sensor pulses. It clears the latch but keeps pump OFF. |
| `calzero` | none | Snapshots both raw pulse counters for calibration. Pump should be OFF as described in the manual. |
| `calsave` | `l` = known litres | Requires 0.2–100 L, at least 50 pulses from each sensor, and pump OFF. Saves `K_A` and `K_B` separately and sets `cal=true`. |
| `baseline` | none | Requires calibrated sensors, pump ON, and no alarm latch. Starts capture of the no-leak baseline across 10 windows. |
| `set` | any of `kA`, `kB`, `win`, `zero`, `abs`, `rel`, `pers`, `base` | Validates ranges and refuses changes while pump is ON. Firmware persists accepted values. |
| `wifi` | `ssid`, `pass` | SSID 1–32 characters; password either empty or 8–63 characters. Saves Wi-Fi settings and reconnects; the current IP may change. |

Response status:
- HTTP 403: `CONTROL_TOKEN` is still the placeholder / control is locked.
- HTTP 401: wrong token or one-minute lockout after five wrong attempts.
- HTTP 400: unknown command.
- HTTP 200 with `{"ok":false,"msg":"..."}`: command precondition or setting validation rejected it.
- HTTP 200 with `{"ok":true,"msg":"..."}`: handler accepted the command; state-changing actions still need read-back.

## 6. Hardware and firmware defaults that block a field release

The supplied sketch has these defaults:

- `RELAY_POLARITY_VERIFIED 0`: START is refused until the relay polarity bench test (manual test R2) is completed and the setting is deliberately changed.
- `CONTROL_TOKEN "CHANGE_ME_TOKEN"`: command control remains locked until replaced with a private unique 8+ character token.
- `AP_PASSWORD "CHANGE_ME_AP_PW"`: fallback setup AP password is still a placeholder and must be changed before deployment.
- `DEFAULT_K_A = 0`, `DEFAULT_K_B = 0`: both sensors are uncalibrated; leak comparison is disabled until measured calibration is saved.
- `UNCAL_RUN_MAX_MS = 180000`: an uncalibrated pump run has a 180-second cap.
- `PUMP_MAX_RUN_MS = 0`: **no maximum run time is configured for calibrated operation**. Set a safe finite limit in the firmware before any unattended/field operation; do not rely on the app for this.
- `NOFLOW_STOP_ENABLED = 1`, `NOFLOW_STOP_WINDOWS = 5`: a no-flow stop guard is enabled.

Android's app-side command switch defaults OFF. Firmware is the final authority. The current app does not change GPIO, relay polarity, calibration constants, or firmware secrets.

## 7. Firmware compatibility procedure

1. Confirm that the exact supplied `JAL_SURAKSHA (1).ino` is the sketch flashed to the ESP32.
2. Configure private Wi-Fi/AP credentials and a unique `CONTROL_TOKEN` locally in the sketch; never commit filled secrets.
3. Compile with the actual Arduino-ESP32 board package and required Adafruit libraries. The sketch header says it was not compiled with the real ESP32 toolchain and not hardware-tested at the time it was supplied.
4. Connect Android to the same hotspot/network and enter the current device IP in the app.
5. Verify `GET /api/status` and `GET /api/events` first with pump power disconnected.
6. Verify app control token against `/api/cmd` with pump power disconnected and relay polarity still unverified; confirm START is rejected by firmware.
7. Complete electrical and relay bench checks before enabling any real pump operation.

The Android emulator tests use mocked/local test responses. They do not prove that the physical ESP32 has this firmware or that the pump/relay works.
