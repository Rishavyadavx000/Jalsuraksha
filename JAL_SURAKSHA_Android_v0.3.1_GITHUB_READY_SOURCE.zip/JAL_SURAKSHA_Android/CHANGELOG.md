## v0.3.1 — Legacy V2 HTTP 401 compatibility (source prepared)

- Added separate optional `WEB_USER` / `WEB_PASSWORD` fields for older JAL-SURAKSHA V2 Basic Auth deployments. The username is a non-secret preference; the password is encrypted with Android Keystore AES-GCM and never logged.
- Added Basic Auth request header support for local status/events requests when explicitly configured.
- A status/events HTTP 401 now reports `Basic Auth required`; command HTTP 401 remains a separate V1 control-token error.
- Added strict parsing for the observed legacy V2 single-sensor JSON: `wifi`, `ip`, `rssi`, `pump`, `pumpAvailable`, `flowLpm`, `totalLiters`. Sensor B and leak-segment fields remain unavailable.
- Legacy V2 runs read-only: `/api/events` polling is skipped; pump commands are never unlocked. `pumpAvailable=false` is LOCKED and `true` is UNKNOWN.
- Added four JVM tests (106 total) covering Basic Auth header, Basic Auth 401 classification, V2 parsing, and fail-closed pump permission.
- Version bumped to 0.3.1 / versionCode 4.
- Local inventory, Kotlin/XML structural checker, firmware contract static checker and ZIP integrity pass. Full Gradle tests, emulator tests, APK build and actual V2 `.ino` verification remain pending.

## v0.3.0 GitHub release verification — Run #27

- GitHub Actions Run #27 completed successfully: JVM/structural/lint/compile job, Compose UI emulator job, and installable Debug APK job all passed.
- JUnit XML reports confirm 102/102 JVM tests passed and instrumented XML confirms 6/6 Compose UI tests passed.
- Android Gradle tasks `clean testDebugUnitTest lintDebug compileDebugKotlin`, `connectedDebugAndroidTest`, and `assembleDebug` completed successfully.
- Debug APK artifact was uploaded with SHA-256 checksum. This is a debug-signed test APK, not a production-signed release.
- Lint completed with 12 warnings and 4 informational notices; these do not fail CI and remain documented in the final CI report.
- No physical ESP32, relay, pump, or water-flow calibration test was performed.

# Changelog

## v0.3.0 CI unit-test correction

- Run #24 confirmed the missing dashboard composable was resolved and Gradle reached unit-test execution. One legacy test failed because `GET /api/status` mapped HTTP 401 to the control-token error type. Firmware 1.0 keeps status/events public and uses the control token only on `POST /api/cmd`; status HTTP 401 now remains a generic `HttpError`. Command HTTP 401 continues to map to `AuthRequired`.

## v0.3.0 CI compile correction

- Added the missing `PipelineStatusCard` composable referenced by the Home dashboard. It displays firmware-reported state, sensor health, leak segment, calibrated flow difference, and baseline-capture state. Stale status is explicitly labelled and flow difference is not presented as a confirmed leak by itself.
- Root cause from GitHub Actions Run #22: `HomeScreen.kt:130` referenced an undefined `PipelineStatusCard`, failing `compileDebugKotlin` in both JVM/build and emulator jobs.
- No pump-control policy, relay setting, GPIO mapping, or firmware safety default was changed.

## v0.3.0 — ESP32 Firmware 1.0 integration

- Replaced the earlier single-sensor / Basic Auth draft API with the supplied dual-flow ESP32 Firmware 1.0 contract.
- Added GET `/api/status`, GET `/api/events`, and token-protected POST `/api/cmd` support.
- Added Sensor A/Sensor B flow, total volume, pulse counters, difference, leak segment, firmware state/latch, sensor health and AP-default warnings.
- Added `start`, `stop`, `ack`, `reset`, `calzero`, `calsave`, `baseline`, `set`, and `wifi` command mapping; current UI exposes pump/alarm/calibration workflows.
- Commands parse `{ok,msg}` and use read-back for pump, alarm and calibration state. Firmware baseline parsing accepts its documented signed −5..5 L/min range; possible-leak classification matches the firmware latch/state strings. HTTP 200 with `ok:false` is treated as firmware rejection.
- Uncalibrated telemetry now shows pulse frequency only; it no longer presents firmware placeholder zeros as measured L/min/litres. App-side flow alarms are suppressed until calibration is active.
- Pump START remains locked by default and by the firmware's token + relay verification flags. STOP remains a network action, never advertised as a physical emergency stop.
- Updated hardware checklist and API documentation for GPIO 27/26 flow sensors, GPIO25 relay, token protocol and actual run-time defaults.
- Updated test inventory to 102 JVM test cases + 6 instrumented UI test cases.
- Fixed signed firmware baseline parsing and possible-leak classification.
- Fixed a Kotlin syntax issue in the firmware command response parser found during targeted compilation.
- Added a static firmware/API drift guard to CI for routes, JSON keys, commands, form parameters and safety defaults.

## v0.2.0

- Initial premium Kotlin/Compose dashboard, local history, alerts, diagnostics and pump safety UI.
- v0.2.0 used a draft API contract and is superseded by v0.3.0 for the supplied dual-sensor firmware.
