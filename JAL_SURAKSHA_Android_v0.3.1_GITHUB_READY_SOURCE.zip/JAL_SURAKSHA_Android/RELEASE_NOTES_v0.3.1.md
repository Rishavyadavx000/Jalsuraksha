# JAL-SURAKSHA Android v0.3.1

## Fix for HTTP 401 on legacy V2

- Adds optional HTTP Basic Auth username/password fields, separate from the firmware control token.
- Encrypts the Basic Auth password with Android Keystore AES-GCM.
- Sends the Basic Auth header for status and events requests only when configured.
- Reports a status/events HTTP 401 as a Basic Auth challenge. A command HTTP 401 remains a control-token rejection.
- Supports the observed legacy V2 single-sensor status JSON in read-only mode.
- Does not poll the V1-only events route for V2.
- Keeps all V2 pump commands disabled. `pumpAvailable=true` does not unlock pump control.

## Verification in this package

- 106 JVM test annotations and 6 instrumented UI test annotations inventoried.
- Kotlin/XML structural checker: 50 Kotlin files, no findings.
- Firmware 1.0 static API contract checker: PASS.
- ZIP structure and integrity: PASS.

The inventory count is not a test run. This environment does not have Gradle or the Android SDK, so the Gradle build, actual JVM/UI test execution, APK assembly and physical ESP32 test remain pending. GitHub Actions must pass before installing this build.

## Setup after CI builds a new APK

For the legacy V2 firmware only, enter the exact `WEB_USER` and `WEB_PASSWORD` values configured in the ESP32 sketch in the separate Basic Auth fields. Do not send those secrets in chat or commit them. Leave the Firmware Control Token blank for read-only monitoring. Keep pump power disconnected and do not unlock pump control.
