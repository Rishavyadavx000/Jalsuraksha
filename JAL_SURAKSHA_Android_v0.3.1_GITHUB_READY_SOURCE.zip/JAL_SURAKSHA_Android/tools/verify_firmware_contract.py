#!/usr/bin/env python3
"""Static compatibility guard between the bundled ESP32 sketch and Android API client.

This checks source-level names and safety defaults only. It does not compile the sketch,
run an HTTP integration test, or prove which firmware is flashed on the physical ESP32.
"""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
FW = ROOT / "firmware" / "JAL_SURAKSHA_Firmware_v1.0.ino"
CONTRACT = ROOT / "app/src/main/java/com/jalsuraksha/app/data/ApiContract.kt"
API = ROOT / "app/src/main/java/com/jalsuraksha/app/data/DeviceApi.kt"

for path in (FW, CONTRACT, API):
    if not path.is_file():
        print(f"ERROR: required contract source is missing: {path.relative_to(ROOT)}")
        sys.exit(1)

fw = FW.read_text(encoding="utf-8")
contract = CONTRACT.read_text(encoding="utf-8")
api = API.read_text(encoding="utf-8")
errors = []

# 1. Exact route/method pairs.
routes = set(re.findall(r'server\.on\("([^\"]+)",\s*HTTP_(GET|POST)', fw))
expected_routes = {
    ("/api/status", "GET"),
    ("/api/events", "GET"),
    ("/api/cmd", "POST"),
}
for route in sorted(expected_routes - routes):
    errors.append(f"Firmware route missing: {route[1]} {route[0]}")

route_defaults = {
    "/api/status": "DEFAULT_STATUS_PATH",
    "/api/events": "DEFAULT_EVENTS_PATH",
    "/api/cmd": "DEFAULT_COMMAND_PATH",
}
for route, const in route_defaults.items():
    if not re.search(rf'const\s+val\s+{const}\s*=\s*"{re.escape(route)}"', contract):
        errors.append(f"Android route constant mismatch: {const} should be {route}")

# 2. Firmware status JSON keys and Android parser constants.
status_start = fw.find("static String buildStatusJson()")
status_end = fw.find("static String buildEventsJson()", status_start)
if status_start < 0 or status_end < 0:
    errors.append("Could not locate firmware buildStatusJson()/buildEventsJson() functions")
    status_block = ""
else:
    status_block = fw[status_start:status_end]
firmware_keys = set(re.findall(r'\\"([A-Za-z][A-Za-z0-9]*)\\"\s*:', status_block))
android_keys = set(re.findall(r'const\s+val\s+KEY_[A-Z0-9_]+\s*=\s*"([A-Za-z][A-Za-z0-9]*)"', contract))
required_keys = {
    "fa", "fb", "diff", "pct", "ra", "rb", "va", "vb", "pa", "pb", "cpa", "cpb",
    "state", "sev", "latch", "loc", "pump", "muted", "cal", "bl", "sens", "wifi",
    "rssi", "ip", "cloud", "up", "note", "stop", "tokOk", "apDef", "relayOk", "ev", "cfg",
}
for key in sorted(required_keys - firmware_keys):
    errors.append(f"Firmware status JSON is missing key: {key}")
for key in sorted(required_keys - android_keys):
    errors.append(f"Android parser has no key constant for: {key}")

# 3. Firmware command names versus Android command constants.
cmd_start = fw.find("static void handleCmd()")
cmd_end = fw.find("static void netStart()", cmd_start)
cmd_block = fw[cmd_start:cmd_end] if cmd_start >= 0 and cmd_end >= 0 else ""
firmware_commands = set(re.findall(r'c\s*==\s*"([a-z]+)"', cmd_block))
android_commands = set(re.findall(r'const\s+val\s+COMMAND_[A-Z0-9_]+\s*=\s*"([a-z]+)"', contract))
required_commands = {"start", "stop", "ack", "reset", "calzero", "calsave", "baseline", "set", "wifi"}
for command in sorted(required_commands - firmware_commands):
    errors.append(f"Firmware command handler missing: {command}")
for command in sorted(required_commands - android_commands):
    errors.append(f"Android command constant missing: {command}")

# 4. Additional form parameters allowed by Android must be accepted by firmware.
params_match = re.search(r'ALLOWED_COMMAND_PARAMS\s*=\s*setOf\((.*?)\)', api, re.S)
android_params = set(re.findall(r'"([A-Za-z]+)"', params_match.group(1))) if params_match else set()
firmware_args = set(re.findall(r'server\.arg\("([A-Za-z]+)"\)', fw))
for param in sorted(android_params - firmware_args):
    errors.append(f"Android may send command parameter not read by firmware: {param}")

# 5. Keep current safe defaults visible and unchanged in the bundled firmware snapshot.
safety_patterns = {
    "placeholder control token": r'#define\s+CONTROL_TOKEN\s+"CHANGE_ME_TOKEN"',
    "relay polarity not verified": r'#define\s+RELAY_POLARITY_VERIFIED\s+0\b',
    "Sensor A not calibrated by default": r'DEFAULT_K_A\s*=\s*0\.0f',
    "Sensor B not calibrated by default": r'DEFAULT_K_B\s*=\s*0\.0f',
    "calibrated max run-time remains unset": r'PUMP_MAX_RUN_MS\s*=\s*0\s*;',
}
for label, pattern in safety_patterns.items():
    if not re.search(pattern, fw):
        errors.append(f"Safety default changed or missing: {label}")

if errors:
    print("Firmware/API contract check: FAIL")
    for error in errors:
        print(f"- {error}")
    sys.exit(1)

print("Firmware/API contract check: PASS")
print(f"- Routes: {len(expected_routes)} matched")
print(f"- Status JSON keys: {len(required_keys)} matched")
print(f"- Commands: {len(required_commands)} matched")
print(f"- Android command parameters: {len(android_params)} accepted by firmware")
print(f"- Safety defaults: {len(safety_patterns)} preserved")
print("Scope: static source comparison only; no firmware compile, live HTTP test, or hardware test.")
