#!/usr/bin/env python3
"""Check that the committed JVM and Compose test inventory remains complete.

This counts @Test annotations; it does NOT compile or execute the tests.
"""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
EXPECTED = {"test": 106, "androidTest": 6}
TEST_ROOT = ROOT / "app" / "src"

failed = False
for source_set, expected in EXPECTED.items():
    files = sorted((TEST_ROOT / source_set).rglob("*.kt"))
    count = sum(len(re.findall(r"@Test\b", path.read_text(encoding="utf-8"))) for path in files)
    status = "OK" if count == expected else "MISMATCH"
    print(f"{source_set}: {count} @Test annotations across {len(files)} Kotlin files (expected {expected}) [{status}]")
    if count != expected:
        failed = True

if failed:
    sys.exit(1)

print("Inventory matches the documented 106 JVM + 6 instrumented UI tests.")
print("Note: inventory counting is not test execution.")
