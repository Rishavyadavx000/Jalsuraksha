/* =============================================================================
   JAL-SURAKSHA  -  IoT Water Leakage Detection and Location Estimation
   "Save Water, Secure Tomorrow"                                Firmware 1.0

   BOARD : ESP32 Dev Module (ESP32-WROOM-32)      Arduino-ESP32 core 2.0.x or 3.x
   LIBS  : "Adafruit SSD1306" + "Adafruit GFX Library" (Library Manager; BusIO is
           installed with them).  "PubSubClient" only if you set MQTT_ENABLED 1.
           WiFi, WebServer, Preferences, ESPmDNS come with the ESP32 core.

   STATUS (keep this honest in your report):
     - Written and logic-checked on a PC with stand-in headers. It was NOT
       compiled with the real ESP32 toolchain and NOT tested on hardware.
     - Compile it yourself, then follow the bench tests in the manual.

   WHAT IT DOES
     Pump -> Flow A -> [leak test point] -> Flow B.  If A stays higher than B by
     more than the calibrated tolerance for several windows in a row, the leak is
     LATCHED, the relay stops the pump, and the segment "Between A & B" is shown.
     Two sensors can only name the SEGMENT, never an exact point or distance.

   BUTTON (GPIO32 to GND)      1 click = mute buzzer (leak stays latched)
                               2 quick clicks = pump START (if safe) or STOP
                               hold 3 s = RESET (only if alarm latched, pump OFF,
                               and no pulses for 5 s)
   LEDs   green steady = NORMAL, green blink = ready/pump off
          red steady = leak latched, red fast blink = possible leak / sensor fault
          yellow = starting / settling / sensor warning / no flow,
                   yellow slow blink = NOT calibrated, short blip = Wi-Fi offline
   BUZZER leak = 2 beeps/s until muted, other alarms = short beep every second

   ------------------------------------------------------------------------
   हिंदी सार (Hindi summary)
   ------------------------------------------------------------------------
   * दो फ्लो सेंसर: Sensor A (पंप के बाद, upstream) और Sensor B (लीक पॉइंट के बाद,
     downstream)। ESP32 दोनों की पल्स गिनकर Flow (L/min) और कुल पानी (लीटर) निकालता है।
   * अगर A का फ्लो, B से कई विंडो तक लगातार ज़्यादा रहे (कैलिब्रेशन के बाद तय सीमा से ऊपर),
     तो पहले "LEAK SUSPECTED" और फिर पक्का होने पर "LEAK DETECTED" दिखता है।
   * लीक की जगह सिर्फ़ "Between A & B" (A और B के बीच) बताई जाती है। दो सेंसर से
     सही जगह या दूरी नहीं निकल सकती।
   * लीक पक्का होते ही: रिले पंप बंद करता है, लाल LED जलती है, बज़र बजता है, OLED और
     डैशबोर्ड पर चेतावनी आती है और अलार्म "लैच" हो जाता है।
   * पंप अपने-आप दोबारा चालू नहीं होता। पाइप ठीक करें, RESET करें (बटन 3 सेकंड), फिर हाथ से START।
   * सबसे पहले K_A और K_B (pulses per litre) खुद नापकर डालें। जब तक नहीं डालेंगे, लीक-जाँच बंद रहेगी।
   * Wi-Fi या क्लाउड न हो तब भी सेंसर, OLED, अलार्म और पंप-सुरक्षा चलती रहती है।
   * बटन: 1 बार = बज़र म्यूट | 2 बार जल्दी-जल्दी = पंप START/STOP | 3 सेकंड दबाए रखें = RESET।
   ============================================================================= */

// ============================================================================
// SECTION 1 - USER SETTINGS  (edit this section only)
// ============================================================================

// ---- 1A. SECRETS AND PLACEHOLDERS -------------------------------------------
// Never share this file after you fill these in. Wi-Fi can also be set later
// from the dashboard (saved in the ESP32's flash, not in this file).
#define WIFI_SSID_DEFAULT      ""                     // your Wi-Fi name (or leave empty)
#define WIFI_PASSWORD_DEFAULT  ""                     // your Wi-Fi password (or leave empty)
#define AP_SSID                "JAL-SURAKSHA-SETUP"   // fallback hotspot name
#define AP_PASSWORD            "CHANGE_ME_AP_PW"      // CHANGE BEFORE DEPLOYMENT (8+ characters)
#define CONTROL_TOKEN          "CHANGE_ME_TOKEN"      // dashboard password for START/STOP/RESET/settings
                                                      // (8+ characters; control stays LOCKED while it
                                                      //  is still the placeholder)
#define MDNS_NAME              "jal-suraksha"         // http://jal-suraksha.local
#define TZ_OFFSET_SEC          19800                  // India (IST, UTC+5:30). Change for other zones.

// ---- 1B. OPTIONAL CLOUD (MQTT, publish-only). Local protection never needs it ----
#define MQTT_ENABLED       0                          // 0 = "Not configured", 1 = enable
#define MQTT_USE_TLS       1                          // 1 = TLS (needs MQTT_CA_CERT below)
#define MQTT_HOST          "broker.example.com"       // PLACEHOLDER
#define MQTT_PORT          8883
#define MQTT_DEVICE_ID     "jal-suraksha-01"
#define MQTT_USER          ""                         // PLACEHOLDER
#define MQTT_PASSWORD      ""                         // PLACEHOLDER
#define MQTT_TOPIC_PREFIX  "jal-suraksha"             // topics: prefix/deviceId/telemetry and /status
#define MQTT_PUBLISH_MS    5000UL
#define MQTT_RETRY_MS      30000UL
static const char MQTT_CA_CERT[] = "";                // paste your broker's root CA (PEM) here

// ---- 1C. PIN MAP (must match the wiring table in the manual) ----------------
#define PIN_FLOW_A      27
#define PIN_FLOW_B      26
#define PIN_RELAY_IN    25
#define PIN_OLED_SDA    21
#define PIN_OLED_SCL    22
#define PIN_BUZZER      23
#define PIN_BUTTON      32
#define PIN_LED_RED     16
#define PIN_LED_YELLOW  17
#define PIN_LED_GREEN   18

// ---- 1D. HARDWARE OPTIONS (decide each one by TESTING, see manual) ----------
#define HAS_YELLOW_LED          1     // 0 if you do not have a third LED (GPIO17 then stays unused)
#define RELAY_ACTIVE_LOW        1     // 1 = relay ON when IN is LOW.  0 = relay ON when IN is HIGH.
                                      // Wrong guess with 1 fails SAFE (pump never starts). Test R2.
#define RELAY_OFF_HIGH_Z        1     // with ACTIVE_LOW: OFF = pin released (input). Best for 5V
                                      // relay boards driven from 3.3V logic.
#define RELAY_POLARITY_VERIFIED 0     // START is refused until you set this to 1 after test R2
#define BUZZER_IS_PASSIVE       0     // 0 = active buzzer (self-oscillating), 1 = passive (needs tone)
#define BUZZER_TONE_HZ          2500
#define OLED_ADDR_1             0x3C  // tried first
#define OLED_ADDR_2             0x3D  // tried second
#define SENSOR_A_PULLUP         0     // 1 = enable ESP32 internal pull-up on that pin. Use ONLY for an
#define SENSOR_B_PULLUP         0     // open-collector output with no pull-up (manual, test S1-S3)
#define SENSOR_EDGE             FALLING
#define GLITCH_FILTER_US        300   // edges closer than this are ignored (noise). Real pulses are
                                      // several milliseconds apart, so valid flow is never suppressed.

// ---- 1E. CALIBRATION (pulses per litre). 0 = NOT CALIBRATED -----------------
// Measure each sensor yourself (manual, calibration worksheet). Do not copy a
// number from the internet: different sensor models differ.
// You can also enter them on the dashboard; saved values override these.
static const float DEFAULT_K_A = 0.0f;   // Sensor A pulses per litre  (0 = not calibrated)
static const float DEFAULT_K_B = 0.0f;   // Sensor B pulses per litre  (0 = not calibrated)

// ---- 1F. LEAK LOGIC DEFAULTS (starting points only; set from your own baseline test) ----
static const uint32_t DEFAULT_WINDOW_MS       = 2000;   // sampling window (1000-10000)
static const float    DEFAULT_ZERO_FLOW_LPM   = 0.10f;  // at or below this a sensor counts as "no flow"
static const float    DEFAULT_MIN_ABS_DIFF    = 0.15f;  // L/min: smallest A-B difference that can be a leak
static const float    DEFAULT_REL_DIFF_PCT    = 15.0f;  // percent of the larger flow
static const uint8_t  DEFAULT_PERSIST         = 3;      // abnormal windows in a row before the alarm latches
static const float    DEFAULT_BASELINE_LPM    = 0.0f;   // natural no-leak A-B offset (use "Capture baseline")
static const float    SENSOR_MAX_PLAUSIBLE_LPM = 30.0f; // above this a reading is treated as a sensor fault
                                                        // (set from YOUR sensor's datasheet maximum)

// ---- 1G. TIMING AND SAFETY ---------------------------------------------------
static const uint32_t STARTUP_STABILIZE_MS = 3000;    // after boot, before the system says READY
static const uint32_t PUMP_GRACE_MS        = 6000;    // after START: pipe fills, no leak decisions yet
static const uint8_t  NOFLOW_STOP_WINDOWS  = 5;       // pump ON + no flow this many windows -> stop (dry-run guard)
#define NOFLOW_STOP_ENABLED  1
static const uint8_t  IDLE_FLOW_WARN_WINDOWS = 5;     // flow while pump OFF this long -> warning (siphon?)
static const uint32_t RESET_QUIET_MS       = 5000;    // RESET needs this long with zero pulses
static const uint32_t PUMP_MAX_RUN_MS      = 0;       // 0 = no limit (calibrated). e.g. 600000 = 10 min
static const uint32_t UNCAL_RUN_MAX_MS     = 180000;  // pump run limit while NOT calibrated (leak check is off)
static const uint8_t  BASELINE_WINDOWS     = 10;      // windows averaged by "Capture baseline"
static const uint32_t BTN_DEBOUNCE_MS      = 30;
static const uint32_t BTN_LONG_MS          = 3000;
static const uint32_t BTN_DOUBLE_MS        = 500;
static const uint32_t OLED_REFRESH_MS      = 500;
static const uint32_t OLED_PAGE_MS         = 3000;
static const uint32_t WIFI_AP_FALLBACK_MS  = 20000;   // no Wi-Fi after this long -> start the setup hotspot
static const uint32_t WIFI_RETRY_MS        = 30000;
#define WDT_TIMEOUT_S 8                               // watchdog: a hung loop reboots the ESP32 (pump OFF)

// ============================================================================
// SECTION 2 - INCLUDES
// ============================================================================
#include <Arduino.h>
#include <Wire.h>
#include <WiFi.h>
#include <WebServer.h>
#include <Preferences.h>
#include <ESPmDNS.h>
#include <time.h>
#include <esp_system.h>
#include <esp_task_wdt.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#if MQTT_ENABLED
  #include <WiFiClientSecure.h>
  #include <PubSubClient.h>
#endif

#ifndef ESP_ARDUINO_VERSION_MAJOR
  #define ESP_ARDUINO_VERSION_MAJOR 2
#endif

// ============================================================================
// SECTION 3 - TYPES AND GLOBAL STATE
// ============================================================================
enum SysState : uint8_t {
  ST_STARTING = 0, ST_IDLE, ST_STABILISING, ST_UNCAL, ST_NORMAL, ST_NO_FLOW,
  ST_WARNING, ST_SUSPECTED, ST_POSSIBLE_LEAK, ST_LEAK, ST_SENSOR_FAULT
};
enum LatchType : uint8_t { LATCH_NONE = 0, LATCH_LEAK, LATCH_POSSIBLE_LEAK, LATCH_SENSOR_FAULT };
enum EventCode : uint8_t {
  EV_BOOT = 1, EV_PUMP_ON, EV_PUMP_OFF, EV_LEAK, EV_POSSIBLE_LEAK, EV_SENSOR_FAULT,
  EV_NO_FLOW, EV_ACK, EV_RESET, EV_WIFI, EV_SETTINGS, EV_CAL, EV_INFO, EV_REJECT
};
enum NetMode : uint8_t { NET_OFFLINE = 0, NET_STA, NET_AP };
enum Cond : uint8_t {
  C_NONE = 0, C_NORMAL, C_NOFLOW, C_LEAK, C_A0_BFLOW, C_B0_AFLOW, C_B_GT_A, C_IMPLAUSIBLE
};

struct Settings {
  float    kA, kB;          // pulses per litre
  uint32_t windowMs;
  float    zeroLpm, minAbs, relPct;
  uint8_t  persist;
  float    baseline;        // natural no-leak (A - B) offset in L/min
};

struct Sys {                // everything the display, dashboard and logic share
  float    fA, fB, diff, pct, volA, volB, rateAHz, rateBHz;
  uint32_t pulsesA, pulsesB;
  uint8_t  state, latch, netMode, cloud;
  int8_t   rssi;
  bool     pumpOn, muted, cal, baselineBusy;
  uint32_t pumpStartMs, lastActivityMs, bootMs;
  char     note[48];
  char     stopReason[40];
  char     ip[16];
};

#define EVENT_MAX 24
struct EventRec { uint32_t upSec; uint32_t epoch; uint8_t code; char msg[56]; };

static Settings gCfg;
static Sys      gSys;
static SemaphoreHandle_t stateMutex = NULL;
#define LOCK()   xSemaphoreTake(stateMutex, portMAX_DELAY)
#define UNLOCK() xSemaphoreGive(stateMutex)

static volatile bool settingsDirty = false;
static String wifiSsid, wifiPass;

// pulse counters (written only by the ISRs)
static volatile uint32_t pulsesA = 0, pulsesB = 0;
static volatile uint32_t lastEdgeUsA = 0, lastEdgeUsB = 0;
static portMUX_TYPE pulseMux = portMUX_INITIALIZER_UNLOCKED;

// event log
static EventRec events[EVENT_MAX];
static uint8_t  evHead = 0, evCount = 0;
static portMUX_TYPE evMux = portMUX_INITIALIZER_UNLOCKED;
static volatile uint8_t lastEventCode = 0;

// detector memory (touched only with the state lock held)
static uint8_t lastCond = C_NONE, condCount = 0, idleFlowCount = 0;
static bool    noFlowStopped = false;
static bool    baselineActive = false;
static float   baselineSum = 0.0f, baselineFlowSum = 0.0f;
static uint8_t baselineN = 0, baselineTries = 0;
static uint32_t calBaseA = 0, calBaseB = 0;

// loop-side timing and UI
static uint32_t windowStartMs = 0, lastSnapA = 0, lastSnapB = 0;
static uint32_t beepUntilMs = 0;
static char     flashTitle[24] = "", flashReason[44] = "";
static uint32_t flashUntil = 0;

// ============================================================================
// SECTION 4 - SMALL HELPERS
// ============================================================================
static void setNote(const char* s) {
  strncpy(gSys.note, s, sizeof(gSys.note) - 1);
  gSys.note[sizeof(gSys.note) - 1] = 0;
}

static float f0(float x) {                      // keep JSON valid: no NaN/Inf
  if (x != x) return 0.0f;
  if (x > 1.0e9f || x < -1.0e9f) return 0.0f;
  return x;
}

static const char* stateText(uint8_t st) {
  switch (st) {
    case ST_STARTING:      return "STARTING";
    case ST_IDLE:          return "READY - PUMP OFF";
    case ST_STABILISING:   return "STABILISING";
    case ST_UNCAL:         return "UNCALIBRATED";
    case ST_NORMAL:        return "NORMAL";
    case ST_NO_FLOW:       return "NO FLOW";
    case ST_WARNING:       return "SENSOR CHECK";
    case ST_SUSPECTED:     return "LEAK SUSPECTED";
    case ST_POSSIBLE_LEAK: return "POSSIBLE LEAK / SENSOR B CHECK";
    case ST_LEAK:          return "LEAK DETECTED";
    case ST_SENSOR_FAULT:  return "SENSOR CHECK";
    default:               return "UNKNOWN";
  }
}

static const char* stateShort(uint8_t st) {     // 10 characters or fewer (text size 2)
  switch (st) {
    case ST_STARTING:      return "STARTING";
    case ST_IDLE:          return "IDLE";
    case ST_STABILISING:   return "STABILISE";
    case ST_UNCAL:         return "UNCAL";
    case ST_NORMAL:        return "NORMAL";
    case ST_NO_FLOW:       return "NO FLOW";
    case ST_WARNING:       return "SENSOR CHK";
    case ST_SUSPECTED:     return "SUSPECTED";
    case ST_POSSIBLE_LEAK: return "POSS LEAK";
    case ST_LEAK:          return "LEAK!";
    case ST_SENSOR_FAULT:  return "SENSOR CHK";
    default:               return "?";
  }
}

static const char* latchText(uint8_t l) {
  switch (l) {
    case LATCH_LEAK:          return "leak";
    case LATCH_POSSIBLE_LEAK: return "possible_leak";
    case LATCH_SENSOR_FAULT:  return "sensor_fault";
    default:                  return "none";
  }
}

static const char* locationText(const Sys& s) {
  if (s.latch == LATCH_LEAK)          return "Between A & B";
  if (s.latch == LATCH_POSSIBLE_LEAK) return "Between A & B (unconfirmed)";
  if (s.state == ST_SUSPECTED)        return "Between A & B (checking)";
  return "-";
}

static const char* sensorHealthText(const Sys& s) {
  if (!s.cal) return "UNCALIBRATED";
  if (s.latch == LATCH_SENSOR_FAULT || s.latch == LATCH_POSSIBLE_LEAK || s.state == ST_WARNING)
    return "CHECK";
  return "OK";
}

static const char* cloudText(uint8_t c) {
  if (c == 2) return "Connected";
  if (c == 1) return "Offline";
  return "Not configured";
}

static uint8_t severityOf(const Sys& s) {       // 0 green, 1 amber, 2 red
  if (s.latch != LATCH_NONE) return 2;
  switch (s.state) {
    case ST_IDLE: case ST_NORMAL: return 0;
    default: return 1;
  }
}

static bool tokenConfigured() {
  return strlen(CONTROL_TOKEN) >= 8 && strcmp(CONTROL_TOKEN, "CHANGE_ME_TOKEN") != 0;
}
static bool apPasswordIsDefault() { return strcmp(AP_PASSWORD, "CHANGE_ME_AP_PW") == 0; }

// ---- event log (keeps text JSON-safe; uses its own tiny lock) ----
static void logEvent(uint8_t code, const char* msg) {
  char clean[56];
  size_t i = 0;
  for (; i < sizeof(clean) - 1 && msg[i]; i++) {
    char c = msg[i];
    if (c == '"' || c == '\\') c = '\'';
    if ((uint8_t)c < 32) c = ' ';
    clean[i] = c;
  }
  clean[i] = 0;
  time_t nowT = time(nullptr);
  uint32_t epoch = (nowT > 1700000000L) ? (uint32_t)nowT : 0;   // 0 = clock not set -> show uptime
  uint32_t up = millis() / 1000UL;
  portENTER_CRITICAL(&evMux);
  EventRec& e = events[evHead];
  e.upSec = up; e.epoch = epoch; e.code = code;
  memcpy(e.msg, clean, sizeof(e.msg));
  evHead = (uint8_t)((evHead + 1) % EVENT_MAX);
  if (evCount < EVENT_MAX) evCount++;
  portEXIT_CRITICAL(&evMux);
  lastEventCode = code;
  Serial.printf("[EVT up=%lus] %s\n", (unsigned long)up, clean);
}

static uint8_t copyEvents(EventRec* out, uint8_t maxN) {        // newest first
  portENTER_CRITICAL(&evMux);
  uint8_t n = (evCount < maxN) ? evCount : maxN;
  for (uint8_t i = 0; i < n; i++) {
    int idx = (int)evHead - 1 - (int)i;
    if (idx < 0) idx += EVENT_MAX;
    out[i] = events[idx];
  }
  portEXIT_CRITICAL(&evMux);
  return n;
}

// ============================================================================
// SECTION 5 - PULSE COUNTING (interrupts)  - the ISR only counts
// ============================================================================
static void IRAM_ATTR isrFlowA() {
  uint32_t t = (uint32_t)micros();
  portENTER_CRITICAL_ISR(&pulseMux);
  if ((uint32_t)(t - lastEdgeUsA) >= (uint32_t)GLITCH_FILTER_US) { pulsesA = pulsesA + 1; lastEdgeUsA = t; }
  portEXIT_CRITICAL_ISR(&pulseMux);
}
static void IRAM_ATTR isrFlowB() {
  uint32_t t = (uint32_t)micros();
  portENTER_CRITICAL_ISR(&pulseMux);
  if ((uint32_t)(t - lastEdgeUsB) >= (uint32_t)GLITCH_FILTER_US) { pulsesB = pulsesB + 1; lastEdgeUsB = t; }
  portEXIT_CRITICAL_ISR(&pulseMux);
}
static void snapshotPulses(uint32_t* a, uint32_t* b) {           // atomic copy
  portENTER_CRITICAL(&pulseMux);
  *a = pulsesA; *b = pulsesB;
  portEXIT_CRITICAL(&pulseMux);
}

// ============================================================================
// SECTION 6 - RELAY AND PUMP
// ============================================================================
// The pump is wired to relay COM + NO, so with the relay de-energised the pump is OFF.
static void relayWrite(bool on) {
#if RELAY_ACTIVE_LOW
  if (on) {
    digitalWrite(PIN_RELAY_IN, LOW);
    pinMode(PIN_RELAY_IN, OUTPUT);
  } else {
  #if RELAY_OFF_HIGH_Z
    pinMode(PIN_RELAY_IN, INPUT);              // release the pin; the board's pull-up keeps it OFF
  #else
    digitalWrite(PIN_RELAY_IN, HIGH);
    pinMode(PIN_RELAY_IN, OUTPUT);
  #endif
  }
#else
  digitalWrite(PIN_RELAY_IN, on ? HIGH : LOW);
  pinMode(PIN_RELAY_IN, OUTPUT);
#endif
}

static void resetDetectorLocked() { lastCond = C_NONE; condCount = 0; idleFlowCount = 0; }

static void pumpOnLocked() {
  relayWrite(true);
  gSys.pumpOn = true;
  gSys.pumpStartMs = millis();
  gSys.stopReason[0] = 0;
  noFlowStopped = false;
  resetDetectorLocked();
  gSys.state = gSys.cal ? ST_STABILISING : ST_UNCAL;
  setNote(gSys.cal ? "Pump settling" : "Leak check OFF: calibrate K_A/K_B");
  logEvent(EV_PUMP_ON, "Pump ON");
}

static void pumpOffLocked(const char* why, bool logIt) {
  relayWrite(false);
  bool was = gSys.pumpOn;
  gSys.pumpOn = false;
  strncpy(gSys.stopReason, why, sizeof(gSys.stopReason) - 1);
  gSys.stopReason[sizeof(gSys.stopReason) - 1] = 0;
  baselineActive = false; gSys.baselineBusy = false;
  resetDetectorLocked();
  if (gSys.latch == LATCH_NONE && gSys.state != ST_STARTING) gSys.state = ST_IDLE;
  if (was && logIt) {
    char m[56]; snprintf(m, sizeof m, "Pump OFF: %s", why);
    logEvent(EV_PUMP_OFF, m);
  }
}

static void latchLocked(uint8_t type, uint8_t evCode, const char* msg) {
  pumpOffLocked("alarm", false);                 // relay OFF first
  gSys.latch = type;
  gSys.muted = false;
  gSys.state = (type == LATCH_LEAK) ? ST_LEAK
             : (type == LATCH_POSSIBLE_LEAK) ? ST_POSSIBLE_LEAK : ST_SENSOR_FAULT;
  setNote(type == LATCH_LEAK ? "Pump stopped. Fix leak, then RESET" : "Pump stopped. Inspect, then RESET");
  strncpy(gSys.stopReason, "alarm latched", sizeof(gSys.stopReason) - 1);
  logEvent(evCode, msg);
}

// ============================================================================
// SECTION 7 - SETTINGS (saved in flash by the network task)
// ============================================================================
static Preferences prefs;

static bool settingsValid(const Settings& s) {
  if (!(s.kA == 0.0f || (s.kA >= 1.0f && s.kA <= 200000.0f))) return false;
  if (!(s.kB == 0.0f || (s.kB >= 1.0f && s.kB <= 200000.0f))) return false;
  if (!(s.windowMs >= 1000 && s.windowMs <= 10000)) return false;
  if (!(s.zeroLpm >= 0.01f && s.zeroLpm <= 5.0f)) return false;
  if (!(s.minAbs >= 0.01f && s.minAbs <= 20.0f)) return false;
  if (!(s.relPct >= 1.0f && s.relPct <= 90.0f)) return false;
  if (!(s.persist >= 1 && s.persist <= 10)) return false;
  if (!(s.baseline >= -5.0f && s.baseline <= 5.0f)) return false;
  return true;
}

static void defaultSettings(Settings& s) {
  s.kA = DEFAULT_K_A; s.kB = DEFAULT_K_B; s.windowMs = DEFAULT_WINDOW_MS;
  s.zeroLpm = DEFAULT_ZERO_FLOW_LPM; s.minAbs = DEFAULT_MIN_ABS_DIFF;
  s.relPct = DEFAULT_REL_DIFF_PCT; s.persist = DEFAULT_PERSIST; s.baseline = DEFAULT_BASELINE_LPM;
}

static void loadSettings() {
  defaultSettings(gCfg);
  prefs.begin("jalsur", false);
  Settings s;
  s.kA = prefs.getFloat("kA", gCfg.kA);
  s.kB = prefs.getFloat("kB", gCfg.kB);
  s.windowMs = prefs.getUInt("win", gCfg.windowMs);
  s.zeroLpm = prefs.getFloat("zero", gCfg.zeroLpm);
  s.minAbs = prefs.getFloat("abs", gCfg.minAbs);
  s.relPct = prefs.getFloat("rel", gCfg.relPct);
  s.persist = prefs.getUChar("pers", gCfg.persist);
  s.baseline = prefs.getFloat("base", gCfg.baseline);
  wifiSsid = prefs.getString("ssid", WIFI_SSID_DEFAULT);
  wifiPass = prefs.getString("pass", WIFI_PASSWORD_DEFAULT);
  prefs.end();
  if (settingsValid(s)) gCfg = s;
  else Serial.println("[CFG] saved settings invalid -> defaults used");
  gSys.cal = (gCfg.kA >= 1.0f && gCfg.kB >= 1.0f);
}

static void saveSettingsNow() {
  Settings c;
  LOCK(); c = gCfg; UNLOCK();
  prefs.begin("jalsur", false);
  prefs.putFloat("kA", c.kA);
  prefs.putFloat("kB", c.kB);
  prefs.putUInt("win", c.windowMs);
  prefs.putFloat("zero", c.zeroLpm);
  prefs.putFloat("abs", c.minAbs);
  prefs.putFloat("rel", c.relPct);
  prefs.putUChar("pers", c.persist);
  prefs.putFloat("base", c.baseline);
  prefs.end();
  Serial.println("[CFG] settings saved");
}

// ============================================================================
// SECTION 8 - LEAK DETECTION LOGIC  (runs once per sampling window)
// ============================================================================
static uint8_t classifyWindow() {
  const float fA = gSys.fA, fB = gSys.fB;
  if (fA > SENSOR_MAX_PLAUSIBLE_LPM || fB > SENSOR_MAX_PLAUSIBLE_LPM) return C_IMPLAUSIBLE;
  const bool a = fA > gCfg.zeroLpm;
  const bool b = fB > gCfg.zeroLpm;
  if (!a && !b) return C_NOFLOW;                 // both quiet: "NO FLOW", never "LEAK"
  if (!a && b)  return C_A0_BFLOW;               // B without A: reverse flow / wiring / sensor
  if (a && !b)  return C_B0_AFLOW;               // A without B: severe leak, blockage or B fault
  const float d   = (fA - fB) - gCfg.baseline;   // corrected difference, positive = A greater
  const float ref = (fA > fB) ? fA : fB;
  const float rel = (ref > 0.001f) ? (fabsf(d) / ref * 100.0f) : 0.0f;
  if (fabsf(d) >= gCfg.minAbs && rel >= gCfg.relPct) return (d > 0.0f) ? C_LEAK : C_B_GT_A;
  return C_NORMAL;
}

static void finishBaselineLocked() {
  float mean = baselineSum / (float)baselineN;
  float meanFlow = baselineFlowSum / (float)baselineN;
  baselineActive = false; gSys.baselineBusy = false;
  if (fabsf(mean) > 0.30f * meanFlow) {
    setNote("Baseline rejected: check K values/leak");
    logEvent(EV_CAL, "Baseline rejected: difference too large");
    return;
  }
  gCfg.baseline = mean;
  settingsDirty = true;
  char m[56]; snprintf(m, sizeof m, "Baseline saved: %.3f L/min", mean);
  logEvent(EV_CAL, m);
  setNote("Baseline saved");
}

static void evaluateIdleLocked(uint32_t dA, uint32_t dB) {       // pump is OFF
  bool flowNow = gSys.cal ? (gSys.fA > gCfg.zeroLpm || gSys.fB > gCfg.zeroLpm) : (dA > 0 || dB > 0);
  if (flowNow) { if (idleFlowCount < 250) idleFlowCount++; } else idleFlowCount = 0;
  if (idleFlowCount >= IDLE_FLOW_WARN_WINDOWS) {
    gSys.state = ST_WARNING; setNote("Flow while pump OFF: siphon or leak?");
  } else if (noFlowStopped) {
    gSys.state = ST_NO_FLOW; setNote("Pump stopped: no flow. Check water, START");
  } else {
    gSys.state = ST_IDLE; setNote(gSys.stopReason[0] ? gSys.stopReason : "Ready. Pump OFF");
  }
}

static void evaluateRunningLocked(uint32_t now) {                // pump is ON
  uint32_t limit = gSys.cal ? PUMP_MAX_RUN_MS : UNCAL_RUN_MAX_MS;
  if (limit != 0 && (uint32_t)(now - gSys.pumpStartMs) > limit) {
    pumpOffLocked("run-time limit reached", true);
    return;
  }
  if ((uint32_t)(now - gSys.pumpStartMs) < PUMP_GRACE_MS) {
    gSys.state = gSys.cal ? ST_STABILISING : ST_UNCAL;
    resetDetectorLocked();
    return;
  }
  if (!gSys.cal) { gSys.state = ST_UNCAL; return; }              // leak check needs K_A and K_B

  const uint8_t c = classifyWindow();
  if (c == lastCond) { if (condCount < 250) condCount++; } else { lastCond = c; condCount = 1; }

  if (baselineActive) {                                          // learn the natural A-B offset
    baselineTries++;
    if (c != C_NOFLOW && c != C_IMPLAUSIBLE) {
      if (gSys.fA > gCfg.zeroLpm && gSys.fB > gCfg.zeroLpm) {
        baselineSum += gSys.diff; baselineFlowSum += gSys.fA; baselineN++;
      }
      gSys.state = ST_STABILISING; setNote("Capturing no-leak baseline...");
      if (baselineN >= BASELINE_WINDOWS) finishBaselineLocked();
      else if (baselineTries > (uint8_t)(3 * BASELINE_WINDOWS)) {
        baselineActive = false; gSys.baselineBusy = false;
        logEvent(EV_CAL, "Baseline aborted: flow not steady");
      }
      return;
    }
  }

  switch (c) {
    case C_NORMAL:
      gSys.state = ST_NORMAL; setNote("Flows match within tolerance");
      break;
    case C_B_GT_A:
      if (condCount >= gCfg.persist) { gSys.state = ST_WARNING; setNote("B higher than A: check calibration"); }
      else gSys.state = ST_NORMAL;
      break;
    case C_LEAK:
      if (condCount >= gCfg.persist) {
        char m[56]; snprintf(m, sizeof m, "LEAK A=%.2f B=%.2f L/min", gSys.fA, gSys.fB);
        latchLocked(LATCH_LEAK, EV_LEAK, m);
      } else { gSys.state = ST_SUSPECTED; setNote("A greater than B: confirming..."); }
      break;
    case C_B0_AFLOW:
      if (condCount >= gCfg.persist) latchLocked(LATCH_POSSIBLE_LEAK, EV_POSSIBLE_LEAK, "A flowing, B near zero: leak or B fault");
      else { gSys.state = ST_SUSPECTED; setNote("A flowing, B near zero..."); }
      break;
    case C_A0_BFLOW:
      if (condCount >= gCfg.persist) latchLocked(LATCH_SENSOR_FAULT, EV_SENSOR_FAULT, "A near zero but B flowing: sensor or reverse flow");
      else { gSys.state = ST_WARNING; setNote("B flowing, A near zero..."); }
      break;
    case C_IMPLAUSIBLE:
      if (condCount >= 2) latchLocked(LATCH_SENSOR_FAULT, EV_SENSOR_FAULT, "Implausible flow reading: check sensor wiring");
      else { gSys.state = ST_WARNING; setNote("Implausible flow reading"); }
      break;
    case C_NOFLOW:
      gSys.state = ST_NO_FLOW; setNote("Pump ON but no flow: tank empty/blocked?");
      if (NOFLOW_STOP_ENABLED && condCount >= NOFLOW_STOP_WINDOWS) {
        noFlowStopped = true;
        pumpOffLocked("no flow (dry-run guard)", true);
        logEvent(EV_NO_FLOW, "No flow while pump ON: pump stopped");
      }
      break;
    default: break;
  }
}

static void evaluateWindowLocked(uint32_t dA, uint32_t dB, uint32_t elapsedMs, uint32_t totA, uint32_t totB) {
  uint32_t now = millis();
  if (elapsedMs == 0) elapsedMs = 1;
  gSys.pulsesA = totA; gSys.pulsesB = totB;
  gSys.rateAHz = (float)dA * 1000.0f / (float)elapsedMs;
  gSys.rateBHz = (float)dB * 1000.0f / (float)elapsedMs;
  gSys.cal = (gCfg.kA >= 1.0f && gCfg.kB >= 1.0f);
  if (gSys.cal) {
    float mins = (float)elapsedMs / 60000.0f;
    gSys.fA = ((float)dA / gCfg.kA) / mins;
    gSys.fB = ((float)dB / gCfg.kB) / mins;
    gSys.volA = (float)totA / gCfg.kA;
    gSys.volB = (float)totB / gCfg.kB;
  } else {
    gSys.fA = gSys.fB = 0.0f; gSys.volA = gSys.volB = 0.0f;
  }
  gSys.diff = gSys.fA - gSys.fB;
  gSys.pct  = (gSys.fA > 0.001f) ? ((gSys.diff - gCfg.baseline) / gSys.fA * 100.0f) : 0.0f;
  if (dA != 0 || dB != 0) gSys.lastActivityMs = now;

  if (gSys.state == ST_STARTING) return;          // boot stabilisation is handled in loop()
  if (gSys.latch != LATCH_NONE) return;           // alarm stays latched until RESET
  if (gSys.pumpOn) evaluateRunningLocked(now);
  else             evaluateIdleLocked(dA, dB);
}

// ============================================================================
// SECTION 9 - COMMANDS (every command source goes through these safety checks)
// ============================================================================
static const char* startLocked() {
  if (!RELAY_POLARITY_VERIFIED)  return "Relay polarity not verified";
  if (gSys.state == ST_STARTING) return "System still starting";
  if (gSys.latch != LATCH_NONE)  return "Alarm latched: RESET first";
  if (gSys.pumpOn) return NULL;
  pumpOnLocked();
  return NULL;
}
static const char* cmdStart() { LOCK(); const char* r = startLocked(); UNLOCK(); return r; }

static void cmdStop() { LOCK(); pumpOffLocked("stopped by user", true); UNLOCK(); }   // never refused

static const char* cmdAck() {
  const char* r = NULL;
  LOCK();
  if (gSys.latch == LATCH_NONE) r = "No alarm to acknowledge";
  else { gSys.muted = true; logEvent(EV_ACK, "Alarm acknowledged: buzzer muted, latch kept"); }
  UNLOCK();
  return r;
}

static const char* cmdReset() {
  const char* r = NULL;
  LOCK();
  if (gSys.latch == LATCH_NONE) r = "Nothing to reset";
  else if (gSys.pumpOn) r = "Pump must be OFF first";
  else if ((uint32_t)(millis() - gSys.lastActivityMs) < RESET_QUIET_MS) r = "Wait: sensors not quiet for 5 s";
  else {
    gSys.latch = LATCH_NONE; gSys.muted = false; gSys.state = ST_IDLE;
    strncpy(gSys.stopReason, "reset: pump stays OFF", sizeof(gSys.stopReason) - 1);
    setNote("Reset done. Pump OFF. Press START");
    logEvent(EV_RESET, "Alarm reset by operator; pump stays OFF");
  }
  UNLOCK();
  return r;
}

static void cmdCalZero() {
  uint32_t a, b; snapshotPulses(&a, &b);
  calBaseA = a; calBaseB = b;
  logEvent(EV_CAL, "Calibration counters zeroed");
}

static const char* cmdCalSave(float litres) {
  if (!(litres >= 0.2f && litres <= 100.0f)) return "Litres must be 0.2 to 100";
  uint32_t a, b; snapshotPulses(&a, &b);
  uint32_t dA = a - calBaseA, dB = b - calBaseB;
  if (dA < 50 || dB < 50) return "Too few pulses (<50): pass more water";
  LOCK();
  if (gSys.pumpOn) { UNLOCK(); return "Stop the pump first"; }
  gCfg.kA = (float)dA / litres;
  gCfg.kB = (float)dB / litres;
  gCfg.baseline = 0.0f;
  gSys.cal = true; baselineActive = false;
  UNLOCK();
  settingsDirty = true;
  char m[56]; snprintf(m, sizeof m, "K saved: A=%.1f B=%.1f pulses/L", gCfg.kA, gCfg.kB);
  logEvent(EV_CAL, m);
  return NULL;
}

static const char* cmdBaseline() {
  const char* r = NULL;
  LOCK();
  if (!gSys.cal) r = "Calibrate K_A and K_B first";
  else if (!gSys.pumpOn) r = "Start the pump first (leak closed)";
  else if (gSys.latch != LATCH_NONE) r = "Alarm latched";
  else {
    baselineActive = true; gSys.baselineBusy = true;
    baselineSum = 0.0f; baselineFlowSum = 0.0f; baselineN = 0; baselineTries = 0;
  }
  UNLOCK();
  return r;
}

// ============================================================================
// SECTION 10 - LEDs, BUZZER, BUTTON
// ============================================================================
#if BUZZER_IS_PASSIVE
  #if ESP_ARDUINO_VERSION_MAJOR >= 3
    static void buzzerInit() { ledcAttach(PIN_BUZZER, BUZZER_TONE_HZ, 8); ledcWriteTone(PIN_BUZZER, 0); }
    static void buzzerTone(uint32_t hz) { ledcWriteTone(PIN_BUZZER, hz); }
  #else
    #define BUZZER_LEDC_CH 0
    static void buzzerInit() {
      ledcSetup(BUZZER_LEDC_CH, BUZZER_TONE_HZ, 8);
      ledcAttachPin(PIN_BUZZER, BUZZER_LEDC_CH);
      ledcWriteTone(BUZZER_LEDC_CH, 0);
    }
    static void buzzerTone(uint32_t hz) { ledcWriteTone(BUZZER_LEDC_CH, hz); }
  #endif
#endif

static void buzzerWrite(bool on) {
  static int8_t last = -1;
  if ((int8_t)on == last) return;
  last = (int8_t)on;
#if BUZZER_IS_PASSIVE
  buzzerTone(on ? (uint32_t)BUZZER_TONE_HZ : 0);
#else
  digitalWrite(PIN_BUZZER, on ? HIGH : LOW);
#endif
}

static void outputsService(uint32_t now) {
  const uint8_t st = gSys.state, lt = gSys.latch, nm = gSys.netMode;
  const bool muted = gSys.muted;
  const bool slow = ((now / 500UL) & 1UL) != 0;
  const bool fast = ((now / 125UL) & 1UL) != 0;

  bool green = false, red = false, yellow = false;
  if (lt == LATCH_LEAK) red = true;
  else if (lt != LATCH_NONE) red = fast;

  if (st == ST_NORMAL) green = true;
  else if (st == ST_IDLE && lt == LATCH_NONE) green = slow;

  if (st == ST_STARTING || st == ST_STABILISING || st == ST_WARNING ||
      st == ST_SUSPECTED || st == ST_NO_FLOW) yellow = true;
  else if (st == ST_UNCAL) yellow = slow;
  else if (lt == LATCH_NONE && nm != NET_STA && (st == ST_IDLE || st == ST_NORMAL))
    yellow = ((now % 2000UL) < 100UL);                           // short blip = Wi-Fi offline

  digitalWrite(PIN_LED_RED, red ? HIGH : LOW);
  digitalWrite(PIN_LED_GREEN, green ? HIGH : LOW);
#if HAS_YELLOW_LED
  digitalWrite(PIN_LED_YELLOW, yellow ? HIGH : LOW);
#else
  (void)yellow;
#endif

  bool buz = false;
  if (!muted) {
    if (lt == LATCH_LEAK) buz = ((now % 500UL) < 250UL);
    else if (lt != LATCH_NONE) buz = ((now % 1000UL) < 200UL);
  }
  if ((int32_t)(beepUntilMs - now) > 0) buz = true;
  buzzerWrite(buz);
}

static void flashMessage(const char* title, const char* reason) {
  strncpy(flashTitle, title, sizeof(flashTitle) - 1); flashTitle[sizeof(flashTitle) - 1] = 0;
  strncpy(flashReason, reason ? reason : "", sizeof(flashReason) - 1); flashReason[sizeof(flashReason) - 1] = 0;
  flashUntil = millis() + 2500UL;
  beepUntilMs = millis() + 80UL;
}

static void buttonAck() {
  const char* r = cmdAck();
  flashMessage(r ? "NO ALARM" : "BUZZER MUTED", r ? r : "Leak stays LATCHED");
}
static void buttonReset() {
  const char* r = cmdReset();
  flashMessage(r ? "RESET REFUSED" : "RESET OK", r ? r : "Pump OFF. Double-click=START");
  if (r) logEvent(EV_REJECT, r);
}
static void buttonPumpToggle() {
  if (gSys.pumpOn) { cmdStop(); flashMessage("PUMP STOPPED", ""); return; }
  const char* r = cmdStart();
  flashMessage(r ? "START REFUSED" : "PUMP START", r ? r : "Settling...");
  if (r) logEvent(EV_REJECT, r);
}

static void buttonService(uint32_t now) {
  static bool raw = false, stable = false, longFired = false;
  static uint32_t changeMs = 0, pressMs = 0, lastClickMs = 0;
  static uint8_t clicks = 0;

  bool r = (digitalRead(PIN_BUTTON) == LOW);                     // pressed = LOW (INPUT_PULLUP)
  if (r != raw) { raw = r; changeMs = now; }
  if (raw != stable && (uint32_t)(now - changeMs) >= BTN_DEBOUNCE_MS) {
    stable = raw;
    if (stable) { pressMs = now; longFired = false; }
    else if (!longFired) { clicks++; lastClickMs = now; }        // a short click ended
  }
  if (stable && !longFired && (uint32_t)(now - pressMs) >= BTN_LONG_MS) {
    longFired = true; clicks = 0;
    buttonReset();
  }
  if (clicks > 0 && !stable && (uint32_t)(now - lastClickMs) >= BTN_DOUBLE_MS) {
    if (clicks == 1) buttonAck(); else buttonPumpToggle();
    clicks = 0;
  }
}

// ============================================================================
// SECTION 11 - OLED (128x64 SSD1306, I2C)
// ============================================================================
static Adafruit_SSD1306 display(128, 64, &Wire, -1);
static bool oledOk = false;
static uint8_t oledAddr = 0, oledFail = 0;
static uint32_t oledProbeMs = 0;

static bool i2cPresent(uint8_t a) { Wire.beginTransmission(a); return Wire.endTransmission() == 0; }

static void i2cScanLog() {
  Serial.print("[I2C] devices found:");
  uint8_t n = 0;
  for (uint8_t a = 1; a < 127; a++) {
    if (i2cPresent(a)) { Serial.printf(" 0x%02X", a); n++; }
  }
  if (!n) Serial.print(" none (check SDA/SCL/power)");
  Serial.println();
}

static bool oledTryInit() {
  uint8_t found = 0;
  if (i2cPresent(OLED_ADDR_1)) found = OLED_ADDR_1;
  else if (i2cPresent(OLED_ADDR_2)) found = OLED_ADDR_2;
  if (found && display.begin(SSD1306_SWITCHCAPVCC, found, true, false)) {
    oledOk = true; oledAddr = found; oledFail = 0;
    display.clearDisplay(); display.setTextColor(SSD1306_WHITE); display.setTextSize(1);
    display.setCursor(0, 0);  display.println("JAL-SURAKSHA");
    display.setCursor(0, 12); display.println("Starting...");
    display.display();
    Serial.printf("[OLED] ready at 0x%02X\n", found);
    return true;
  }
  oledOk = false;
  return false;
}

static void oledPageMain(const Sys& s) {
  char b[28];
  display.setTextSize(1);
  display.setCursor(0, 0);
  snprintf(b, sizeof b, "JAL-SURAKSHA  PUMP:%s", s.pumpOn ? "ON" : "OFF"); display.print(b);
  if (s.cal) {
    snprintf(b, sizeof b, "Flow A:%6.2f L/min", f0(s.fA));  display.setCursor(0, 12); display.print(b);
    snprintf(b, sizeof b, "Flow B:%6.2f L/min", f0(s.fB));  display.setCursor(0, 22); display.print(b);
    snprintf(b, sizeof b, "Diff  :%6.2f L/min", f0(s.diff)); display.setCursor(0, 32); display.print(b);
  } else {
    snprintf(b, sizeof b, "A:%5.1fHz B:%5.1fHz", f0(s.rateAHz), f0(s.rateBHz));
    display.setCursor(0, 12); display.print(b);
    display.setCursor(0, 22); display.print("NOT CALIBRATED");
    display.setCursor(0, 32); display.print("Leak check is OFF");
  }
  display.setTextSize(2); display.setCursor(0, 46); display.print(stateShort(s.state));
}

static void oledPageNet(const Sys& s) {
  char b[28];
  display.setTextSize(1);
  display.setCursor(0, 0);  display.print("JAL-SURAKSHA  status");
  snprintf(b, sizeof b, "Pump : %s", s.pumpOn ? "ON" : "OFF"); display.setCursor(0, 11); display.print(b);
  snprintf(b, sizeof b, "Wi-Fi: %s", s.netMode == NET_STA ? "CONNECTED" : (s.netMode == NET_AP ? "OFFLINE (AP)" : "OFFLINE"));
  display.setCursor(0, 21); display.print(b);
  snprintf(b, sizeof b, "Cloud: %s", cloudText(s.cloud)); display.setCursor(0, 31); display.print(b);
  snprintf(b, sizeof b, "A:%.2fL B:%.2fL", f0(s.volA), f0(s.volB)); display.setCursor(0, 41); display.print(b);
  snprintf(b, sizeof b, "IP:%s", s.ip[0] ? s.ip : "-"); display.setCursor(0, 51); display.print(b);
}

static void oledPageAlarm(const Sys& s) {
  char b[28];
  display.setTextSize(1);
  display.setCursor(0, 0); display.print("JAL-SURAKSHA PUMP OFF");
  display.setTextSize(2); display.setCursor(0, 10);
  display.print(s.latch == LATCH_LEAK ? "LEAK!" : (s.latch == LATCH_POSSIBLE_LEAK ? "POSS.LEAK" : "SENSOR?"));
  display.setTextSize(1);
  display.setCursor(0, 30);
  if (s.latch == LATCH_SENSOR_FAULT) display.print("Check sensor A / B");
  else display.print(s.latch == LATCH_LEAK ? "Loc: BETWEEN A & B" : "Loc: A-B (unconfirmed)");
  snprintf(b, sizeof b, "A:%.2f B:%.2f L/min", f0(s.fA), f0(s.fB)); display.setCursor(0, 40); display.print(b);
  display.setCursor(0, 51); display.print(s.muted ? "Muted. Hold=RESET" : "Click=mute Hold=RESET");
}

static void oledService(uint32_t now) {
  if (!oledOk) {
    if ((uint32_t)(now - oledProbeMs) > 10000UL) { oledProbeMs = now; oledTryInit(); }
    return;
  }
  if ((uint32_t)(now - oledProbeMs) > 5000UL) {                  // is the display still there?
    oledProbeMs = now;
    if (i2cPresent(oledAddr)) oledFail = 0;
    else if (++oledFail >= 3) { oledOk = false; Serial.println("[OLED] lost"); return; }
  }
  Sys s;
  LOCK(); s = gSys; UNLOCK();
  display.clearDisplay(); display.setTextColor(SSD1306_WHITE);
  if ((int32_t)(flashUntil - now) > 0) {
    display.setTextSize(2); display.setCursor(0, 0); display.print(flashTitle);
    display.setTextSize(1); display.setCursor(0, 36); display.print(flashReason);
  } else if (s.latch != LATCH_NONE) {
    oledPageAlarm(s);
  } else if (((now / OLED_PAGE_MS) & 1UL) == 0) {
    oledPageMain(s);
  } else {
    oledPageNet(s);
  }
  display.display();
}

// ============================================================================
// SECTION 12 - DASHBOARD PAGE (served by the ESP32; works on a phone browser)
// ============================================================================
static const char INDEX_HTML[] PROGMEM = R"rawliteral(<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>JAL-SURAKSHA</title>
<style>
:root{--bg:#0f172a;--cd:#1e293b;--tx:#e2e8f0;--mu:#94a3b8;--ok:#15803d;--wa:#b45309;--er:#b91c1c}
*{box-sizing:border-box}
body{margin:0;font-family:system-ui,Arial,sans-serif;background:var(--bg);color:var(--tx)}
header{padding:12px 14px;background:var(--cd)}
h1{margin:0;font-size:18px}small{color:var(--mu)}
#st{margin:10px;padding:14px;border-radius:12px;font-size:20px;font-weight:700;text-align:center}
.sev0{background:var(--ok)}.sev1{background:var(--wa)}.sev2{background:var(--er)}
.g{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:10px}
.c{background:var(--cd);border-radius:12px;padding:10px}
.c span{color:var(--mu);font-size:12px;display:block}
.c b{font-size:20px;word-break:break-word}
.w{margin:10px;background:var(--cd);border-radius:12px;padding:10px;font-size:14px}
.warn{margin:10px;padding:10px;border-radius:10px;background:#422006;color:#fde68a;font-size:13px}
button{padding:12px 14px;margin:4px 2px;border:0;border-radius:10px;font-size:15px;font-weight:600;color:#fff;background:#334155}
.go{background:#15803d}.no{background:#b91c1c}
input{width:100%;padding:9px;margin:3px 0 8px;border-radius:8px;border:1px solid #475569;background:#0f172a;color:var(--tx)}
label{font-size:12px;color:var(--mu)}
details{margin:10px;background:var(--cd);border-radius:12px;padding:10px}
summary{font-weight:600}
table{width:100%;font-size:12px;border-collapse:collapse}
td{padding:4px;border-bottom:1px solid #334155;vertical-align:top}
.ok{color:#86efac}.bad{color:#fca5a5}
</style></head><body>
<header><h1>JAL-SURAKSHA</h1><small>Save Water, Secure Tomorrow</small></header>
<div id="st" class="sev1">Connecting...</div>
<div id="warn"></div>
<div class="g">
 <div class="c"><span>Flow A (upstream)</span><b id="fa">--</b></div>
 <div class="c"><span>Flow B (downstream)</span><b id="fb">--</b></div>
 <div class="c"><span>Difference A-B</span><b id="df">--</b></div>
 <div class="c"><span>Difference %</span><b id="pc">--</b></div>
 <div class="c"><span>Total A</span><b id="va">--</b></div>
 <div class="c"><span>Total B</span><b id="vb">--</b></div>
 <div class="c"><span>Pump</span><b id="pu">--</b></div>
 <div class="c"><span>Suspected segment</span><b id="loc">--</b></div>
</div>
<div class="w" id="info">--</div>
<div class="w">
 <label>Control password (CONTROL_TOKEN)</label>
 <input id="tok" type="password" autocomplete="off" placeholder="enter once per session">
 <button class="go" onclick="cmd('start')">START</button>
 <button class="no" onclick="cmd('stop')">STOP</button>
 <button onclick="cmd('ack')">ACKNOWLEDGE</button>
 <button onclick="cmd('reset')">RESET</button>
 <div id="msg"></div>
</div>
<details><summary>Calibration and settings</summary>
 <p><small>1) Stop pump. 2) Zero counters. 3) Run a measured volume through (leak closed). 4) Enter litres, compute K. Then run normally and capture the baseline.</small></p>
 <button onclick="cmd('calzero')">1. Zero counters</button>
 <div id="cal">--</div>
 <label>Litres measured</label><input id="lit" type="number" step="0.01" placeholder="e.g. 1.00">
 <button onclick="calsave()">2. Compute and save K_A, K_B</button>
 <button onclick="cmd('baseline')">3. Capture no-leak baseline (pump running)</button>
 <hr>
 <label>K_A pulses/litre (0 = not calibrated)</label><input id="kA">
 <label>K_B pulses/litre (0 = not calibrated)</label><input id="kB">
 <label>Sampling window (ms, 1000-10000)</label><input id="win">
 <label>No-flow threshold (L/min)</label><input id="zero">
 <label>Minimum difference (L/min)</label><input id="abs">
 <label>Relative difference (%)</label><input id="rel">
 <label>Persistence (windows in a row)</label><input id="pers">
 <label>Baseline offset A-B (L/min)</label><input id="base">
 <button onclick="setcfg()">Save settings (pump must be OFF)</button>
</details>
<details><summary>Wi-Fi setup</summary>
 <label>Wi-Fi name</label><input id="ssid" autocomplete="off">
 <label>Wi-Fi password</label><input id="wpass" type="password" autocomplete="off">
 <button onclick="setwifi()">Save and connect</button>
</details>
<details open><summary>Event log</summary><table id="ev"></table></details>
<div class="w"><small>Location = segment estimate only (between Sensor A and Sensor B). Two sensors cannot give an exact point or distance. Readings are estimates until you calibrate. Educational prototype: plain HTTP, use only on a trusted network.</small></div>
<script>
const $=i=>document.getElementById(i);
let tok=sessionStorage.getItem('tok')||'',filled=false;
$('tok').value=tok;
$('tok').oninput=e=>{tok=e.target.value;sessionStorage.setItem('tok',tok)};
function up(s){return Math.floor(s/3600)+'h '+Math.floor(s%3600/60)+'m '+(s%60)+'s'}
async function cmd(c,x){
 const b=new URLSearchParams(x||{});b.set('c',c);b.set('t',tok);
 const m=$('msg');
 try{const r=await fetch('/api/cmd',{method:'POST',body:b});const j=await r.json();
  m.textContent=j.msg;m.className=j.ok?'ok':'bad';}
 catch(e){m.textContent='No connection to device';m.className='bad';}
 poll();
}
function setcfg(){cmd('set',{kA:$('kA').value,kB:$('kB').value,win:$('win').value,zero:$('zero').value,abs:$('abs').value,rel:$('rel').value,pers:$('pers').value,base:$('base').value})}
function setwifi(){cmd('wifi',{ssid:$('ssid').value,pass:$('wpass').value})}
function calsave(){cmd('calsave',{l:$('lit').value})}
async function poll(){
 try{
  const r=await fetch('/api/status',{cache:'no-store'});const s=await r.json();
  const st=$('st');st.textContent=s.state+(s.latch!=='none'?'  [LATCHED]':'');st.className='sev'+s.sev;
  $('fa').textContent=s.cal?s.fa.toFixed(2)+' L/min':s.ra.toFixed(1)+' Hz';
  $('fb').textContent=s.cal?s.fb.toFixed(2)+' L/min':s.rb.toFixed(1)+' Hz';
  $('df').textContent=s.cal?s.diff.toFixed(2)+' L/min':'--';
  $('pc').textContent=s.cal?s.pct.toFixed(1)+' %':'--';
  $('va').textContent=s.cal?s.va.toFixed(2)+' L':s.pa+' pulses';
  $('vb').textContent=s.cal?s.vb.toFixed(2)+' L':s.pb+' pulses';
  $('pu').textContent=s.pump?'ON':'OFF';
  $('loc').textContent=s.loc;
  $('info').textContent='Sensors: '+s.sens+' | Wi-Fi: '+s.wifi+' '+s.ip+' ('+s.rssi+' dBm) | Cloud: '+s.cloud+' | Uptime: '+up(s.up)+' | '+s.note+(s.muted?' | buzzer muted':'');
  $('cal').textContent='Pulses since zero: A='+s.cpa+'  B='+s.cpb;
  let w='';
  if(!s.tokOk)w+='<div class="warn">Control is LOCKED: set CONTROL_TOKEN in the firmware (8+ characters).</div>';
  if(s.apDef)w+='<div class="warn">Default setup-hotspot password in use: change AP_PASSWORD before deployment.</div>';
  if(!s.cal)w+='<div class="warn">Not calibrated: leak detection is OFF until K_A and K_B are saved.</div>';
  if(!s.relayOk)w+='<div class="warn">Relay polarity not verified: START is disabled (see manual, test R2).</div>';
  $('warn').innerHTML=w;
  if(!filled){['kA','kB','win','zero','abs','rel','pers','base'].forEach(k=>{$(k).value=s.cfg[k]});filled=true;}
 }catch(e){$('st').textContent='OFFLINE: no data from device';$('st').className='sev1';}
}
async function ev(){
 try{const r=await fetch('/api/events',{cache:'no-store'});const a=await r.json();
  $('ev').innerHTML=a.map(e=>'<tr><td>'+(e.t>0?new Date(e.t*1000).toLocaleString():'up '+up(e.u))+'</td><td>'+e.m.replace(/&/g,'&amp;').replace(/</g,'&lt;')+'</td></tr>').join('');
 }catch(e){}
}
poll();ev();setInterval(poll,1000);setInterval(ev,5000);
</script></body></html>)rawliteral";

// ============================================================================
// SECTION 13 - NETWORK TASK (Wi-Fi, web dashboard, optional MQTT)
//   Runs on core 0. The safety loop (core 1) never waits for it.
// ============================================================================
static WebServer server(80);
static bool apActive = false, staWasUp = false;
static uint32_t staStartMs = 0, lastStaTryMs = 0;
static volatile bool wifiDirty = false;
static uint8_t authFails = 0;
static uint32_t authLockUntil = 0;

#if MQTT_ENABLED
  #if MQTT_USE_TLS
    static WiFiClientSecure mqttNet;
  #else
    static WiFiClient mqttNet;
  #endif
  static PubSubClient mqtt(mqttNet);
  static uint32_t mqttLastTry = 0, mqttLastPub = 0;
  static bool mqttConfigured() {
    if (strlen(MQTT_HOST) == 0 || strcmp(MQTT_HOST, "broker.example.com") == 0) return false;
  #if MQTT_USE_TLS
    if (strlen(MQTT_CA_CERT) < 100) return false;            // no certificate pasted
  #endif
    return true;
  }
#endif

static uint8_t cloudStateNow() {
#if MQTT_ENABLED
  if (!mqttConfigured()) return 0;
  return mqtt.connected() ? 2 : 1;
#else
  return 0;
#endif
}

#if MQTT_ENABLED
static void mqttService() {
  if (!mqttConfigured() || WiFi.status() != WL_CONNECTED) return;
  uint32_t now = millis();
  char topic[96];
  if (!mqtt.connected()) {
    if (mqttLastTry != 0 && (uint32_t)(now - mqttLastTry) < MQTT_RETRY_MS) return;
    mqttLastTry = now;
  #if MQTT_USE_TLS
    mqttNet.setCACert(MQTT_CA_CERT);
  #endif
    mqtt.setServer(MQTT_HOST, MQTT_PORT);
    mqtt.setBufferSize(512);
    mqtt.setSocketTimeout(3);
    snprintf(topic, sizeof topic, "%s/%s/status", MQTT_TOPIC_PREFIX, MQTT_DEVICE_ID);
    bool ok = (strlen(MQTT_USER) > 0)
      ? mqtt.connect(MQTT_DEVICE_ID, MQTT_USER, MQTT_PASSWORD, topic, 0, true, "offline")
      : mqtt.connect(MQTT_DEVICE_ID, NULL, NULL, topic, 0, true, "offline");
    if (ok) mqtt.publish(topic, "online", true);
    else Serial.printf("[MQTT] connect failed, state=%d\n", mqtt.state());   // never prints credentials
    return;
  }
  mqtt.loop();
  if ((uint32_t)(now - mqttLastPub) >= MQTT_PUBLISH_MS) {
    mqttLastPub = now;
    Sys s;
    LOCK(); s = gSys; UNLOCK();
    char buf[420];
    snprintf(buf, sizeof buf,
      "{\"deviceId\":\"%s\",\"flowA\":%.2f,\"flowB\":%.2f,\"difference\":%.2f,"
      "\"totalVolume\":%.2f,\"totalVolumeB\":%.2f,\"leakState\":\"%s\",\"locationSegment\":\"%s\","
      "\"pumpState\":\"%s\",\"sensorHealth\":\"%s\",\"eventCode\":%u}",
      MQTT_DEVICE_ID, f0(s.fA), f0(s.fB), f0(s.diff), f0(s.volA), f0(s.volB),
      stateText(s.state), locationText(s), s.pumpOn ? "ON" : "OFF", sensorHealthText(s),
      (unsigned)lastEventCode);
    snprintf(topic, sizeof topic, "%s/%s/telemetry", MQTT_TOPIC_PREFIX, MQTT_DEVICE_ID);
    mqtt.publish(topic, buf);
  }
}
#endif

// ---- Wi-Fi management ----
static void netStartAP() {
  if (apActive) return;
  WiFi.mode(wifiSsid.length() ? WIFI_AP_STA : WIFI_AP);
  apActive = WiFi.softAP(AP_SSID, AP_PASSWORD);
  Serial.printf("[NET] setup hotspot %s\n", apActive ? "started" : "FAILED (AP_PASSWORD needs 8+ characters)");
  if (apActive && apPasswordIsDefault()) Serial.println("[NET] WARNING: default AP_PASSWORD in use - change it");
  logEvent(EV_WIFI, apActive ? "Setup hotspot started" : "Setup hotspot failed");
}

static void netStaBegin() {
  if (wifiSsid.length() == 0) return;
  WiFi.mode(apActive ? WIFI_AP_STA : WIFI_STA);
  WiFi.begin(wifiSsid.c_str(), wifiPass.c_str());
  staStartMs = millis(); lastStaTryMs = staStartMs;
}

static void netManageWifi() {
  uint32_t now = millis();
  bool up = (WiFi.status() == WL_CONNECTED);
  if (up && !staWasUp) {
    staWasUp = true;
    logEvent(EV_WIFI, "Wi-Fi connected");
    if (apActive) { WiFi.softAPdisconnect(true); apActive = false; }
    configTime(TZ_OFFSET_SEC, 0, "pool.ntp.org", "time.google.com");
    MDNS.end();
    if (MDNS.begin(MDNS_NAME)) MDNS.addService("http", "tcp", 80);
  } else if (!up && staWasUp) {
    staWasUp = false;
    staStartMs = now; lastStaTryMs = now;
    logEvent(EV_WIFI, "Wi-Fi lost: local protection continues");
  }
  if (!up) {
    bool haveSsid = wifiSsid.length() > 0;
    if (!apActive && (!haveSsid || (uint32_t)(now - staStartMs) > WIFI_AP_FALLBACK_MS)) netStartAP();
    if (haveSsid && (uint32_t)(now - lastStaTryMs) > WIFI_RETRY_MS) {
      lastStaTryMs = now;
      WiFi.disconnect(false);
      WiFi.begin(wifiSsid.c_str(), wifiPass.c_str());
    }
  }
  if (wifiDirty) {
    wifiDirty = false;
    prefs.begin("jalsur", false);
    prefs.putString("ssid", wifiSsid);
    prefs.putString("pass", wifiPass);
    prefs.end();
    logEvent(EV_WIFI, "Wi-Fi settings changed");
    WiFi.disconnect(false);
    netStaBegin();
  }
}

static void netUpdateStatus() {
  uint8_t mode = NET_OFFLINE; char ip[16] = "-"; int8_t rssi = 0;
  if (WiFi.status() == WL_CONNECTED) {
    mode = NET_STA; rssi = (int8_t)WiFi.RSSI();
    strncpy(ip, WiFi.localIP().toString().c_str(), sizeof(ip) - 1);
  } else if (apActive) {
    mode = NET_AP;
    strncpy(ip, WiFi.softAPIP().toString().c_str(), sizeof(ip) - 1);
  }
  ip[sizeof(ip) - 1] = 0;
  uint8_t cloud = cloudStateNow();
  LOCK();
  gSys.netMode = mode; gSys.rssi = rssi; gSys.cloud = cloud;
  memcpy(gSys.ip, ip, sizeof(gSys.ip));
  UNLOCK();
}

// ---- JSON builders ----
static String buildStatusJson() {
  Sys s; Settings c;
  LOCK(); s = gSys; c = gCfg; UNLOCK();
  uint32_t a, b; snapshotPulses(&a, &b);
  char buf[1300];
  snprintf(buf, sizeof buf,
    "{\"fa\":%.2f,\"fb\":%.2f,\"diff\":%.2f,\"pct\":%.1f,\"ra\":%.1f,\"rb\":%.1f,"
    "\"va\":%.2f,\"vb\":%.2f,\"pa\":%lu,\"pb\":%lu,\"cpa\":%lu,\"cpb\":%lu,"
    "\"state\":\"%s\",\"sev\":%u,\"latch\":\"%s\",\"loc\":\"%s\",\"pump\":%s,\"muted\":%s,"
    "\"cal\":%s,\"bl\":%s,\"sens\":\"%s\",\"wifi\":\"%s\",\"rssi\":%d,\"ip\":\"%s\","
    "\"cloud\":\"%s\",\"up\":%lu,\"note\":\"%s\",\"stop\":\"%s\","
    "\"tokOk\":%s,\"apDef\":%s,\"relayOk\":%s,\"ev\":%u,"
    "\"cfg\":{\"kA\":%.3f,\"kB\":%.3f,\"win\":%lu,\"zero\":%.2f,\"abs\":%.2f,\"rel\":%.1f,\"pers\":%u,\"base\":%.3f}}",
    f0(s.fA), f0(s.fB), f0(s.diff), f0(s.pct), f0(s.rateAHz), f0(s.rateBHz),
    f0(s.volA), f0(s.volB), (unsigned long)s.pulsesA, (unsigned long)s.pulsesB,
    (unsigned long)(a - calBaseA), (unsigned long)(b - calBaseB),
    stateText(s.state), (unsigned)severityOf(s), latchText(s.latch), locationText(s),
    s.pumpOn ? "true" : "false", s.muted ? "true" : "false",
    s.cal ? "true" : "false", s.baselineBusy ? "true" : "false",
    sensorHealthText(s),
    s.netMode == NET_STA ? "CONNECTED" : (s.netMode == NET_AP ? "AP MODE" : "OFFLINE"),
    (int)s.rssi, s.ip[0] ? s.ip : "-",
    cloudText(s.cloud), (unsigned long)(millis() / 1000UL), s.note, s.stopReason,
    tokenConfigured() ? "true" : "false", apPasswordIsDefault() ? "true" : "false",
    RELAY_POLARITY_VERIFIED ? "true" : "false", (unsigned)lastEventCode,
    f0(c.kA), f0(c.kB), (unsigned long)c.windowMs, f0(c.zeroLpm), f0(c.minAbs), f0(c.relPct),
    (unsigned)c.persist, f0(c.baseline));
  return String(buf);
}

static String buildEventsJson() {
  EventRec ev[20];
  uint8_t n = copyEvents(ev, 20);
  String out; out.reserve(2000);
  out += '[';
  for (uint8_t i = 0; i < n; i++) {
    char one[120];
    snprintf(one, sizeof one, "%s{\"t\":%lu,\"u\":%lu,\"c\":%u,\"m\":\"%s\"}",
             i ? "," : "", (unsigned long)ev[i].epoch, (unsigned long)ev[i].upSec,
             (unsigned)ev[i].code, ev[i].msg);
    out += one;
  }
  out += ']';
  return out;
}

// ---- HTTP handlers ----
static void sendJson(int code, const String& body) {
  server.sendHeader("Cache-Control", "no-store");
  server.send(code, "application/json", body);
}
static void replyMsg(int code, bool ok, const char* msg) {
  String b = String("{\"ok\":") + (ok ? "true" : "false") + ",\"msg\":\"" + msg + "\"}";
  sendJson(code, b);
}

static bool authLocked() { return authLockUntil != 0 && (int32_t)(authLockUntil - millis()) > 0; }

static bool tokenMatches(const String& t) {                      // constant-time compare
  const char* ref = CONTROL_TOKEN;
  size_t n = strlen(ref);
  uint8_t diff = (t.length() == n) ? 0 : 1;
  for (size_t i = 0; i < n; i++) {
    char ch = (i < t.length()) ? t[i] : (char)0;
    diff |= (uint8_t)(ch ^ ref[i]);
  }
  return diff == 0;
}

static bool authCheck() {
  if (authLocked()) return false;
  if (tokenMatches(server.arg("t"))) { authFails = 0; return true; }
  if (++authFails >= 5) { authFails = 0; authLockUntil = millis() + 60000UL; }   // 1 minute lock-out
  return false;
}

static const char* cmdSettingsFromRequest() {
  Settings n;
  LOCK(); n = gCfg; UNLOCK();
  if (server.arg("kA").length())   n.kA = server.arg("kA").toFloat();
  if (server.arg("kB").length())   n.kB = server.arg("kB").toFloat();
  if (server.arg("win").length())  n.windowMs = (uint32_t)server.arg("win").toInt();
  if (server.arg("zero").length()) n.zeroLpm = server.arg("zero").toFloat();
  if (server.arg("abs").length())  n.minAbs = server.arg("abs").toFloat();
  if (server.arg("rel").length())  n.relPct = server.arg("rel").toFloat();
  if (server.arg("pers").length()) n.persist = (uint8_t)server.arg("pers").toInt();
  if (server.arg("base").length()) n.baseline = server.arg("base").toFloat();
  if (!settingsValid(n)) return "Invalid value: see allowed ranges in the manual";
  LOCK();
  if (gSys.pumpOn) { UNLOCK(); return "Stop the pump before changing settings"; }
  gCfg = n;
  gSys.cal = (gCfg.kA >= 1.0f && gCfg.kB >= 1.0f);
  baselineActive = false; gSys.baselineBusy = false;
  UNLOCK();
  settingsDirty = true;
  logEvent(EV_SETTINGS, "Settings changed from dashboard");
  return NULL;
}

static const char* cmdWifiFromRequest() {
  String s = server.arg("ssid"), p = server.arg("pass");
  if (s.length() == 0 || s.length() > 32) return "Wi-Fi name must be 1-32 characters";
  if (p.length() > 0 && (p.length() < 8 || p.length() > 63)) return "Wi-Fi password must be 8-63 characters";
  wifiSsid = s; wifiPass = p; wifiDirty = true;
  return NULL;
}

static void handleRoot() { server.send_P(200, "text/html", INDEX_HTML); }
static void handleStatus() { sendJson(200, buildStatusJson()); }
static void handleEvents() { sendJson(200, buildEventsJson()); }
static void handleNotFound() { server.send(404, "text/plain", "Not found"); }

static void handleCmd() {
  if (!tokenConfigured()) { replyMsg(403, false, "Control locked: set CONTROL_TOKEN in the firmware first"); return; }
  if (!authCheck()) { replyMsg(401, false, authLocked() ? "Too many wrong tries: wait 1 minute" : "Wrong password"); return; }
  String c = server.arg("c");
  const char* r = NULL;
  const char* okMsg = "Done";
  if      (c == "start")    { r = cmdStart();  okMsg = "START accepted: pump settling"; }
  else if (c == "stop")     { cmdStop();       okMsg = "Pump STOPPED"; }
  else if (c == "ack")      { r = cmdAck();    okMsg = "Buzzer muted. Leak stays LATCHED"; }
  else if (c == "reset")    { r = cmdReset();  okMsg = "Reset accepted. Pump OFF until START"; }
  else if (c == "calzero")  { cmdCalZero();    okMsg = "Counters zeroed"; }
  else if (c == "calsave")  { r = cmdCalSave(server.arg("l").toFloat()); okMsg = "K_A and K_B saved"; }
  else if (c == "baseline") { r = cmdBaseline(); okMsg = "Baseline capture started"; }
  else if (c == "set")      { r = cmdSettingsFromRequest(); okMsg = "Settings saved"; }
  else if (c == "wifi")     { r = cmdWifiFromRequest(); okMsg = "Wi-Fi saved, reconnecting"; }
  else { replyMsg(400, false, "Unknown command"); return; }
  if (!r && c != "stop" && c != "calzero") {
    char m[56]; snprintf(m, sizeof m, "Dashboard command: %s", c.c_str());
    if (c == "start" || c == "reset" || c == "ack") logEvent(EV_INFO, m);
  }
  if (r) { logEvent(EV_REJECT, r); replyMsg(200, false, r); }
  else   replyMsg(200, true, okMsg);
}

static void netStart() {
  WiFi.persistent(false);
  WiFi.setHostname(MDNS_NAME);
  WiFi.setAutoReconnect(true);
  staStartMs = millis(); lastStaTryMs = staStartMs;
  if (wifiSsid.length()) { WiFi.mode(WIFI_STA); WiFi.begin(wifiSsid.c_str(), wifiPass.c_str()); }
  else netStartAP();
  server.on("/", HTTP_GET, handleRoot);
  server.on("/api/status", HTTP_GET, handleStatus);
  server.on("/api/events", HTTP_GET, handleEvents);
  server.on("/api/cmd", HTTP_POST, handleCmd);
  server.onNotFound(handleNotFound);
  server.begin();
  if (!tokenConfigured()) Serial.println("[NET] CONTROL_TOKEN is still the placeholder: dashboard control is LOCKED");
}

static void netTask(void* arg) {
  (void)arg;
  netStart();
  uint32_t lastStat = 0;
  for (;;) {
    server.handleClient();
    netManageWifi();
    if (settingsDirty) { settingsDirty = false; saveSettingsNow(); }
    uint32_t now = millis();
    if ((uint32_t)(now - lastStat) >= 1000UL) { lastStat = now; netUpdateStatus(); }
#if MQTT_ENABLED
    mqttService();
#endif
    vTaskDelay(pdMS_TO_TICKS(5));
  }
}

// ============================================================================
// SECTION 14 - SETUP AND LOOP  (the loop is the safety core: it never waits on the network)
// ============================================================================
static const char* resetReasonText() {
  switch (esp_reset_reason()) {
    case ESP_RST_POWERON:  return "power-on";
    case ESP_RST_SW:       return "software reset";
    case ESP_RST_PANIC:    return "crash/panic";
    case ESP_RST_INT_WDT:
    case ESP_RST_TASK_WDT:
    case ESP_RST_WDT:      return "watchdog";
    case ESP_RST_BROWNOUT: return "brownout (check 5V supply)";
    case ESP_RST_EXT:      return "external reset";
    default:               return "other";
  }
}

static void watchdogStart() {
#if ESP_ARDUINO_VERSION_MAJOR >= 3
  esp_task_wdt_config_t twdt = { (uint32_t)(WDT_TIMEOUT_S * 1000), 0, true };   // timeout_ms, idle_core_mask, panic
  esp_task_wdt_reconfigure(&twdt);
#else
  esp_task_wdt_init(WDT_TIMEOUT_S, true);
#endif
  esp_task_wdt_add(NULL);                          // watch this (loop) task
}

void setup() {
  // 1) SAFETY FIRST: relay OFF before anything else (before Serial, OLED, Wi-Fi)
  relayWrite(false);
  pinMode(PIN_BUZZER, OUTPUT);     digitalWrite(PIN_BUZZER, LOW);
  pinMode(PIN_LED_RED, OUTPUT);    digitalWrite(PIN_LED_RED, LOW);
  pinMode(PIN_LED_GREEN, OUTPUT);  digitalWrite(PIN_LED_GREEN, LOW);
#if HAS_YELLOW_LED
  pinMode(PIN_LED_YELLOW, OUTPUT); digitalWrite(PIN_LED_YELLOW, LOW);
#endif
#if BUZZER_IS_PASSIVE
  buzzerInit();
#endif
  Serial.begin(115200);
  delay(50);
  Serial.println();
  Serial.println("JAL-SURAKSHA Starting (relay is OFF)");

  stateMutex = xSemaphoreCreateMutex();
  memset(&gSys, 0, sizeof(gSys));
  gSys.state = ST_STARTING;
  gSys.bootMs = millis();
  gSys.lastActivityMs = millis();
  strncpy(gSys.stopReason, "boot: pump OFF", sizeof(gSys.stopReason) - 1);
  setNote("Starting");
  loadSettings();

  // 2) Display
  Wire.begin(PIN_OLED_SDA, PIN_OLED_SCL);
  Wire.setClock(400000);
  i2cScanLog();
  if (!oledTryInit()) Serial.println("[OLED] not found: check wiring, supply and address (0x3C/0x3D)");

  // 3) Inputs
  pinMode(PIN_BUTTON, INPUT_PULLUP);
  pinMode(PIN_FLOW_A, SENSOR_A_PULLUP ? INPUT_PULLUP : INPUT);
  pinMode(PIN_FLOW_B, SENSOR_B_PULLUP ? INPUT_PULLUP : INPUT);
  attachInterrupt(digitalPinToInterrupt(PIN_FLOW_A), isrFlowA, SENSOR_EDGE);
  attachInterrupt(digitalPinToInterrupt(PIN_FLOW_B), isrFlowB, SENSOR_EDGE);
  Serial.printf("[SENSOR] idle level A=%d B=%d (levels only; not a pulse test)\n",
                digitalRead(PIN_FLOW_A), digitalRead(PIN_FLOW_B));
  if (!RELAY_POLARITY_VERIFIED) Serial.println("[SAFETY] RELAY_POLARITY_VERIFIED is 0: START is refused until you run test R2");
  if (!gSys.cal) Serial.println("[CAL] K_A/K_B not set: leak detection is OFF until you calibrate");

  // 4) Boot event, then the network task on core 0
  char m[56];
  snprintf(m, sizeof m, "Boot: %s. Pump OFF", resetReasonText());
  logEvent(EV_BOOT, m);
  xTaskCreatePinnedToCore(netTask, "net", 12288, NULL, 1, NULL, 0);

  windowStartMs = millis();
  snapshotPulses(&lastSnapA, &lastSnapB);
  watchdogStart();                                 // last step: a hang from here on reboots the board
}

void loop() {
  esp_task_wdt_reset();
  uint32_t now = millis();

  // (1) end of a sampling window -> flows, volumes, leak logic
  if ((uint32_t)(now - windowStartMs) >= gCfg.windowMs) {
    uint32_t a, b; snapshotPulses(&a, &b);
    uint32_t dA = a - lastSnapA, dB = b - lastSnapB, el = now - windowStartMs;
    lastSnapA = a; lastSnapB = b; windowStartMs = now;
    LOCK(); evaluateWindowLocked(dA, dB, el, a, b); UNLOCK();
  }

  // (2) boot stabilisation finished -> READY (pump stays OFF; START must be deliberate)
  if (gSys.state == ST_STARTING && (uint32_t)(now - gSys.bootMs) >= STARTUP_STABILIZE_MS) {
    LOCK();
    if (gSys.state == ST_STARTING) { gSys.state = ST_IDLE; setNote("Ready. Pump OFF"); }
    UNLOCK();
    beepUntilMs = now + 100UL;
    logEvent(EV_INFO, "System ready. Pump OFF until START");
  }

  buttonService(now);
  outputsService(now);
  static uint32_t oledLastMs = 0;
  if ((uint32_t)(now - oledLastMs) >= OLED_REFRESH_MS) { oledLastMs = now; oledService(now); }
  delay(2);
}
