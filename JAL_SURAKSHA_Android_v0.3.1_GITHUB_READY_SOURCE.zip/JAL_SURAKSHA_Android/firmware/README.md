# ESP32 Firmware 1.0 (source snapshot)

`JAL_SURAKSHA_Firmware_v1.0.ino` is copied unchanged from the user-provided Library file `JAL_SURAKSHA (1).ino` so that the Android/API contract can be reviewed together with the source.

## Before using or uploading

- Confirm this is the exact sketch version intended for the ESP32 DevKit V1.
- The sketch header says it was written and logic-checked with stand-in headers, **not compiled with the real ESP32 Arduino toolchain and not hardware-tested**.
- Required libraries: Adafruit SSD1306 and Adafruit GFX (with Adafruit BusIO). ESP32 built-in libraries are provided by the Arduino-ESP32 board package.
- Keep all placeholder values private and change them locally before deployment:
  - `CONTROL_TOKEN` must be unique and at least 8 characters.
  - `AP_PASSWORD` must be a private password of at least 8 characters.
  - Wi-Fi credentials must be entered locally or through the firmware dashboard. Never commit real credentials.
- Keep `RELAY_POLARITY_VERIFIED=0` until hardware bench test R2 has been completed.
- Keep `DEFAULT_K_A=0` and `DEFAULT_K_B=0` until both flow sensors are measured and calibrated.
- `PUMP_MAX_RUN_MS=0` means no calibrated-operation maximum run-time limit. Set a finite, verified limit in a local firmware copy before any unattended or field operation.
- Do not set pump-control flags or relay polarity by assumption. The Android app remains fail-closed and does not override firmware permission.

See `../docs/API_CONTRACT.md` and `../docs/HARDWARE_SAFETY_CHECKLIST.md`.
