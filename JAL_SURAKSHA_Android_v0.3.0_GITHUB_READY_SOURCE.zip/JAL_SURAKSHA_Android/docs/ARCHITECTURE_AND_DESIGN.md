# Android architecture — JAL-SURAKSHA v0.3.0

## Layers

- `data/DeviceApi`: asynchronous local HTTP client, endpoint restrictions, form-token commands, status and event parsing.
- `data/ApiContract`: exact compact JSON and command contract from the supplied dual-flow firmware sketch.
- `data/SecretStore`: control token encrypted using AES-GCM with an Android Keystore key.
- `data/SettingsRepository`: non-secret preferences in DataStore.
- `data/HistoryStore` / `EventStore`: app-observed sample history and advisory events.
- `domain/PumpGatePolicy`: fail-closed Android UI gate; firmware remains authoritative.
- `ui/AppViewModel`: foreground polling, read-back, reconnection/backoff, history/events, export and command state.
- `ui/screens`: premium Material 3 Compose screens (Home, Live Monitor, Pump, History, Events, Settings, Device Setup, Calibration, Diagnostics).

## Firmware communication

```text
Android app
  -> GET /api/status      (no auth, local HTTP)
  -> GET /api/events      (no auth, local HTTP)
  -> POST /api/cmd        (form: t=CONTROL_TOKEN, c=command, optional parameters)
  -> GET /api/status      (read back after a state/calibration command)
```

The API uses the supplied ESP32 Firmware 1.0 dual-sensor sketch. Basic Auth is not used. Plain HTTP is not encrypted; use only a trusted private hotspot/LAN.

## Safety design

- Missing/invalid/stale pump state becomes UNKNOWN.
- Firmware `tokOk` and `relayOk` are displayed separately; START is disabled unless both are true and current status is fresh.
- App command toggle defaults OFF. The firmware validates token, latch and relay polarity again for every command.
- HTTP 200 alone is not proof of command success. The command JSON `ok` is parsed and the app reads status back.
- Calibration is firmware-owned and stores separate K_A/K_B values. L/min and litre readings remain unavailable while `cal=false`; raw pulse rates (Hz) are shown.
- STOP is presented as a network action, not an emergency stop. Physical power cutoff is required.

## Test layers

- JVM tests validate API parsing, host restrictions, command mapping, storage, domain rules, calibration math and pump gate behavior.
- Instrumented Compose tests validate the safety-critical Pump panel interactions.
- Emulator tests do not verify physical ESP32, sensor, relay or pump hardware.
