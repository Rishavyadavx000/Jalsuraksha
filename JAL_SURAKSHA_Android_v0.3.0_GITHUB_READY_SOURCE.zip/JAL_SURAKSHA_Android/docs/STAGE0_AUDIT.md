# JAL-SURAKSHA v0.3.0 — Firmware integration audit

## Source reviewed

The Android integration has been updated against the user-library sketch `JAL_SURAKSHA (1).ino` (Firmware 1.0, 66,998 bytes). The sketch is dual-sensor and provides `GET /api/status`, `GET /api/events`, and token-protected `POST /api/cmd`. The earlier v0.2.0 single-flow / Basic Auth contract is obsolete for this sketch.

## Confirmed from source

- Flow A GPIO27, Flow B GPIO26, relay GPIO25.
- Status exposes `fa/fb`, `diff/pct`, `ra/rb`, `va/vb`, pulse counters, state, severity, latch, pump, calibration, Wi-Fi/RSSI/IP and configuration.
- Status and event GET endpoints have no authentication in the sketch.
- POST command endpoint requires the `t` CONTROL_TOKEN and `c` command form fields.
- Command handler returns `ok` and `msg`; HTTP 200 with `ok:false` is a rejection.
- Token placeholder, relay-polarity flag, and zero calibration constants keep control/calibration restricted by default.
- `PUMP_MAX_RUN_MS=0` means no calibrated maximum run time is configured. Uncalibrated operation has a 180 s cap; no-flow stop is enabled.

## Android v0.3.0 implementation

- Replaced old Basic Auth and `/pump/on` / `/pump/off` API assumptions with the supplied firmware's exact routes and form-token command protocol.
- Added strict dual-sensor status parsing, events parsing, token protection, HTTP rejection handling, and post-command status read-back.
- Added Sensor A/Sensor B metrics and flow-difference display.
- Uncalibrated telemetry is not misrepresented as 0 L/min or 0 L; only pulse rate in Hz is shown until the firmware reports `cal=true`.
- Added firmware-owned calibration steps (`calzero`, `calsave`, `baseline`) and alarm actions (`ack`, `reset`).
- Pump START remains gated by the app switch, fresh status, configured token, `relayOk=true`, known pump state and confirmation. STOP remains available as a network command when fresh status and a configured token are present, even if the app START switch is off.
- No firmware secrets, GPIO assignments, relay polarity, or calibration constants are changed by Android source.

## Not verified

- The provided `.ino` itself states it has not been compiled with the actual ESP32 toolchain or tested on physical hardware.
- It is not confirmed that this exact `.ino` file is the version currently flashed to the user's board.
- Actual YF-S201 wiring, voltage levels, relay model/polarity, pump current and power supply remain unverified.
- Run #19 CI results applied to the earlier v0.2.0 source checkpoint. They are not test results for v0.3.0.

## Additional parser consistency check

- Firmware `cfg.base` is a signed baseline offset (valid range −5.0..+5.0 L/min); Android parser now accepts negative values rather than rejecting them as malformed.
- Firmware latch value `possible_leak` and state text `POSSIBLE LEAK / SENSOR B CHECK` are recognised as a possible leak, not a confirmed leak. Sensor faults are not classified as confirmed leaks.
- Added a JVM regression test for this status.
