# Build and continuous integration

## Declared toolchain

| Component | Project configuration |
|---|---|
| Android Gradle Plugin | 8.7.3 |
| Gradle | 8.9 |
| Kotlin Android + Compose compiler plugin | 2.0.21 |
| Android compile / target / minimum SDK | 35 / 35 / 24 |
| Java source and bytecode target | 17 |

This is the configured compatibility matrix. The local source-delivery environment has Java 21 but no Android SDK or installed Gradle, so a full Android Gradle build and APK packaging cannot be claimed from the local environment.

## Gradle wrapper status

`gradle/wrapper/gradle-wrapper.properties` pins Gradle 8.9. The official wrapper JAR and `gradlew` / `gradlew.bat` launcher scripts are not included. GitHub Actions installs Gradle 8.9 directly and invokes the `gradle` executable. For local command-line use, install Gradle 8.9 or generate and commit the standard wrapper using `gradle wrapper --gradle-version 8.9 --distribution-type bin`.

## Local checks

```bash
python3 tools/verify_test_inventory.py
python3 tools/lint_kt.py .
python3 tools/verify_firmware_contract.py
gradle --no-daemon clean testDebugUnitTest lintDebug compileDebugKotlin
gradle --no-daemon connectedDebugAndroidTest
gradle --no-daemon assembleDebug
```

Inventory is 102 JVM unit tests plus 6 instrumented Compose UI tests. Inventory counting does not execute tests.

## GitHub Actions

`.github/workflows/main.yml` runs on push, pull request and manual dispatch:

1. `unit-lint-build`: checks inventory, Kotlin/XML structure and the bundled ESP32/Android API contract, runs JVM tests, Android lint and Kotlin debug compilation.
2. `compose-ui-tests`: starts an API 35 Android emulator and runs `connectedDebugAndroidTest`.
3. `build-debug-apk`: runs only after both verification jobs pass (and not on pull requests). It builds `app-debug.apk`, copies it to a versioned filename, calculates SHA-256 and uploads the APK/checksum as a 30-day artifact.

`.github/workflows/manual-apk.yml` remains available for an explicit manual Debug or unsigned Release build. The Release APK is unsigned. The Debug APK is installable for testing but is not a production-signed release. Production signing requires the owner's private signing key and secure GitHub secrets; never put a keystore or passwords in the repository or this chat.

## Evidence required before calling the Android release verified

1. A v0.3.0 Actions run shows `unit-lint-build` and `compose-ui-tests` successful.
2. JUnit XML confirms 102 JVM + 6 UI tests passed, with zero failures/errors/skips.
3. The dependent `build-debug-apk` job succeeds and uploads a non-empty APK and SHA-256 checksum.
4. The APK is installed and manually smoke-tested on the owner's Android phone.

## Firmware and physical hardware boundary

The API contract is compared to the supplied `JAL_SURAKSHA (1).ino` source, but this does not prove that exact sketch is flashed on the board or that it compiles under the user's installed ESP32 Arduino core. The supplied sketch itself says it had not yet been compiled with the real ESP32 toolchain or tested on hardware.

Keep the app-side command switch OFF and the pump power disconnected until relay polarity, GPIO compatibility, sensor voltage, pump supply/current, calibration, finite run-time limits and physical cutoff have been checked. Do not use an Android test result as evidence of electrical safety.
