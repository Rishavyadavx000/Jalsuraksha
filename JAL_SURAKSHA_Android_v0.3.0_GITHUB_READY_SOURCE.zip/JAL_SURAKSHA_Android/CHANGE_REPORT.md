# JAL-SURAKSHA Android v0.3.0 — integration change report

**Prepared:** 12 November 2026
**Android source:** retained v0.2.0 native Kotlin/Jetpack Compose project
**Firmware source reviewed:** `JAL_SURAKSHA (1).ino`, Firmware 1.0, supplied from the user's Library

## Executive summary

The Android project was updated to target the supplied dual-sensor ESP32 firmware rather than the earlier single-flow, Basic-Auth draft. The firmware source is included unchanged under `firmware/JAL_SURAKSHA_Firmware_v1.0.ino`. The Android integration maps status, events and token-protected command routes; it does not modify GPIO assignments, relay flags, secrets or calibration constants in firmware.

The project is **source-integrated, but not yet release-verified against physical hardware**. GitHub Run #19 only verifies the older v0.2.0 checkpoint. v0.3.0 requires its own Actions results.

## Confirmed firmware contract from the supplied sketch

- ESP32 Arduino `WebServer` on port 80.
- `GET /api/status` and `GET /api/events` are unauthenticated read endpoints.
- `POST /api/cmd` is protected by form fields `t` (control token) and `c` (command); it is not HTTP Basic Auth.
- Commands: `start`, `stop`, `ack`, `reset`, `calzero`, `calsave`, `baseline`, `set`, `wifi`.
- Status contains two sensor readings (`fa`, `fb`), difference (`diff`, `pct`), pulse rates (`ra`, `rb`), totals (`va`, `vb`), raw and calibration pulses, state/severity/latch, pump state, calibration flags, Wi-Fi/RSSI/IP and `cfg`.
- The exact sketch defaults to `CONTROL_TOKEN="CHANGE_ME_TOKEN"`, `RELAY_POLARITY_VERIFIED=0`, `DEFAULT_K_A=0`, `DEFAULT_K_B=0`; pump START is therefore locked by firmware by default.
- `PUMP_MAX_RUN_MS=0` means no calibrated maximum run-time limit.

## Android changes

- Replaced the old draft API defaults with the actual `GET /api/status`, `GET /api/events`, `POST /api/cmd` routes.
- Implemented dual-sensor JSON parsing, uncalibrated Hz-only display, firmware event parsing, command token handling, `ok:false` rejection handling and status read-back.
- Added firmware calibration wizard based on raw sensor pulse counters and measured litres; no generic pulses-per-litre calibration is assumed.
- Kept existing premium Compose screens, history, event handling, diagnostics and dashboard.
- Kept the app-side pump-request setting OFF by default. The app cannot override the firmware relay/token gate.
- Corrected signed baseline parsing (`cfg.base`) and possible-leak classification; added a regression test.
- Corrected `CommandReplyParser.parse()` from an expression body with illegal non-local `return` to a valid block body after a targeted Kotlin syntax compile caught the error.

## Verification performed locally

| Check | Result |
|---|---|
| Test inventory | 102 JVM + 6 UI test annotations found |
| Kotlin/XML structural checker | 49 Kotlin files, no findings |
| Partial pure-Kotlin compile | PASS: 10 pure Kotlin data/domain files with kotlinc 1.9.0, JVM target 17 |
| API parser syntax compile | PASS: Models + ApiModels + ApiContract compiled using temporary JSON API stubs; not a full dependency/runtime test |
| Full Gradle Android build | Not run locally; Gradle and Android SDK are absent |
| JVM test execution | Not run locally |
| UI emulator test execution | Not run locally |
| APK build | Not run locally |
| Firmware Arduino compile | Not run |
| ESP32 / relay / pump hardware test | Not run |

The GitHub workflow is configured to run JVM tests, structural checks, lint, Kotlin compilation, instrumented emulator tests, and then build/upload a Debug APK only if both test jobs succeed. The v0.3.0 Actions run is the acceptance evidence.

## Safety boundary

Do not change `RELAY_POLARITY_VERIFIED`, `CONTROL_TOKEN`, `DEFAULT_K_A`, `DEFAULT_K_B`, relay polarity or GPIO values by assumption. The firmware header itself states that the supplied sketch was not compiled with the real board toolchain and was not hardware-tested. `PUMP_MAX_RUN_MS=0` also needs a finite safe value before unattended or field operation. Keep the pump disconnected until the checklist is completed and keep a physical cutoff available.

## Remaining release actions

1. Push the v0.3.0 source archive and workflows to GitHub.
2. Require `unit-lint-build` and `compose-ui-tests` to pass.
3. Verify the attached JUnit XML shows 102/102 JVM and 6/6 UI tests with no failures, errors or skips.
4. Collect the Debug APK artifact produced by the dependent build job; verify SHA-256 and install manually on an Android phone.
5. Confirm the exact firmware version flashed to ESP32 and test GET-only status/events first with pump power disconnected.
6. Complete relay, sensor-voltage, water/electrical isolation, calibration and controlled bench tests before unlocking pump START.

**Current status:** native app and source-level firmware API integration prepared; v0.3.0 CI/APK and physical hardware verification still pending.
