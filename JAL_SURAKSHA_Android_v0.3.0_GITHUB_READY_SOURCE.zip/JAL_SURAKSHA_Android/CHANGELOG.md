# Changelog

## v0.3.0 — ESP32 Firmware 1.0 integration

- Replaced the earlier single-sensor / Basic Auth draft API with the supplied dual-flow ESP32 Firmware 1.0 contract.
- Added GET `/api/status`, GET `/api/events`, and token-protected POST `/api/cmd` support.
- Added Sensor A/Sensor B flow, total volume, pulse counters, difference, leak segment, firmware state/latch, sensor health and AP-default warnings.
- Added `start`, `stop`, `ack`, `reset`, `calzero`, `calsave`, `baseline`, `set`, and `wifi` command mapping; current UI exposes pump/alarm/calibration workflows.
- Commands parse `{ok,msg}` and use read-back for pump, alarm and calibration state. Firmware baseline parsing accepts its documented signed −5..5 L/min range; possible-leak classification matches the firmware latch/state strings. HTTP 200 with `ok:false` is treated as firmware rejection.
- Uncalibrated telemetry now shows pulse frequency only; it no longer presents firmware placeholder zeros as measured L/min/litres. App-side flow alarms are suppressed until calibration is active.
- Pump START remains locked by default and by the firmware's token + relay verification flags. STOP remains a network action, never advertised as a physical emergency stop.
- Updated hardware checklist and API documentation for GPIO 27/26 flow sensors, GPIO25 relay, token protocol and actual run-time defaults.
- Updated test inventory to 102 JVM test cases + 6 instrumented UI test cases.
- Fixed signed firmware baseline parsing and possible-leak classification.
- Fixed a Kotlin syntax issue in the firmware command response parser found during targeted compilation.
- Added a static firmware/API drift guard to CI for routes, JSON keys, commands, form parameters and safety defaults.

## v0.2.0

- Initial premium Kotlin/Compose dashboard, local history, alerts, diagnostics and pump safety UI.
- v0.2.0 used a draft API contract and is superseded by v0.3.0 for the supplied dual-sensor firmware.
