# JAL-SURAKSHA Android v0.3.0

Premium native Android companion for the supplied JAL-SURAKSHA ESP32 Firmware 1.0 dual-flow water-leak monitor. The unchanged source sketch is included under `firmware/`.

## Important release status

This release source is aligned to the uploaded `JAL_SURAKSHA (1).ino` sketch. It is **not yet a physical-hardware-certified release**. The firmware sketch itself states it has not been compiled with the real ESP32 toolchain or tested on hardware, and it has not been confirmed that this exact sketch is currently flashed on the user's ESP32.

Pump START is locked by default in the app and by firmware flags. Do not enable it until the relay, sensors, wiring, supply, flow calibration and firmware have passed the hardware checklist.

## Features

- Native Kotlin + Jetpack Compose + Material 3 premium UI.
- Home dashboard, connection hero, dual sensor telemetry, flow-difference/leak segment, live monitor, history, events, diagnostics, settings, calibration wizard and pump controls.
- Local HTTP communication to the ESP32: `GET /api/status`, `GET /api/events`, `POST /api/cmd`.
- Firmware command token stored encrypted with Android Keystore.
- Pump START confirmation and firmware permission gate; state read-back after pump commands.
- Firmware alarm ACK/RESET controls and dual-sensor calibration commands.
- App-observed history and CSV export. It does not invent samples during offline periods.
- Local-only endpoint allow-list; no cloud account or third-party analytics/tracking required for core functions.

## Device setup

1. Configure the ESP32 sketch locally. Replace `CONTROL_TOKEN` with a private unique 8+ character value. Replace the fallback AP password placeholder. Do not commit real secrets.
2. Compile and upload the sketch using the actual ESP32 board package and required Adafruit SSD1306 / GFX libraries.
3. Initially keep `RELAY_POLARITY_VERIFIED=0`, `DEFAULT_K_A=0`, and `DEFAULT_K_B=0`.
4. Connect the Android phone to the same hotspot/LAN as the ESP32. If the ESP32 is in setup AP mode, connect to `JAL-SURAKSHA-SETUP` using the private AP password configured in the sketch.
5. In Android Device Setup, enter the ESP32's current private IP (or supported `.local` name), e.g. `192.168.1.50`. The previous observed IP `10.96.201.207` was DHCP-assigned and must not be treated as permanent.
6. Save the firmware CONTROL_TOKEN in the app only if you need authenticated commands. Status and event monitoring can work without the token.
7. Tap Test Connection. Confirm Sensor A/B status and firmware state.

## Firmware API contract

See `docs/API_CONTRACT.md` for exact fields and semantics.

| Request | Authentication | Meaning |
|---|---|---|
| `GET /api/status` | None | Dual flow, pump, leak state, network and config |
| `GET /api/events` | None | Firmware ring-buffer events |
| `POST /api/cmd` | Form fields `t` (token), `c` (command) | start/stop/ack/reset/calibration/settings/Wi-Fi |

This firmware does **not** use HTTP Basic Auth. HTTP 200 with `ok:false` is a rejected command. The Android app checks `ok` and reads status back for state confirmation.

## Calibration

The firmware uses separate `K_A` and `K_B` pulses-per-litre values. It starts with both at zero. Use the Android Calibration screen:

1. Pump OFF and test path prepared.
2. Send `calzero` to snapshot both raw pulse counters.
3. Pass a measured 0.2–100 L volume through both sensors (at least 50 pulses per sensor).
4. Send `calsave` with the exact litres; confirm `cal=true` and non-zero `cfg.kA` / `cfg.kB`.
5. With the leak path closed and a stable controlled run, capture the no-leak baseline.

Until `cal=true`, Android shows Sensor A/B pulse rate in Hz and deliberately does not label the firmware's placeholder zeros as 0 L/min or 0 L.

## Build in Android Studio

- JDK 17.
- Android SDK Platform 35 and Build Tools 35.0.0.
- Android Gradle Plugin 8.7.3 / Gradle 8.9 / Kotlin 2.0.21.
- Open the project root in Android Studio and allow Gradle Sync.
- Run `gradle testDebugUnitTest lintDebug compileDebugKotlin`.
- Run `gradle connectedDebugAndroidTest` on an API 35 emulator/device.
- Build a debug APK with `gradle assembleDebug` after tests pass.

The source repository package uses GitHub Actions to install Gradle 8.9 directly; wrapper properties are present but wrapper launch scripts/JAR are absent from this package. For local command-line use, generate a standard Gradle Wrapper from the chosen Gradle distribution or use Android Studio's configured Gradle.

## GitHub Actions

The workflow `JAL-SURAKSHA Main Verification and Debug APK` runs source inventory, structural checks, JVM tests, Android lint, Kotlin debug compilation and instrumented UI tests. Only after both verification jobs pass does the `build-debug-apk` job build an installable Debug APK and upload it with a SHA-256 checksum. A green v0.2.0 Run #19 is not a v0.3.0 test result. Upload v0.3.0 source and inspect the new run artifacts before calling this release verified.

## Safety defaults and limits

- The app's pump-request switch defaults OFF.
- Firmware `CONTROL_TOKEN` defaults to a placeholder: commands remain locked until changed locally.
- Firmware `RELAY_POLARITY_VERIFIED` defaults to `0`: START is refused until relay bench test R2 passes and the flag is deliberately set in firmware.
- Firmware `DEFAULT_K_A` and `DEFAULT_K_B` default to zero: leak comparison is disabled until measured calibration is saved.
- Uncalibrated pump operation is capped at 180 seconds by the supplied sketch.
- `PUMP_MAX_RUN_MS=0` means calibrated pump operation has no firmware maximum run-time cap by default. Configure a finite safe limit before field/unattended use.
- A no-flow stop guard is enabled (five consecutive windows), but this is not a substitute for a physical cutoff.
- STOP from the app requires a working network and the token; it is not an emergency stop. Always keep a physical way to cut pump power.
- Local HTTP is not encrypted. A token and Wi-Fi configuration sent on the same LAN may be observed by another device on that network. Do not use public Wi-Fi or port-forward the ESP32.

## Hardware pins from the supplied sketch (verify before wiring)

- Sensor A: GPIO 27
- Sensor B: GPIO 26
- Relay input: GPIO 25
- OLED SDA/SCL: GPIO 21 / 22
- Buzzer: GPIO 23
- Button: GPIO 32
- LEDs: GPIO 16 / 17 / 18

See `docs/HARDWARE_SAFETY_CHECKLIST.md` and `docs/ESP32_FIRMWARE_AUDIT.md`.

## Test inventory

- 102 JVM test cases (annotation inventory only until run).
- 6 instrumented Compose UI tests.
- Current v0.3.0 test results must be taken from a new GitHub Actions run; v0.2.0 Run #19 does not apply to this version.

## Privacy

No telemetry is sent to a cloud service by the Android app by default. The ESP32's optional MQTT code is disabled by default in the supplied sketch. The status/events GET routes are unauthenticated on the local network, so only use a trusted network and do not expose port 80 publicly.
