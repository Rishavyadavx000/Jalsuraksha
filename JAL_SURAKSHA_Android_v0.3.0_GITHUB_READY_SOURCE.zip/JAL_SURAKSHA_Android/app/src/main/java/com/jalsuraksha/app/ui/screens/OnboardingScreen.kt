package com.jalsuraksha.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Router
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.jalsuraksha.app.ui.AppViewModel
import com.jalsuraksha.app.ui.components.JalButton
import com.jalsuraksha.app.ui.components.ScreenHeader
import com.jalsuraksha.app.ui.theme.Jal
import com.jalsuraksha.app.ui.theme.JalSpacing

@Composable
fun OnboardingScreen(vm: AppViewModel, hasPassword: Boolean, onDone: () -> Unit) {
    var step by rememberSaveable { mutableStateOf(0) }
    val test by vm.testState.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    var saveError by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) { vm.clearTest() }

    Column(
        Modifier
            .fillMaxSize()
            .imePadding()
            .verticalScroll(rememberScrollState()),
    ) {
        when (step) {
            0 -> {
                ScreenHeader(title = "Welcome", subtitle = "Water monitoring you can trust")
                Column(
                    Modifier.padding(horizontal = JalSpacing.lg),
                    verticalArrangement = Arrangement.spacedBy(JalSpacing.lg),
                ) {
                    Text(
                        "JAL-SURAKSHA shows live readings from your ESP32 flow sensor and lets you request pump actions, " +
                            "over your own Wi-Fi or phone hotspot.",
                        style = MaterialTheme.typography.bodyLarge,
                    )
                    Principle(Icons.Filled.Router, "Local only", "The app talks directly to your ESP32. Nothing is sent to the internet.")
                    Principle(Icons.Filled.Sensors, "Honest readings", "If a value is missing or invalid, the app shows -- instead of guessing.")
                    Principle(Icons.Filled.Lock, "Safety first", "Pump control stays locked until your firmware allows it, and every start asks for confirmation.")
                    JalButton("Get started", onClick = { step = 1 }, modifier = Modifier.fillMaxWidth())
                }
            }
            1 -> {
                ScreenHeader(title = "Before you connect", subtitle = "Three quick checks")
                Column(
                    Modifier.padding(horizontal = JalSpacing.lg),
                    verticalArrangement = Arrangement.spacedBy(JalSpacing.lg),
                ) {
                    Principle(
                        Icons.Filled.Router,
                        "Same network",
                        "Connect the ESP32 and this phone to the same Wi-Fi, or connect the ESP32 to this phone's hotspot.",
                    )
                    Principle(
                        Icons.Filled.WaterDrop,
                        "Find the IP address",
                        "After a reset the ESP32 prints its IP in the Arduino Serial Monitor (check the baud rate in your sketch; the draft used 57600). " +
                            "Your hotspot or router also lists connected devices. The address can change when the hotspot restarts.",
                    )
                    Principle(
                        Icons.Filled.Lock,
                        "Credentials",
                        "The supplied sketch uses a control token only for START/STOP and other commands. Status monitoring is read-only without a token.",
                    )
                    JalButton("Continue", onClick = { step = 2 }, modifier = Modifier.fillMaxWidth())
                    TextButton(onClick = { step = 0 }, modifier = Modifier.fillMaxWidth()) { Text("Back") }
                }
            }
            else -> {
                ScreenHeader(title = "Connect your device", subtitle = "Add the ESP32's address")
                DeviceSetupForm(
                    initial = settings,
                    hasPassword = hasPassword,
                    test = test,
                    saveLabel = "Save and continue",
                    saveError = saveError,
                    onTest = { input ->
                        saveError = null
                        vm.testConnection(input)
                    },
                    onSave = { input ->
                        saveError = null
                        vm.saveDevice(input) { error ->
                            if (error == null) onDone() else saveError = error
                        }
                    },
                    modifier = Modifier.padding(horizontal = JalSpacing.lg),
                )
                TextButton(
                    onClick = { step = 1 },
                    modifier = Modifier.padding(horizontal = JalSpacing.lg),
                ) { Text("Back") }
            }
        }
    }
}

@Composable
private fun Principle(icon: ImageVector, title: String, body: String) {
    Row(verticalAlignment = Alignment.Top) {
        Icon(
            icon,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(24.dp),
        )
        Spacer(Modifier.width(JalSpacing.md))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(2.dp))
            Text(
                body,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}
