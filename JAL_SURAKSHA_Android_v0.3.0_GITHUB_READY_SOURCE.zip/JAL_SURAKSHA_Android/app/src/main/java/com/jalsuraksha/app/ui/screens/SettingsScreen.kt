package com.jalsuraksha.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.jalsuraksha.app.data.ThemeMode
import com.jalsuraksha.app.data.VolumeUnit
import com.jalsuraksha.app.domain.Formats
import com.jalsuraksha.app.ui.AppViewModel
import com.jalsuraksha.app.ui.UiSnapshot
import com.jalsuraksha.app.ui.components.ChipRow
import com.jalsuraksha.app.ui.components.JalCard
import com.jalsuraksha.app.ui.components.JalOutlinedButton
import com.jalsuraksha.app.ui.components.ScreenHeader
import com.jalsuraksha.app.ui.components.SectionTitle
import com.jalsuraksha.app.ui.components.SliderRow
import com.jalsuraksha.app.ui.components.SwitchRow
import com.jalsuraksha.app.ui.theme.JalSpacing
import java.util.Locale
import kotlin.math.roundToInt

@Composable
fun SettingsScreen(
    vm: AppViewModel,
    ui: UiSnapshot,
    onOpenDevice: () -> Unit,
    onOpenCalibration: () -> Unit,
    onOpenDiagnostics: () -> Unit,
) {
    val s = ui.settings
    val unit = s.unit
    var storage by remember { mutableStateOf("") }
    var confirmClear by remember { mutableStateOf(false) }
    var confirmReset by remember { mutableStateOf(false) }
    var confirmEnablePump by remember { mutableStateOf(false) }

    LaunchedEffect(ui.events.size) { storage = vm.storageSummary() }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
    ) {
        ScreenHeader(title = "Settings", subtitle = "Connection, alerts and display")
        Column(
            modifier = Modifier.padding(horizontal = JalSpacing.lg),
            verticalArrangement = Arrangement.spacedBy(JalSpacing.md),
        ) {
            JalCard {
                Text("Device", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(JalSpacing.sm))
                StatRow("Name", if (s.isConfigured) s.deviceName else "Not set up")
                StatRow("Address", if (s.isConfigured) s.addressDisplay else "--")
                StatRow("Control token", if (ui.hasPassword) "Saved securely" else "Not saved (read-only mode)")
                StatRow("Firmware API", "${s.statusPath} · ${s.eventsPath} · ${s.commandPath}")
                Spacer(Modifier.height(JalSpacing.md))
                JalOutlinedButton(
                    text = if (s.isConfigured) "Edit device and credentials" else "Set up device",
                    onClick = onOpenDevice,
                    icon = Icons.Filled.Edit,
                    modifier = Modifier.fillMaxWidth(),
                )
            }

            JalCard {
                Text("Connection", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(JalSpacing.md))
                Text("Check the device every", style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(JalSpacing.sm))
                ChipRow(
                    options = listOf("2 s" to 2, "3 s" to 3, "5 s" to 5, "10 s" to 10),
                    selected = s.pollIntervalSec,
                    onSelect = { v -> vm.updateSettings { it.copy(pollIntervalSec = v) } },
                )
                Spacer(Modifier.height(JalSpacing.lg))
                Text("Treat data as stale after", style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(JalSpacing.sm))
                ChipRow(
                    options = listOf("10 s" to 10, "20 s" to 20, "30 s" to 30, "60 s" to 60),
                    selected = s.staleAfterSec,
                    onSelect = { v -> vm.updateSettings { it.copy(staleAfterSec = v) } },
                )
                Spacer(Modifier.height(JalSpacing.sm))
                Text(
                    "The app polls only while it is open. While the device cannot be reached it slows down automatically.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            JalCard {
                Text("Alert thresholds", style = MaterialTheme.typography.titleMedium)
                Text(
                    "Advisory only. They work while the app is open and are heuristics, not a safety system.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(JalSpacing.md))
                val flowUnit = Formats.flowUnit(unit)
                val liters = unit == VolumeUnit.LITERS

                SliderRow(
                    label = "High flow",
                    value = toDisplay(s.highFlowLpm, unit),
                    range = if (liters) 1f..30f else 0.25f..8f,
                    steps = if (liters) 28 else 30,
                    format = { "${fmt(it, if (liters) 0 else 2)} $flowUnit" },
                    onCommit = { v -> vm.updateSettings { it.copy(highFlowLpm = fromDisplay(v, unit)) } },
                )
                SliderRow(
                    label = "No flow while pump ON for",
                    value = s.noFlowGraceSec.toFloat(),
                    range = 10f..120f,
                    steps = 10,
                    format = { "${it.roundToInt()} s" },
                    onCommit = { v -> vm.updateSettings { it.copy(noFlowGraceSec = v.roundToInt()) } },
                )
                SliderRow(
                    label = "Flow while pump OFF above",
                    value = toDisplay(s.flowWhileOffLpm, unit),
                    range = if (liters) 0.1f..2f else 0.05f..0.5f,
                    steps = if (liters) 18 else 8,
                    format = { "${fmt(it, 2)} $flowUnit" },
                    onCommit = { v -> vm.updateSettings { it.copy(flowWhileOffLpm = fromDisplay(v, unit)) } },
                )
                SliderRow(
                    label = "Flow while pump OFF for",
                    value = s.flowWhileOffGraceSec.toFloat(),
                    range = 10f..120f,
                    steps = 10,
                    format = { "${it.roundToInt()} s" },
                    onCommit = { v -> vm.updateSettings { it.copy(flowWhileOffGraceSec = v.roundToInt()) } },
                )
                SliderRow(
                    label = "Weak Wi-Fi signal at",
                    value = s.weakSignalDbm.toFloat(),
                    range = -95f..-60f,
                    steps = 34,
                    format = { "${it.roundToInt()} dBm" },
                    onCommit = { v -> vm.updateSettings { it.copy(weakSignalDbm = v.roundToInt()) } },
                )
            }

            JalCard {
                Text("Device command access", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(JalSpacing.sm))
                SwitchRow(
                    label = "Allow device commands from this app",
                    description = "Off by default. This gates pump, alarm, calibration, settings and Wi-Fi commands. Enable only after reviewing docs/API_CONTRACT.md. The firmware remains the final authority.",
                    checked = s.pumpRequestsEnabled,
                    onChange = { wantOn ->
                        if (wantOn) {
                            confirmEnablePump = true
                        } else {
                            vm.updateSettings { it.copy(pumpRequestsEnabled = false) }
                        }
                    },
                )
            }

            JalCard {
                Text("Display", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(JalSpacing.md))
                Text("Theme", style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(JalSpacing.sm))
                ChipRow(
                    options = listOf(
                        "System" to ThemeMode.SYSTEM,
                        "Light" to ThemeMode.LIGHT,
                        "Dark" to ThemeMode.DARK,
                    ),
                    selected = s.theme,
                    onSelect = { v -> vm.updateSettings { it.copy(theme = v) } },
                )
                Spacer(Modifier.height(JalSpacing.lg))
                Text("Units", style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(JalSpacing.sm))
                ChipRow(
                    options = listOf(
                        "Litres" to VolumeUnit.LITERS,
                        "US gallons" to VolumeUnit.US_GALLONS,
                    ),
                    selected = s.unit,
                    onSelect = { v -> vm.updateSettings { it.copy(unit = v) } },
                )
            }

            JalCard {
                Text("Data on this phone", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(JalSpacing.sm))
                StatRow("Stored", storage.ifEmpty { "..." })
                Spacer(Modifier.height(JalSpacing.sm))
                Text("Keep history for", style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(JalSpacing.sm))
                ChipRow(
                    options = listOf("1 day" to 1, "7 days" to 7, "30 days" to 30),
                    selected = s.retentionDays,
                    onSelect = { v -> vm.updateSettings { it.copy(retentionDays = v) } },
                )
                Spacer(Modifier.height(JalSpacing.xs))
                Text(
                    "Older data is removed the next time the app starts.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(JalSpacing.md))
                JalOutlinedButton(
                    text = "Clear history and events",
                    onClick = { confirmClear = true },
                    icon = Icons.Filled.Delete,
                    modifier = Modifier.fillMaxWidth(),
                )
            }

            JalCard {
                Text("Tools", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(JalSpacing.md))
                JalOutlinedButton(
                    text = "Flow calibration wizard",
                    onClick = onOpenCalibration,
                    icon = Icons.Filled.Build,
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(JalSpacing.sm))
                JalOutlinedButton(
                    text = "Diagnostics",
                    onClick = onOpenDiagnostics,
                    icon = Icons.Filled.Build,
                    modifier = Modifier.fillMaxWidth(),
                )
            }

            SectionTitle("About")
            JalCard {
                StatRow("Version", vm.appVersion)
                StatRow("Connection", "Local network only, plain HTTP")
                Text(
                    "Pump control is decided by your ESP32 firmware. This app can only request it, and keeps it locked whenever the firmware does not allow it.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(JalSpacing.md))
                TextButton(onClick = { confirmReset = true }) { Text("Forget device and reset settings") }
            }
            Spacer(Modifier.height(JalSpacing.lg))
        }
    }

    if (confirmEnablePump) {
        EnablePumpRequestsDialog(
            onConfirm = {
                confirmEnablePump = false
                vm.updateSettings { it.copy(pumpRequestsEnabled = true) }
            },
            onDismiss = { confirmEnablePump = false },
        )
    }
    if (confirmClear) {
        ConfirmDialog(
            title = "Clear history and events?",
            text = "All saved readings and events on this phone will be deleted. This cannot be undone.",
            confirmLabel = "Clear",
            onConfirm = {
                confirmClear = false
                vm.clearHistoryAndEvents()
            },
            onDismiss = { confirmClear = false },
        )
    }
    if (confirmReset) {
        ConfirmDialog(
            title = "Forget this device and reset settings?",
            text = "The device address, saved control token, thresholds and device-command switch will be removed and you will return to setup. Local history is kept.",
            confirmLabel = "Forget",
            onConfirm = {
                confirmReset = false
                vm.resetSettings()
            },
            onDismiss = { confirmReset = false },
        )
    }
}

@Composable
private fun EnablePumpRequestsDialog(onConfirm: () -> Unit, onDismiss: () -> Unit) {
    var verified by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Allow device commands?") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(JalSpacing.md)) {
                Text(
                    "This lets the app send firmware commands for pump control, alarm acknowledgement/reset, calibration, settings and Wi-Fi. The ESP32 still validates the control token and every command. Pump START additionally requires firmware relay verification and fresh status.",
                    style = MaterialTheme.typography.bodyMedium,
                )
                Row(
                    modifier = Modifier.toggleable(
                        value = verified,
                        onValueChange = { verified = it },
                        role = Role.Checkbox,
                    ),
                    verticalAlignment = Alignment.Top,
                ) {
                    Checkbox(checked = verified, onCheckedChange = null)
                    Spacer(Modifier.width(JalSpacing.sm))
                    Text(
                        "I have reviewed the API contract and safety checklist, and I understand this switch does not override the ESP32 safety interlocks.",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }
            }
        },
        confirmButton = { TextButton(onClick = onConfirm, enabled = verified) { Text("Enable commands") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
internal fun ConfirmDialog(
    title: String,
    text: String,
    confirmLabel: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { Text(text) },
        confirmButton = { TextButton(onClick = onConfirm) { Text(confirmLabel) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
fun DeviceScreen(vm: AppViewModel, ui: UiSnapshot, onBack: () -> Unit) {
    val test by vm.testState.collectAsStateWithLifecycle()
    var saveError by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) { vm.clearTest() }

    Column(
        Modifier
            .fillMaxSize()
            .imePadding()
            .verticalScroll(rememberScrollState()),
    ) {
        ScreenHeader(title = "Device", subtitle = "Connection profile", onBack = onBack)
        DeviceSetupForm(
            initial = ui.settings,
            hasPassword = ui.hasPassword,
            test = test,
            saveLabel = "Save changes",
            saveError = saveError,
            onTest = { input ->
                saveError = null
                vm.testConnection(input)
            },
            onSave = { input ->
                saveError = null
                vm.saveDevice(input) { error ->
                    if (error == null) onBack() else saveError = error
                }
            },
            modifier = Modifier.padding(horizontal = JalSpacing.lg),
        )
    }
}

private fun toDisplay(lpm: Double, unit: VolumeUnit): Float = Formats.flowValue(lpm, unit).toFloat()

private fun fromDisplay(v: Float, unit: VolumeUnit): Double =
    if (unit == VolumeUnit.LITERS) v.toDouble() else v * Formats.LITERS_PER_US_GALLON

private fun fmt(v: Float, digits: Int): String = String.format(Locale.getDefault(), "%.${digits}f", v)
