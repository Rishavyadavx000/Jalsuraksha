package com.jalsuraksha.app.ui

import com.jalsuraksha.app.data.AppSettings
import com.jalsuraksha.app.data.DeviceSnapshot
import com.jalsuraksha.app.data.DeviceStatus
import com.jalsuraksha.app.data.EventRecord
import com.jalsuraksha.app.data.FirmwareEvent
import com.jalsuraksha.app.data.LinkState
import com.jalsuraksha.app.data.Sample
import com.jalsuraksha.app.data.Severity
import com.jalsuraksha.app.domain.BucketSize
import com.jalsuraksha.app.domain.FlowSeries
import com.jalsuraksha.app.domain.UsageSlot
import com.jalsuraksha.app.domain.UsageStats

/** What every screen reads. Flow and total are already calibrated for display when the person opted in. */
data class UiSnapshot(
    val settingsLoaded: Boolean = false,
    val settings: AppSettings = AppSettings(),
    val device: DeviceSnapshot = DeviceSnapshot(),
    val link: LinkState = LinkState.CONNECTING,
    val nowMs: Long = 0L,
    val flowLpm: Double? = null,
    val totalLiters: Double? = null,
    val flowBLpm: Double? = null,
    val flowDifferenceLpm: Double? = null,
    val totalBLiters: Double? = null,
    val rateAHz: Double? = null,
    val rateBHz: Double? = null,
    val recent: List<Sample> = emptyList(),
    val events: List<EventRecord> = emptyList(),
    val firmwareEvents: List<FirmwareEvent> = emptyList(),
    val pumpCommand: PumpCommandUi = PumpCommandUi.Idle,
    val hasPassword: Boolean = false,
) {
    val status: DeviceStatus? get() = device.status
    val ageMs: Long? get() = device.lastSuccessMs?.let { nowMs - it }
    val attentionCount: Int get() = events.count { !it.acknowledged && it.severity != Severity.INFO }
}

/** Form values. A null control token means "keep the saved token". */
data class DeviceInput(
    val name: String,
    val address: String,
    val controlToken: String?,
    val clearControlToken: Boolean,
    val statusPath: String,
    val eventsPath: String,
    val commandPath: String,
)

enum class CommandOutcome { CONFIRMED, NOT_CONFIRMED, REJECTED, FAILED, BLOCKED }

sealed interface PumpCommandUi {
    data object Idle : PumpCommandUi
    data class InProgress(
        val requestedOn: Boolean,
        val actionLabel: String = if (requestedOn) "PUMP ON" else "PUMP OFF",
    ) : PumpCommandUi
    data class Done(
        val requestedOn: Boolean,
        val outcome: CommandOutcome,
        val message: String,
        val atMs: Long,
        val actionLabel: String = if (requestedOn) "PUMP ON" else "PUMP OFF",
    ) : PumpCommandUi
}

enum class TestKind { OK, AUTH, UNSUPPORTED, TIMEOUT, UNREACHABLE, INVALID, HTTP }

sealed interface TestUi {
    data object Idle : TestUi
    data object Running : TestUi
    data class Done(val kind: TestKind, val message: String, val detail: String?) : TestUi
}

enum class HistoryRange(val label: String, val durationMs: Long) {
    H6("6 hours", 6L * 3_600_000L),
    H24("24 hours", 24L * 3_600_000L),
    D7("7 days", 7L * 86_400_000L),
    D30("30 days", 30L * 86_400_000L),
}

sealed interface HistoryUi {
    data object Loading : HistoryUi
    data class Ready(
        val range: HistoryRange,
        val startMs: Long,
        val endMs: Long,
        val flow: FlowSeries,
        val bucketSize: BucketSize,
        val usage: List<UsageSlot>,
        val stats: UsageStats,
        val events: List<EventRecord>,
    ) : HistoryUi
}

enum class ExportKind { SAMPLES, EVENTS }
