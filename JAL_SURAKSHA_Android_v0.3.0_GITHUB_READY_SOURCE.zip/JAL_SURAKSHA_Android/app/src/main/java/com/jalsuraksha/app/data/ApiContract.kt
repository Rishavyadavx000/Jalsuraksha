package com.jalsuraksha.app.data

import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

/** Exact HTTP/JSON contract read from the supplied `JAL_SURAKSHA (1).ino` firmware sketch. */
object ApiContract {
    const val DEFAULT_STATUS_PATH = "/api/status"
    const val DEFAULT_EVENTS_PATH = "/api/events"
    const val DEFAULT_COMMAND_PATH = "/api/cmd"
    const val MAX_BODY_BYTES = 64L * 1024L
    const val MAX_EVENTS = 20

    const val KEY_FLOW_A = "fa"
    const val KEY_FLOW_B = "fb"
    const val KEY_DIFF = "diff"
    const val KEY_PCT = "pct"
    const val KEY_RATE_A = "ra"
    const val KEY_RATE_B = "rb"
    const val KEY_VOLUME_A = "va"
    const val KEY_VOLUME_B = "vb"
    const val KEY_PULSES_A = "pa"
    const val KEY_PULSES_B = "pb"
    const val KEY_CAL_PULSES_A = "cpa"
    const val KEY_CAL_PULSES_B = "cpb"
    const val KEY_STATE = "state"
    const val KEY_SEVERITY = "sev"
    const val KEY_LATCH = "latch"
    const val KEY_LOCATION = "loc"
    const val KEY_PUMP = "pump"
    const val KEY_MUTED = "muted"
    const val KEY_CALIBRATED = "cal"
    const val KEY_BASELINE_ACTIVE = "bl"
    const val KEY_SENSOR_HEALTH = "sens"
    const val KEY_WIFI = "wifi"
    const val KEY_RSSI = "rssi"
    const val KEY_IP = "ip"
    const val KEY_CLOUD = "cloud"
    const val KEY_UPTIME = "up"
    const val KEY_NOTE = "note"
    const val KEY_STOP = "stop"
    const val KEY_TOKEN_OK = "tokOk"
    const val KEY_AP_PASSWORD_DEFAULT = "apDef"
    const val KEY_RELAY_OK = "relayOk"
    const val KEY_EVENT_CODE = "ev"
    const val KEY_CONFIG = "cfg"

    const val COMMAND_START = "start"
    const val COMMAND_STOP = "stop"
    const val COMMAND_ACK = "ack"
    const val COMMAND_RESET = "reset"
    const val COMMAND_CAL_ZERO = "calzero"
    const val COMMAND_CAL_SAVE = "calsave"
    const val COMMAND_BASELINE = "baseline"
    const val COMMAND_SET = "set"
    const val COMMAND_WIFI = "wifi"
}

sealed interface ParseResult {
    data class Ok(val status: DeviceStatus) : ParseResult
    data class Invalid(val reason: String) : ParseResult
}

object StatusParser {
    fun parse(body: String, nowMs: Long): ParseResult {
        val json = try { JSONObject(body) } catch (_: JSONException) {
            return ParseResult.Invalid("The response is not a JSON object.")
        }
        if (!json.has(ApiContract.KEY_FLOW_A) || !json.has(ApiContract.KEY_FLOW_B) ||
            !json.has(ApiContract.KEY_PUMP) || !json.has(ApiContract.KEY_STATE)) {
            return ParseResult.Invalid("This is not the dual-sensor JAL-SURAKSHA firmware status schema (fa, fb, pump, state are required).")
        }

        val warnings = mutableListOf<String>()
        fun num(key: String): Double? = readNumber(json, key, warnings, nonNegative = true)
        fun integer(key: String): Long? = readLong(json, key, warnings)
        fun bool(key: String): Boolean? = readBoolean(json, key, warnings)
        fun str(key: String): String? = readString(json, key, warnings)

        val calibrated = bool(ApiContract.KEY_CALIBRATED)
        val rateAHz = num(ApiContract.KEY_RATE_A)
        val rateBHz = num(ApiContract.KEY_RATE_B)
        // Firmware deliberately reports fa/fb/va/vb as zero while uncalibrated. Do not present
        // those placeholders as real L/min or litres; the ra/rb fields remain pulse frequencies.
        val flowA = if (calibrated == true) num(ApiContract.KEY_FLOW_A) else null
        val flowB = if (calibrated == true) num(ApiContract.KEY_FLOW_B) else null
        val volumeA = if (calibrated == true) num(ApiContract.KEY_VOLUME_A) else null
        val volumeB = if (calibrated == true) num(ApiContract.KEY_VOLUME_B) else null
        if (calibrated != true) warnings += "Flow calibration is not active; only Sensor A/B pulse frequency (Hz) is valid."

        val pumpRaw = bool(ApiContract.KEY_PUMP)
        val pump = when (pumpRaw) {
            true -> PumpState.ON
            false -> PumpState.OFF
            null -> PumpState.UNKNOWN
        }
        val tokenOk = bool(ApiContract.KEY_TOKEN_OK)
        val relayOk = bool(ApiContract.KEY_RELAY_OK)
        val permission = when {
            tokenOk == true && relayOk == true -> FirmwarePumpPermission.ENABLED
            tokenOk == false || relayOk == false -> FirmwarePumpPermission.LOCKED
            else -> FirmwarePumpPermission.UNKNOWN
        }

        val config = json.optJSONObject(ApiContract.KEY_CONFIG)?.let { c ->
            FirmwareConfig(
                kA = readNumber(c, "kA", warnings, true),
                kB = readNumber(c, "kB", warnings, true),
                windowMs = readLong(c, "win", warnings),
                zeroLpm = readNumber(c, "zero", warnings, true),
                minAbs = readNumber(c, "abs", warnings, true),
                relativePercent = readNumber(c, "rel", warnings, true),
                persistence = readLong(c, "pers", warnings)?.takeIf { it in 0..255 }?.toInt(),
                baseline = readBaseline(c, warnings),
            )
        }

        val status = DeviceStatus(
            wifi = str(ApiContract.KEY_WIFI),
            ip = str(ApiContract.KEY_IP),
            rssiDbm = readRssi(json, warnings),
            pump = pump,
            pumpPermission = permission,
            flowLpm = flowA,
            totalLiters = volumeA,
            deviceId = null,
            apiVersion = 1,
            receivedAtMs = nowMs,
            contradictoryPump = false,
            warnings = warnings.toList(),
            flowALpm = flowA,
            flowBLpm = flowB,
            differenceLpm = readSignedNumber(json, ApiContract.KEY_DIFF, warnings),
            differencePercent = readSignedNumber(json, ApiContract.KEY_PCT, warnings),
            rateAHz = rateAHz,
            rateBHz = rateBHz,
            volumeALiters = volumeA,
            volumeBLiters = volumeB,
            pulsesA = integer(ApiContract.KEY_PULSES_A),
            pulsesB = integer(ApiContract.KEY_PULSES_B),
            calibrationPulsesA = integer(ApiContract.KEY_CAL_PULSES_A),
            calibrationPulsesB = integer(ApiContract.KEY_CAL_PULSES_B),
            systemState = str(ApiContract.KEY_STATE),
            severityLevel = integer(ApiContract.KEY_SEVERITY)?.takeIf { it in 0..3 }?.toInt(),
            latch = str(ApiContract.KEY_LATCH),
            locationEstimate = str(ApiContract.KEY_LOCATION),
            muted = bool(ApiContract.KEY_MUTED),
            calibrated = calibrated,
            baselineActive = bool(ApiContract.KEY_BASELINE_ACTIVE),
            sensorHealth = str(ApiContract.KEY_SENSOR_HEALTH),
            cloudState = str(ApiContract.KEY_CLOUD),
            uptimeSeconds = integer(ApiContract.KEY_UPTIME),
            note = str(ApiContract.KEY_NOTE),
            stopReason = str(ApiContract.KEY_STOP),
            tokenConfigured = tokenOk,
            accessPointPasswordDefault = bool(ApiContract.KEY_AP_PASSWORD_DEFAULT),
            relayPolarityVerified = relayOk,
            firmwareEventCode = integer(ApiContract.KEY_EVENT_CODE)?.takeIf { it in 0..255 }?.toInt(),
            firmwareConfig = config,
        )
        if (pump == PumpState.UNKNOWN) warnings += "Pump state could not be decoded; control remains unavailable."
        return ParseResult.Ok(status.copy(warnings = warnings.toList()))
    }

    fun parseEvents(body: String, nowMs: Long): List<FirmwareEvent> {
        val array = try { JSONArray(body) } catch (_: JSONException) {
            throw IllegalArgumentException("The events response is not a JSON array.")
        }
        val out = ArrayList<FirmwareEvent>(minOf(array.length(), ApiContract.MAX_EVENTS))
        for (i in 0 until minOf(array.length(), ApiContract.MAX_EVENTS)) {
            val item = array.optJSONObject(i) ?: continue
            val uptime = item.optLong("u", -1L).takeIf { it >= 0 } ?: continue
            val code = item.optInt("c", -1).takeIf { it in 0..255 } ?: continue
            val epochSeconds = item.optLong("t", 0L).takeIf { it > 0L }
            val message = item.optString("m", "").filter { !it.isISOControl() }.take(110)
            val id = (uptime shl 16) or (code.toLong() shl 8) or i.toLong()
            out += FirmwareEvent(id, epochSeconds?.times(1_000L), uptime, code, message)
        }
        return out
    }

    private fun raw(json: JSONObject, key: String): Any? {
        if (!json.has(key)) return null
        val value = json.opt(key)
        return if (value == null || value === JSONObject.NULL) null else value
    }

    private fun readNumber(json: JSONObject, key: String, warnings: MutableList<String>, nonNegative: Boolean): Double? {
        val value = raw(json, key) ?: return null
        val number = (value as? Number)?.toDouble()
        if (number == null || !number.isFinite() || (nonNegative && number < 0.0)) {
            warnings += "$key is not a valid ${if (nonNegative) "non-negative " else ""}number."
            return null
        }
        return number
    }

    private fun readSignedNumber(json: JSONObject, key: String, warnings: MutableList<String>): Double? =
        readNumber(json, key, warnings, nonNegative = false)

    private fun readLong(json: JSONObject, key: String, warnings: MutableList<String>): Long? {
        val value = raw(json, key) ?: return null
        val number = (value as? Number)?.toDouble()
        if (number == null || !number.isFinite() || number < 0.0 || number > Long.MAX_VALUE.toDouble() || number != Math.rint(number)) {
            warnings += "$key is not a valid non-negative whole number."
            return null
        }
        return number.toLong()
    }

    private fun readBoolean(json: JSONObject, key: String, warnings: MutableList<String>): Boolean? {
        val value = raw(json, key) ?: return null
        if (value !is Boolean) {
            warnings += "$key has the wrong type (expected true or false)."
            return null
        }
        return value
    }

    private fun readString(json: JSONObject, key: String, warnings: MutableList<String>): String? {
        val value = raw(json, key) ?: return null
        if (value !is String) {
            warnings += "$key has the wrong type (expected text)."
            return null
        }
        return value.filter { !it.isISOControl() }.trim().take(100).ifEmpty { null }
    }

    private fun readBaseline(json: JSONObject, warnings: MutableList<String>): Double? {
        val value = readSignedNumber(json, "base", warnings) ?: return null
        if (value !in -5.0..5.0) {
            warnings += "base is outside the firmware's -5..5 L/min range."
            return null
        }
        return value
    }

    private fun readRssi(json: JSONObject, warnings: MutableList<String>): Int? {
        val d = readSignedNumber(json, ApiContract.KEY_RSSI, warnings) ?: return null
        if (d != Math.rint(d) || d < -127.0 || d > 0.0) {
            warnings += "rssi is outside the valid -127..0 dBm range."
            return null
        }
        return d.toInt()
    }
}

sealed interface CommandParseResult {
    data class Ok(val accepted: Boolean, val message: String) : CommandParseResult
    data class Invalid(val reason: String) : CommandParseResult
}

object CommandReplyParser {
    fun parse(body: String): CommandParseResult {
        return try {
            val json = JSONObject(body)
            val accepted = json.opt("ok") as? Boolean
                ?: return CommandParseResult.Invalid("The command response does not contain a Boolean 'ok' field.")
            val message = json.optString("msg", if (accepted) "Command accepted." else "Command rejected.")
                .filter { !it.isISOControl() }.take(160)
            CommandParseResult.Ok(accepted, message)
        } catch (_: JSONException) {
            CommandParseResult.Invalid("The command response is not JSON.")
        }
    }
}
