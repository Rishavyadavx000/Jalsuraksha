package com.jalsuraksha.app.ui

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.jalsuraksha.app.JalApplication
import com.jalsuraksha.app.data.ApiError
import com.jalsuraksha.app.data.ApiContract
import com.jalsuraksha.app.data.ApiOutcome
import com.jalsuraksha.app.data.AppSettings
import com.jalsuraksha.app.data.DeviceCredentials
import com.jalsuraksha.app.data.DeviceSnapshot
import com.jalsuraksha.app.data.DeviceStatus
import com.jalsuraksha.app.data.Endpoint
import com.jalsuraksha.app.data.EndpointValidator
import com.jalsuraksha.app.data.EventRecord
import com.jalsuraksha.app.data.FirmwareEvent
import com.jalsuraksha.app.data.FirmwareCommandReply
import com.jalsuraksha.app.data.EventType
import com.jalsuraksha.app.data.FirmwarePumpPermission
import com.jalsuraksha.app.data.PumpState
import com.jalsuraksha.app.data.Sample
import com.jalsuraksha.app.data.Severity
import com.jalsuraksha.app.data.userMessage
import com.jalsuraksha.app.data.shortLabel
import com.jalsuraksha.app.data.LinkState
import com.jalsuraksha.app.domain.AlertEngine
import com.jalsuraksha.app.domain.AlertState
import com.jalsuraksha.app.domain.AlertThresholds
import com.jalsuraksha.app.domain.Analytics
import com.jalsuraksha.app.domain.BucketSize
import com.jalsuraksha.app.domain.CsvExport
import com.jalsuraksha.app.domain.LinkDeriver
import com.jalsuraksha.app.domain.NewEvent
import com.jalsuraksha.app.domain.PumpGatePolicy
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Single owner of connection state. Polling runs only while the app is in the foreground, never
 * overlaps itself (one mutex), backs off while the device is unreachable, and stops with the
 * ViewModel. All blocking work (network, files, keystore) runs off the main thread.
 */
class AppViewModel(app: Application) : AndroidViewModel(app) {

    private val container = (app as JalApplication).container
    private val settingsRepo = container.settingsRepository
    private val secrets = container.secretStore
    private val api = container.deviceApi
    private val historyStore = container.historyStore
    private val eventStore = container.eventStore

    private val settingsLoaded = MutableStateFlow(false)
    val settings: StateFlow<AppSettings> = settingsRepo.settings
        .onEach { settingsLoaded.value = true }
        .stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())

    private val device = MutableStateFlow(DeviceSnapshot())
    private val recent = MutableStateFlow<List<Sample>>(emptyList())
    private val events = MutableStateFlow<List<EventRecord>>(emptyList())
    private val pumpCommand = MutableStateFlow<PumpCommandUi>(PumpCommandUi.Idle)
    private val hasPassword = MutableStateFlow(false)

    private val ticker: Flow<Long> = flow {
        while (true) {
            emit(System.currentTimeMillis())
            delay(1_000L)
        }
    }

    /** Re-emits every second while a screen is collecting, so "updated 3 s ago" and staleness stay live. */
    val ui: StateFlow<UiSnapshot> = combine(settings, device, ticker, recent, events) { s, d, now, r, e ->
        buildSnapshot(s, d, now, r, e)
    }
        .combine(pumpCommand) { snap, cmd -> snap.copy(pumpCommand = cmd) }
        .combine(hasPassword) { snap, hp -> snap.copy(hasPassword = hp) }
        .combine(settingsLoaded) { snap, loaded -> snap.copy(settingsLoaded = loaded) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000L), UiSnapshot())

    private val _test = MutableStateFlow<TestUi>(TestUi.Idle)
    val testState: StateFlow<TestUi> = _test.asStateFlow()

    private val _history = MutableStateFlow<HistoryUi>(HistoryUi.Loading)
    val history: StateFlow<HistoryUi> = _history.asStateFlow()

    private var pollJob: Job? = null
    private var historyJob: Job? = null
    private val pollMutex = Mutex()
    private val eventsMutex = Mutex()
    private var alertState = AlertState()
    private var lastPersistedMs = 0L
    private var lastFirmwareEventsFetchMs = 0L
    private var lastEventId = 0L
    private var refreshing = false

    val appVersion: String = try {
        app.packageManager.getPackageInfo(app.packageName, 0).versionName ?: "unknown"
    } catch (e: Exception) {
        "unknown"
    }

    init {
        viewModelScope.launch {
            guarded("Loading saved data") {
                val s = settingsRepo.settings.first()
                val now = System.currentTimeMillis()
                val cutoff = now - s.retentionDays * 86_400_000L

                val all = eventStore.loadAll().sortedByDescending { it.tMs }
                val keep = all.filter { it.tMs >= cutoff }.take(MAX_EVENTS)
                eventsMutex.withLock {
                    events.value = keep
                    lastEventId = maxOf(lastEventId, keep.maxOfOrNull { it.id } ?: 0L)
                    if (keep.size != all.size) {
                        eventStore.replaceAll(keep.reversed())
                    }
                }

                historyStore.prune(cutoff)
                recent.value = historyStore.loadSince(now - RECENT_WINDOW_MS)
            }
        }
        viewModelScope.launch(Dispatchers.IO) {
            hasPassword.value = secrets.hasControlToken()
        }
    }

    // ---------------------------------------------------------------- lifecycle / polling

    fun onAppForeground() {
        if (pollJob?.isActive == true) return
        pollJob = viewModelScope.launch {
            while (isActive) {
                pollOnce()
                delay(nextDelayMs())
            }
        }
    }

    fun onAppBackground() {
        pollJob?.cancel()
        pollJob = null
    }

    fun refreshNow() {
        if (refreshing) return
        refreshing = true
        viewModelScope.launch {
            try {
                pollOnce()
            } finally {
                refreshing = false
            }
        }
    }

    private fun nextDelayMs(): Long {
        val s = settings.value
        if (!s.isConfigured) return 1_000L
        val base = s.pollIntervalSec * 1_000L
        val failures = device.value.consecutiveFailures
        if (failures == 0) return base
        val multiplier = 1L shl minOf(failures, 4)
        return minOf(MAX_BACKOFF_MS, base * multiplier)
    }

    private suspend fun pollOnce() {
        try {
            fetchAndApply()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            noteInternal("Polling error: ${e.javaClass.simpleName}")
        }
    }

    /** The only place that talks to the device for status. Serialised so two requests never overlap. */
    private suspend fun fetchAndApply(): ApiOutcome<DeviceStatus> = pollMutex.withLock {
        val s = settings.value
        val ep = endpointFor(s) ?: return@withLock ApiOutcome.Failure(ApiError.NotConfigured)
        val outcome = api.fetchStatus(ep)
        val now = System.currentTimeMillis()
        when (outcome) {
            is ApiOutcome.Success -> {
                handleStatus(s, outcome.value, outcome.latencyMs, now)
                if (now - lastFirmwareEventsFetchMs >= FIRMWARE_EVENTS_INTERVAL_MS) {
                    lastFirmwareEventsFetchMs = now
                    when (val eventResult = api.fetchEvents(ep)) {
                        is ApiOutcome.Success -> device.update { it.copy(firmwareEvents = eventResult.value) }
                        is ApiOutcome.Failure -> noteInternal("Firmware events unavailable: ${eventResult.error.shortLabel()}")
                    }
                }
            }
            is ApiOutcome.Failure -> handleFailure(s, outcome.error, now)
        }
        outcome
    }

    private suspend fun endpointFor(s: AppSettings, tokenOverride: String? = null): Endpoint? {
        if (!s.isConfigured) return null
        val token = tokenOverride ?: withContext(Dispatchers.IO) { secrets.getControlToken() }
        val credentials = token?.let { DeviceCredentials(it) }
        return Endpoint(s.host, s.port, s.statusPath, s.eventsPath, s.commandPath, credentials)
    }

    private suspend fun handleStatus(s: AppSettings, status: DeviceStatus, latencyMs: Long, now: Long) {
        val before = device.value
        device.value = before.copy(
            status = status,
            lastSuccessMs = now,
            lastAttemptMs = now,
            consecutiveFailures = 0,
            lastError = null,
            lastLatencyMs = latencyMs,
            successCount = before.successCount + 1,
        )

        // Alert thresholds compare against what the person sees, so apply the display calibration to flow only.
        val factor = s.calibrationFactorInUse
        val forAlerts = if (factor == 1.0) status else status.copy(
            flowLpm = status.flowALpm?.times(factor),
            flowALpm = status.flowALpm?.times(factor),
            flowBLpm = status.flowBLpm?.times(factor),
            differenceLpm = status.differenceLpm?.times(factor),
        )
        val step = AlertEngine.onStatus(alertState, forAlerts, now, thresholds(s))
        alertState = step.state
        emitEvents(step.events, now)

        val sample = Sample(
            now, status.flowALpm, status.volumeALiters, status.pump, status.rssiDbm,
            flowBLpm = status.flowBLpm, totalBLiters = status.volumeBLiters,
            differenceLpm = status.differenceLpm,
        )
        recent.update { (it + sample).takeLast(MAX_RECENT_SAMPLES) }
        val pumpChanged = before.status != null && before.status.pump != status.pump
        if (now - lastPersistedMs >= s.historyIntervalSec * 1_000L || pumpChanged) {
            lastPersistedMs = now
            guarded("Saving history") { historyStore.append(sample) }
        }
    }

    private suspend fun handleFailure(s: AppSettings, error: ApiError, now: Long) {
        val before = device.value
        val failures = before.consecutiveFailures + 1
        device.value = before.copy(
            lastAttemptMs = now,
            consecutiveFailures = failures,
            lastError = error,
            failureCount = before.failureCount + 1,
        )
        val step = AlertEngine.onFailure(alertState, error, failures, before.lastSuccessMs, now, thresholds(s))
        alertState = step.state
        emitEvents(step.events, now)
    }

    private fun thresholds(s: AppSettings) = AlertThresholds(
        highFlowLpm = s.highFlowLpm,
        noFlowGraceSec = s.noFlowGraceSec,
        flowWhileOffLpm = s.flowWhileOffLpm,
        flowWhileOffGraceSec = s.flowWhileOffGraceSec,
        weakSignalDbm = s.weakSignalDbm,
        staleAfterSec = s.staleAfterSec,
    )

    private fun buildSnapshot(
        s: AppSettings,
        d: DeviceSnapshot,
        now: Long,
        r: List<Sample>,
        e: List<EventRecord>,
    ): UiSnapshot {
        val link = LinkDeriver.derive(s.isConfigured, d, now, s.staleAfterSec * 1_000L)
        val factor = s.calibrationFactorInUse
        val status = d.status
        return UiSnapshot(
            settings = s,
            device = d,
            link = link,
            nowMs = now,
            flowLpm = status?.flowALpm?.let { it * factor },
            totalLiters = status?.volumeALiters?.let { it * factor },
            flowBLpm = status?.flowBLpm?.let { it * factor },
            flowDifferenceLpm = status?.differenceLpm?.let { it * factor },
            totalBLiters = status?.volumeBLiters?.let { it * factor },
            rateAHz = status?.rateAHz,
            rateBHz = status?.rateBHz,
            recent = if (factor == 1.0) r else r.map { it.scaled(factor) },
            events = e,
            firmwareEvents = d.firmwareEvents,
        )
    }

    private fun Sample.scaled(f: Double): Sample = copy(
        flowLpm = flowLpm?.times(f), totalLiters = totalLiters?.times(f),
        flowBLpm = flowBLpm?.times(f), totalBLiters = totalBLiters?.times(f),
        differenceLpm = differenceLpm?.times(f),
    )

    // ---------------------------------------------------------------- events

    private fun nextEventId(now: Long): Long {
        lastEventId = maxOf(lastEventId + 1, now)
        return lastEventId
    }

    private suspend fun emitEvents(list: List<NewEvent>, now: Long) {
        if (list.isEmpty()) return
        eventsMutex.withLock {
            val records = list.map { EventRecord(nextEventId(now), now, it.severity, it.type, it.message) }
            events.update { (records.reversed() + it).take(MAX_EVENTS) }
            for (r in records) {
                guarded("Saving event") { eventStore.append(r) }
            }
        }
    }

    private suspend fun logEvent(severity: Severity, type: EventType, message: String) {
        emitEvents(listOf(NewEvent(severity, type, message)), System.currentTimeMillis())
    }

    fun acknowledge(id: Long) = acknowledgeWhere { it.id == id }

    fun acknowledgeAll() = acknowledgeWhere { true }

    private fun acknowledgeWhere(matches: (EventRecord) -> Boolean) {
        viewModelScope.launch {
            eventsMutex.withLock {
                events.update { list ->
                    list.map { if (matches(it) && !it.acknowledged) it.copy(acknowledged = true) else it }
                }
                val toWrite = events.value.reversed()
                guarded("Saving events") { eventStore.replaceAll(toWrite) }
            }
        }
    }

    // ---------------------------------------------------------------- device setup

    private sealed interface Checked {
        data class Ok(val host: String, val port: Int) : Checked
        data class Bad(val reason: String) : Checked
    }

    private fun check(input: DeviceInput): Checked {
        val valid = when (val p = EndpointValidator.parse(input.address)) {
            is EndpointValidator.Result.Invalid -> return Checked.Bad(p.reason)
            is EndpointValidator.Result.Valid -> p
        }
        val paths = listOf(
            "The status path" to input.statusPath,
            "The events path" to input.eventsPath,
            "The command path" to input.commandPath,
        )
        for ((label, path) in paths) {
            if (!EndpointValidator.isValidPath(path)) {
                return Checked.Bad("$label must start with / and contain no spaces, ? or #.")
            }
        }
        return Checked.Ok(valid.host, valid.port)
    }

    fun clearTest() {
        _test.value = TestUi.Idle
    }

    fun testConnection(input: DeviceInput) {
        if (_test.value is TestUi.Running) return
        _test.value = TestUi.Running
        viewModelScope.launch {
            _test.value = try {
                runTest(input)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                TestUi.Done(TestKind.UNREACHABLE, "The test could not run (${e.javaClass.simpleName}).", null)
            }
        }
    }

    private suspend fun runTest(input: DeviceInput): TestUi.Done {
        val ok = when (val c = check(input)) {
            is Checked.Bad -> return TestUi.Done(TestKind.INVALID, c.reason, null)
            is Checked.Ok -> c
        }
        val token: String? = when {
            input.clearControlToken -> null
            !input.controlToken.isNullOrEmpty() -> input.controlToken
            else -> withContext(Dispatchers.IO) { secrets.getControlToken() }
        }
        val ep = Endpoint(
            ok.host, ok.port, input.statusPath, input.eventsPath, input.commandPath,
            token?.let { DeviceCredentials(it) },
        )
        return when (val outcome = api.fetchStatus(ep)) {
            is ApiOutcome.Success -> {
                val st = outcome.value
                val detail = describeStatus(st) + if (st.tokenConfigured == true) " Control token is configured." else " Control commands are locked until CONTROL_TOKEN is configured in firmware."
                TestUi.Done(TestKind.OK, "Connected to the JAL-SURAKSHA dual-sensor API in ${outcome.latencyMs} ms.", detail)
            }
            is ApiOutcome.Failure -> TestUi.Done(kindOf(outcome.error), outcome.error.userMessage(), null)
        }
    }

    private fun kindOf(error: ApiError): TestKind = when (error) {
        is ApiError.AuthRequired, is ApiError.FirmwareControlLocked -> TestKind.AUTH
        is ApiError.BadResponse -> TestKind.UNSUPPORTED
        is ApiError.Timeout -> TestKind.TIMEOUT
        is ApiError.Unreachable -> TestKind.UNREACHABLE
        is ApiError.InvalidEndpoint -> TestKind.INVALID
        is ApiError.NotConfigured -> TestKind.INVALID
        is ApiError.HttpError -> TestKind.HTTP
    }

    private fun describeStatus(st: DeviceStatus): String {
        val a = st.flowALpm?.let { String.format(Locale.US, "A %.2f L/min", it) } ?: "A --"
        val b = st.flowBLpm?.let { String.format(Locale.US, "B %.2f L/min", it) } ?: "B --"
        val permission = when (st.pumpPermission) {
            FirmwarePumpPermission.ENABLED -> "control token set and relay polarity verified"
            FirmwarePumpPermission.LOCKED -> "firmware control locked"
            FirmwarePumpPermission.UNKNOWN -> "firmware control permission unknown"
        }
        val state = st.systemState ?: "unknown system state"
        return "${st.pump.name}; $a; $b; state $state; $permission."
    }

    /** Validates, stores the control token in Android Keystore and saves the local device profile. */
    fun saveDevice(input: DeviceInput, onResult: (String?) -> Unit) {
        viewModelScope.launch {
            val ok = when (val c = check(input)) {
                is Checked.Bad -> {
                    onResult(c.reason)
                    return@launch
                }
                is Checked.Ok -> c
            }
            val stored = withContext(Dispatchers.IO) {
                when {
                    input.clearControlToken -> secrets.setControlToken(null)
                    !input.controlToken.isNullOrEmpty() -> secrets.setControlToken(input.controlToken)
                    else -> true
                }
            }
            if (!stored) {
                onResult(secrets.lastError ?: "The control token could not be stored securely.")
                return@launch
            }
            settingsRepo.update {
                it.copy(
                    onboardingDone = true,
                    deviceName = input.name.trim().ifEmpty { "JAL-SURAKSHA" },
                    host = ok.host,
                    port = ok.port,
                    username = "", // v0.2 Basic Auth field is not used by the current ESP32 firmware
                    statusPath = input.statusPath,
                    eventsPath = input.eventsPath,
                    commandPath = input.commandPath,
                    pumpOnPath = input.commandPath,
                    pumpOffPath = input.commandPath,
                )
            }
            hasPassword.value = withContext(Dispatchers.IO) { secrets.hasControlToken() }
            // Wait for any in-flight request to the old address to finish before clearing its state.
            pollMutex.withLock {
                device.value = DeviceSnapshot()
                alertState = AlertState()
            }
            onResult(null)
            refreshNow()
        }
    }

    fun forgetPassword() {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { secrets.setControlToken(null) }
            hasPassword.value = false
        }
    }


    // ---------------------------------------------------------------- pump

    fun dismissPumpResult() {
        if (pumpCommand.value is PumpCommandUi.Done) {
            pumpCommand.value = PumpCommandUi.Idle
        }
    }

    /** The caller must already have shown the confirmation dialog for ON. The gate is re-checked here. */
    fun requestPump(on: Boolean) {
        if (pumpCommand.value is PumpCommandUi.InProgress) return
        pumpCommand.value = PumpCommandUi.InProgress(on)
        viewModelScope.launch {
            try {
                runPumpCommand(on)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                pumpCommand.value = PumpCommandUi.Done(
                    on,
                    CommandOutcome.FAILED,
                    "The request could not be completed (${e.javaClass.simpleName}). The pump state is unconfirmed: check the hardware.",
                    System.currentTimeMillis(),
                )
            }
        }
    }

    private suspend fun runPumpCommand(on: Boolean) {
        val label = if (on) "ON" else "OFF"
        val s = settings.value
        val now0 = System.currentTimeMillis()
        val link = LinkDeriver.derive(s.isConfigured, device.value, now0, s.staleAfterSec * 1_000L)
        val gate = PumpGatePolicy.evaluate(
            link,
            device.value.status,
            commandInProgress = false,
            requestsEnabled = s.pumpRequestsEnabled,
        )
        val blocked = if (on) gate.onBlockedReason else gate.offBlockedReason
        if (blocked != null) {
            pumpCommand.value = PumpCommandUi.Done(on, CommandOutcome.BLOCKED, blocked, now0)
            return
        }
        val ep = endpointFor(s)
        if (ep == null) {
            pumpCommand.value = PumpCommandUi.Done(on, CommandOutcome.BLOCKED, "No device is set up.", now0)
            return
        }

        val command = if (on) ApiContract.COMMAND_START else ApiContract.COMMAND_STOP
        val sent = api.sendCommand(ep, command)
        val sendError: ApiError? = if (sent is ApiOutcome.Failure) sent.error else null
        val rejected = sendError is ApiError.HttpError || sendError is ApiError.AuthRequired ||
            sendError is ApiError.FirmwareControlLocked || sendError is ApiError.BadResponse
        val attempts = if (rejected) 1 else READBACK_ATTEMPTS
        val wanted = if (on) PumpState.ON else PumpState.OFF

        // A 2xx reply only means "accepted". A timeout does not mean "not executed". Always read the state back.
        var confirmed = false
        var attempt = 0
        while (attempt < attempts && !confirmed) {
            delay(if (attempt == 0) 700L else 1_000L)
            val read = fetchAndApply()
            if (read is ApiOutcome.Success && read.value.pump == wanted) {
                confirmed = true
            }
            attempt += 1
        }

        val doneAt = System.currentTimeMillis()
        val result: PumpCommandUi.Done = when {
            confirmed -> PumpCommandUi.Done(
                on, CommandOutcome.CONFIRMED, "The device confirmed the pump is $label.", doneAt,
            )
            sendError is ApiError.AuthRequired -> PumpCommandUi.Done(
                on, CommandOutcome.REJECTED, "The firmware rejected the control token (HTTP 401). Nothing was changed.", doneAt,
            )
            sendError is ApiError.FirmwareControlLocked -> PumpCommandUi.Done(
                on, CommandOutcome.REJECTED, "Firmware control is locked. Configure CONTROL_TOKEN and verify relay polarity in the sketch.", doneAt,
            )
            sendError is ApiError.BadResponse -> PumpCommandUi.Done(
                on, CommandOutcome.REJECTED, sendError.reason, doneAt,
            )
            sendError is ApiError.HttpError -> PumpCommandUi.Done(
                on, CommandOutcome.REJECTED, "The firmware rejected the command (HTTP ${sendError.code}). The pump state was not assumed to change.", doneAt,
            )
            sendError != null -> PumpCommandUi.Done(
                on, CommandOutcome.FAILED, "The request did not complete, so the pump state is unconfirmed. Check the hardware.", doneAt,
            )
            else -> PumpCommandUi.Done(
                on, CommandOutcome.NOT_CONFIRMED, "The firmware accepted the command but does not report the pump $label. Do not assume it changed. Check the hardware.", doneAt,
            )
        }
        pumpCommand.value = result
        val severity = if (result.outcome == CommandOutcome.CONFIRMED) Severity.INFO else Severity.WARNING
        logEvent(severity, EventType.PUMP_COMMAND, "Pump $label requested. ${result.message}")
    }

    /** Send a command from the supplied firmware's token-protected POST /api/cmd route. */
    fun sendFirmwareCommand(command: String, params: Map<String, String> = emptyMap()) {
        if (pumpCommand.value is PumpCommandUi.InProgress) return
        val actionLabel = when (command) {
            ApiContract.COMMAND_ACK -> "ACKNOWLEDGE ALARM"
            ApiContract.COMMAND_RESET -> "RESET ALARM"
            ApiContract.COMMAND_CAL_ZERO -> "ZERO CALIBRATION COUNTERS"
            ApiContract.COMMAND_CAL_SAVE -> "SAVE SENSOR CALIBRATION"
            ApiContract.COMMAND_BASELINE -> "CAPTURE BASELINE"
            ApiContract.COMMAND_SET -> "SAVE FIRMWARE SETTINGS"
            ApiContract.COMMAND_WIFI -> "SAVE WI-FI SETTINGS"
            else -> command.uppercase(Locale.US)
        }
        pumpCommand.value = PumpCommandUi.InProgress(requestedOn = false, actionLabel = actionLabel)
        viewModelScope.launch {
            val startedAt = System.currentTimeMillis()
            try {
                val s = settings.value
                val ep = endpointFor(s)
                val before = device.value.status
                if (!s.pumpRequestsEnabled) {
                    pumpCommand.value = PumpCommandUi.Done(
                        false, CommandOutcome.BLOCKED,
                        "Device commands are disabled in app Settings. Keep this disabled until firmware and hardware checks are complete.",
                        startedAt, actionLabel,
                    )
                    return@launch
                }
                if (ep == null || LinkDeriver.derive(s.isConfigured, device.value, startedAt, s.staleAfterSec * 1_000L) != LinkState.ONLINE) {
                    pumpCommand.value = PumpCommandUi.Done(false, CommandOutcome.BLOCKED, "Fresh ESP32 status is required before sending a firmware command.", startedAt, actionLabel)
                    return@launch
                }
                if (device.value.status?.tokenConfigured != true || ep.credentials?.isUsable != true) {
                    pumpCommand.value = PumpCommandUi.Done(false, CommandOutcome.BLOCKED, "Firmware commands are locked. Configure the CONTROL_TOKEN in the ESP32 sketch and save the same token in Device Settings.", startedAt, actionLabel)
                    return@launch
                }

                when (val sent = api.sendCommand(ep, command, params)) {
                    is ApiOutcome.Failure -> {
                        pumpCommand.value = PumpCommandUi.Done(false, CommandOutcome.REJECTED, sent.error.userMessage(), System.currentTimeMillis(), actionLabel)
                    }
                    is ApiOutcome.Success -> {
                        var confirmedStatus: DeviceStatus? = null
                        repeat(FIRMWARE_COMMAND_READBACK_ATTEMPTS) { attempt ->
                            if (confirmedStatus == null) {
                                delay(if (attempt == 0) 500L else 750L)
                                when (val read = fetchAndApply()) {
                                    is ApiOutcome.Success -> if (firmwareCommandConfirmed(command, params, before, read.value)) {
                                        confirmedStatus = read.value
                                    }
                                    is ApiOutcome.Failure -> Unit
                                }
                            }
                        }
                        val confirmed = confirmedStatus != null
                        val detail = if (confirmed) {
                            firmwareCommandConfirmation(command, confirmedStatus!!, sent.value.message)
                        } else {
                            "Firmware returned ok=true (${sent.value.message}), but the expected status change was not observed. Check the latest ESP32 status; do not assume the setting/action changed."
                        }
                        pumpCommand.value = PumpCommandUi.Done(
                            false,
                            if (confirmed) CommandOutcome.CONFIRMED else CommandOutcome.NOT_CONFIRMED,
                            detail,
                            System.currentTimeMillis(),
                            actionLabel,
                        )
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                pumpCommand.value = PumpCommandUi.Done(false, CommandOutcome.FAILED, "Firmware command failed (${e.javaClass.simpleName}).", System.currentTimeMillis(), actionLabel)
            }
        }
    }

    private fun firmwareCommandConfirmed(
        command: String,
        params: Map<String, String>,
        before: DeviceStatus?,
        after: DeviceStatus,
    ): Boolean = when (command) {
        ApiContract.COMMAND_ACK -> after.muted == true
        ApiContract.COMMAND_RESET -> after.pump == PumpState.OFF && after.latch?.equals("none", true) == true
        ApiContract.COMMAND_CAL_ZERO -> (after.calibrationPulsesA ?: Long.MAX_VALUE) <= 1L &&
            (after.calibrationPulsesB ?: Long.MAX_VALUE) <= 1L
        ApiContract.COMMAND_CAL_SAVE -> after.calibrated == true &&
            (after.firmwareConfig?.kA ?: 0.0) >= 1.0 && (after.firmwareConfig?.kB ?: 0.0) >= 1.0
        ApiContract.COMMAND_BASELINE -> after.baselineActive == true ||
            (before?.firmwareConfig?.baseline != after.firmwareConfig?.baseline && after.calibrated == true)
        ApiContract.COMMAND_SET -> params.isNotEmpty() && params.entries.all { (key, value) ->
            val cfg = after.firmwareConfig ?: return@all false
            val expected = value.toDoubleOrNull() ?: return@all false
            val actual = when (key) {
                "kA" -> cfg.kA
                "kB" -> cfg.kB
                "win" -> cfg.windowMs?.toDouble()
                "zero" -> cfg.zeroLpm
                "abs" -> cfg.minAbs
                "rel" -> cfg.relativePercent
                "pers" -> cfg.persistence?.toDouble()
                "base" -> cfg.baseline
                else -> null
            }
            actual != null && kotlin.math.abs(actual - expected) < 0.01
        }
        // Wi-Fi configuration intentionally reports accepted rather than confirmed; the ESP32 may
        // disconnect immediately while applying the new SSID/password.
        ApiContract.COMMAND_WIFI -> after.wifi != before?.wifi || after.ip != before?.ip
        else -> false
    }

    private fun firmwareCommandConfirmation(command: String, status: DeviceStatus, message: String): String = when (command) {
        ApiContract.COMMAND_ACK -> "ESP32 confirms the buzzer is muted. The alarm latch remains active."
        ApiContract.COMMAND_RESET -> "ESP32 confirms the alarm latch is cleared and the pump remains OFF."
        ApiContract.COMMAND_CAL_ZERO -> "ESP32 reports both calibration pulse counters reset."
        ApiContract.COMMAND_CAL_SAVE -> "ESP32 reports both sensors calibrated: K_A=${status.firmwareConfig?.kA} and K_B=${status.firmwareConfig?.kB} pulses/L."
        ApiContract.COMMAND_BASELINE -> "ESP32 reports baseline capture started or updated. ${status.note.orEmpty()}"
        ApiContract.COMMAND_SET -> "ESP32 status now matches the requested configuration."
        ApiContract.COMMAND_WIFI -> "ESP32 reports a network change after applying the Wi-Fi settings."
        else -> message
    }

    // ---------------------------------------------------------------- settings, calibration, data

    fun updateSettings(transform: (AppSettings) -> AppSettings) {
        viewModelScope.launch { settingsRepo.update(transform) }
    }

    fun saveCalibration(factor: Double, firmwarePpl: Double, suggestedPpl: Double, apply: Boolean) {
        viewModelScope.launch {
            val now = System.currentTimeMillis()
            settingsRepo.update {
                it.copy(
                    calFactor = factor,
                    calApplied = apply,
                    calDateMs = now,
                    calFirmwarePpl = firmwarePpl,
                    calSuggestedPpl = suggestedPpl,
                )
            }
            val applied = if (apply) "applied to displayed values" else "saved but not applied"
            logEvent(
                Severity.INFO,
                EventType.CALIBRATION_SAVED,
                "Calibration factor ${String.format(Locale.US, "%.3f", factor)} $applied. The device firmware was not changed.",
            )
        }
    }

    fun clearHistoryAndEvents() {
        viewModelScope.launch {
            guarded("Clearing history") { historyStore.clear() }
            eventsMutex.withLock {
                guarded("Clearing events") { eventStore.clear() }
                events.value = emptyList()
            }
            recent.value = emptyList()
            pollMutex.withLock { alertState = AlertState() }
        }
    }

    fun resetSettings() {
        viewModelScope.launch {
            settingsRepo.reset()
            withContext(Dispatchers.IO) { secrets.clear() }
            hasPassword.value = false
            pollMutex.withLock {
                device.value = DeviceSnapshot()
                alertState = AlertState()
            }
        }
    }

    fun loadHistory(range: HistoryRange) {
        historyJob?.cancel()
        _history.value = HistoryUi.Loading
        historyJob = viewModelScope.launch {
            val s = settings.value
            val end = System.currentTimeMillis()
            val start = end - range.durationMs
            val raw = guarded("Reading history") { historyStore.loadSince(start) } ?: emptyList()
            val factor = s.calibrationFactorInUse
            val maxGapMs = maxOf(s.historyIntervalSec * 3_000L, 30_000L)
            val ready = withContext(Dispatchers.Default) {
                val samples = if (factor == 1.0) raw else raw.map { it.scaled(factor) }
                val size = if (range.durationMs <= 24L * 3_600_000L) BucketSize.HOUR else BucketSize.DAY
                HistoryUi.Ready(
                    range = range,
                    startMs = start,
                    endMs = end,
                    flow = Analytics.flowSeries(samples, start, end, FLOW_BUCKETS),
                    bucketSize = size,
                    usage = Analytics.usageSlots(samples, size, TimeZone.getDefault(), maxGapMs, start, end),
                    stats = Analytics.stats(samples, maxGapMs),
                    events = emptyList(),
                )
            }
            val inRange = events.value.filter { it.tMs >= start && it.type in HISTORY_EVENT_TYPES }
            _history.value = ready.copy(events = inRange)
        }
    }

    /** Builds a share-sheet intent for a CSV in the app cache. Returns null if the file could not be written. */
    suspend fun buildExportIntent(kind: ExportKind, range: HistoryRange): Intent? =
        withContext(Dispatchers.IO) {
            try {
                val app = getApplication<Application>()
                val s = settings.value
                val now = System.currentTimeMillis()
                val since = now - range.durationMs
                val text = when (kind) {
                    ExportKind.SAMPLES -> CsvExport.samples(historyStore.loadSince(since), s.calibrationFactorInUse)
                    ExportKind.EVENTS -> CsvExport.events(events.value.filter { it.tMs >= since })
                }
                val dir = File(app.cacheDir, "exports")
                dir.mkdirs()
                dir.listFiles()?.forEach { it.delete() }
                val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date(now))
                val file = File(dir, "jal_suraksha_${kind.name.lowercase()}_$stamp.csv")
                file.writeText(text)
                val uri = FileProvider.getUriForFile(app, "${app.packageName}.fileprovider", file)
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/csv"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    putExtra(Intent.EXTRA_SUBJECT, "JAL-SURAKSHA export")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                Intent.createChooser(send, "Export CSV")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                noteInternal("Export failed: ${e.javaClass.simpleName}")
                null
            }
        }

    // ---------------------------------------------------------------- diagnostics helpers

    fun networkSummary(): String {
        val cm = getApplication<Application>().getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            ?: return "Unavailable"
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return "No active network"
        val parts = mutableListOf<String>()
        if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) parts += "Wi-Fi"
        if (caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) parts += "Mobile data"
        if (caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) parts += "Ethernet"
        return if (parts.isEmpty()) "Other network" else parts.joinToString(" + ")
    }

    fun secretStoreNote(): String? = secrets.lastError

    suspend fun storageSummary(): String {
        val n = historyStore.count()
        val kb = historyStore.sizeBytes() / 1024L
        return "$n samples ($kb KB), ${events.value.size} events"
    }

    // ---------------------------------------------------------------- internals

    private fun noteInternal(message: String) {
        device.update { it.copy(internalError = message) }
    }

    /** Runs storage work and turns failures into a Diagnostics note instead of crashing the app. */
    private suspend fun <T> guarded(what: String, block: suspend () -> T): T? = try {
        block()
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        noteInternal("$what failed: ${e.javaClass.simpleName}")
        null
    }

    private companion object {
        const val MAX_BACKOFF_MS = 30_000L
        const val FIRMWARE_EVENTS_INTERVAL_MS = 10_000L
        const val MAX_EVENTS = 500
        const val MAX_RECENT_SAMPLES = 1_500
        const val RECENT_WINDOW_MS = 60L * 60L * 1_000L
        const val READBACK_ATTEMPTS = 4
        const val FIRMWARE_COMMAND_READBACK_ATTEMPTS = 3
        const val FLOW_BUCKETS = 120

        val HISTORY_EVENT_TYPES = setOf(
            EventType.PUMP_STATE_CHANGED,
            EventType.PUMP_COMMAND,
            EventType.PUMP_LOCK_CHANGED,
            EventType.PUMP_STATUS_CONTRADICTION,
            EventType.DEVICE_ONLINE,
            EventType.DEVICE_OFFLINE,
            EventType.DEVICE_REBOOT,
        )
    }
}
