#!/usr/bin/env python3
"""Offline structural checks for the Kotlin sources. This is NOT a compiler."""
import os, re, sys, xml.etree.ElementTree as ET

ROOT = os.path.abspath(sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(__file__), ".."))
SRC = os.path.join(ROOT, "app", "src")
problems = []

def report(path, line, msg):
    rel = os.path.relpath(path, ROOT)
    problems.append(f"{rel}:{line}: {msg}")

# ---------------------------------------------------------------- scanner
class Scanner:
    def __init__(self, src, path):
        self.s, self.n, self.path = src, len(src), path
        self.out = []          # code with strings/comments blanked, templates kept
        self.errors = []

    def line_of(self, i):
        return self.s.count("\n", 0, i) + 1

    def blank(self, a, b):
        for k in range(a, b):
            self.out[k] = "\n" if self.s[k] == "\n" else " "

    def run(self):
        self.out = list(self.s)
        end = self.code(0, top=True)
        return "".join(self.out)

    def code(self, i, top=False):
        stack = []
        s, n = self.s, self.n
        while i < n:
            c = s[i]
            if s.startswith("//", i):
                j = s.find("\n", i)
                j = n if j < 0 else j
                self.blank(i, j); i = j; continue
            if s.startswith("/*", i):
                depth, j = 1, i + 2
                while j < n and depth:
                    if s.startswith("/*", j): depth += 1; j += 2
                    elif s.startswith("*/", j): depth -= 1; j += 2
                    else: j += 1
                self.blank(i, j); i = j; continue
            if s.startswith('"""', i):
                i = self.raw_string(i); continue
            if c == '"':
                i = self.string(i); continue
            if c == "'":
                j = i + 1
                if j < n and s[j] == "\\":
                    j += 2
                    while j < n and s[j] != "'": j += 1
                else:
                    j += 1
                if j < n and s[j] == "'":
                    self.blank(i, j + 1); i = j + 1; continue
                i += 1; continue
            if c in "([{":
                stack.append((c, i))
            elif c in ")]}":
                if not stack:
                    if not top:
                        return i + 1      # closing of a ${ } template
                    self.errors.append((self.line_of(i), f"unmatched '{c}'"))
                else:
                    o, oi = stack.pop()
                    if "([{".index(o) != ")]}".index(c):
                        self.errors.append((self.line_of(i), f"'{o}' from line {self.line_of(oi)} closed by '{c}'"))
            i += 1
        for o, oi in stack:
            self.errors.append((self.line_of(oi), f"unclosed '{o}'"))
        return i

    def template(self, i):
        # i points just after "${"
        return self.code(i, top=False)

    def string(self, i):
        s, n = self.s, self.n
        start = i; i += 1
        while i < n:
            c = s[i]
            if c == "\\": self.blank(i, i + 2); i += 2; continue
            if c == '"':
                return i + 1
            if c == "\n":
                self.errors.append((self.line_of(start), "unterminated string")); return i
            if s.startswith("${", i):
                self.blank(i, i + 2)
                i = self.template(i + 2)
                self.blank(i - 1, i)
                continue
            self.blank(i, i + 1); i += 1
        self.errors.append((self.line_of(start), "unterminated string")); return n

    def raw_string(self, i):
        s, n = self.s, self.n
        start = i; i += 3
        while i < n:
            if s.startswith('"""', i):
                j = i
                while j < n and s[j] == '"': j += 1
                return j
            if s.startswith("${", i):
                self.blank(i, i + 2); i = self.template(i + 2); self.blank(i - 1, i); continue
            self.blank(i, i + 1); i += 1
        self.errors.append((self.line_of(start), "unterminated raw string")); return n

# ---------------------------------------------------------------- collect files
kt_files = []
for d, _, fs in os.walk(SRC):
    for f in fs:
        if f.endswith(".kt"):
            kt_files.append(os.path.join(d, f))
kt_files.sort()

code = {}
raw = {}
for p in kt_files:
    raw[p] = open(p, encoding="utf-8").read()
    sc = Scanner(raw[p], p)
    code[p] = sc.run()
    for ln, msg in sc.errors:
        report(p, ln, "BRACKET/STRING: " + msg)

# ---------------------------------------------------------------- package vs path
def pkg_of(text):
    m = re.search(r"^\s*package\s+([\w.]+)", text, re.M)
    return m.group(1) if m else ""

for p in kt_files:
    pk = pkg_of(raw[p])
    rel = os.path.relpath(os.path.dirname(p), SRC)
    parts = rel.split(os.sep)
    # strip main/test/androidTest + java
    if len(parts) >= 2 and parts[1] == "java":
        expected = ".".join(parts[2:])
        if pk != expected:
            report(p, 1, f"package '{pk}' does not match directory '{expected}'")

# ---------------------------------------------------------------- project declarations
decl = {}      # name -> (package, file, kind)
ext_fun = {}   # extension fun name -> package
sigs = {}      # name -> list of (params) where params=[(name, has_default)]
def split_top(s):
    parts, depth, cur = [], 0, ""
    for ch in s:
        if ch in "([{<" and not (ch == "<" and False): depth += 1 if ch != "<" else 0
        if ch in ")]}" : depth -= 1
        if ch == "," and depth == 0:
            parts.append(cur); cur = ""
        else:
            cur += ch
    if cur.strip(): parts.append(cur)
    return parts

def balanced_args(text, open_idx):
    depth, i = 0, open_idx
    while i < len(text):
        c = text[i]
        if c in "([{": depth += 1
        elif c in ")]}":
            depth -= 1
            if depth == 0: return text[open_idx + 1:i], i
        i += 1
    return None, None

def parse_params(argtext):
    params = []
    for part in split_top(argtext):
        t = part.strip()
        if not t: continue
        t = re.sub(r"^(?:(?:private|public|internal|override|vararg)\s+)*(?:val|var)\s+", "", t)
        t = re.sub(r"^@\w+(\([^)]*\))?\s+", "", t)
        m = re.match(r"(\w+)\s*:", t)
        if not m: continue
        has_default = "=" in re.sub(r"->|=>|==|<=|>=|!=", "", t.split(":", 1)[1])
        params.append((m.group(1), has_default))
    return params

LINE_DECL = re.compile(r"^(?P<mods>(?:(?:public|internal|private|protected|data|sealed|enum|abstract|open|inline|const|suspend|annotation|value|override|lateinit)\s+)*)(?P<kind>class|interface|object|fun|val|var|typealias)\s+(?:<[^>]*>\s*)?(?P<name>[\w.]+)")

for p in kt_files:
    if os.sep + "test" + os.sep in p or "androidTest" in p: continue
    c = code[p]; pk = pkg_of(raw[p])
    offset = 0
    for line in c.split("\n"):
        line_start = offset
        offset += len(line) + 1
        if not line or line[0].isspace():
            continue
        m = LINE_DECL.match(line)
        if not m:
            continue
        name, kind, mods = m.group("name"), m.group("kind"), m.group("mods") or ""
        is_private = "private" in mods
        if "." in name and kind == "fun":
            ext_fun[name.split(".")[-1]] = pk
            continue
        if kind in ("val", "var"):
            # Top-level properties are valid import targets (for example MetricStyle).
            if not is_private:
                decl[name] = (pk, p, kind)
            continue
        if not is_private:
            decl[name] = (pk, p, kind)
        if kind in ("fun", "class"):
            j = line_start + m.end()
            while j < len(c) and c[j] in " \t": j += 1
            if j < len(c) and c[j] == "(":
                args, endi = balanced_args(c, j)
                if args is not None:
                    sigs.setdefault(name, []).append(parse_params(args))

# ---------------------------------------------------------------- imports
def imports_of(text):
    ex, wild = set(), set()
    for m in re.finditer(r"^import\s+([\w.]+)(\.\*)?\s*$", text, re.M):
        if m.group(2): wild.add(m.group(1))
        else: ex.add(m.group(1))
    return ex, wild

LIB = {
 # name: (packages, regex-for-usage)
 "Modifier": (["androidx.compose.ui"], r"\bModifier\b"),
 "Alignment": (["androidx.compose.ui"], r"\bAlignment\b"),
 "Composable": (["androidx.compose.runtime"], r"@Composable\b"),
 "remember": (["androidx.compose.runtime"], r"\bremember\s*[\({]"),
 "mutableStateOf": (["androidx.compose.runtime"], r"\bmutableStateOf\b"),
 "mutableFloatStateOf": (["androidx.compose.runtime"], r"\bmutableFloatStateOf\b"),
 "getValue": (["androidx.compose.runtime"], r"\bby\s+(?:remember|rememberSaveable|\w+\.collectAsStateWithLifecycle|nav\.currentBackStackEntryAsState|rememberUpdatedState)"),
 "setValue": (["androidx.compose.runtime"], r"\bvar\s+\w+\s+by\s+"),
 "LaunchedEffect": (["androidx.compose.runtime"], r"\bLaunchedEffect\b"),
 "DisposableEffect": (["androidx.compose.runtime"], r"\bDisposableEffect\b"),
 "rememberUpdatedState": (["androidx.compose.runtime"], r"\brememberUpdatedState\b"),
 "snapshotFlow": (["androidx.compose.runtime"], r"\bsnapshotFlow\b"),
 "rememberCoroutineScope": (["androidx.compose.runtime"], r"\brememberCoroutineScope\b"),
 "CompositionLocalProvider": (["androidx.compose.runtime"], r"\bCompositionLocalProvider\b"),
 "staticCompositionLocalOf": (["androidx.compose.runtime"], r"\bstaticCompositionLocalOf\b"),
 "Immutable": (["androidx.compose.runtime"], r"@Immutable\b"),
 "ReadOnlyComposable": (["androidx.compose.runtime"], r"@ReadOnlyComposable\b"),
 "rememberSaveable": (["androidx.compose.runtime.saveable"], r"\brememberSaveable\b"),
 "Box": (["androidx.compose.foundation.layout"], r"\bBox\s*[\({]"),
 "Column": (["androidx.compose.foundation.layout"], r"(?<![\w.])Column\s*[\({]"),
 "ColumnScope": (["androidx.compose.foundation.layout"], r"\bColumnScope\b"),
 "Row": (["androidx.compose.foundation.layout"], r"(?<![\w.])Row\s*[\({]"),
 "Spacer": (["androidx.compose.foundation.layout"], r"\bSpacer\s*\("),
 "Arrangement": (["androidx.compose.foundation.layout"], r"\bArrangement\."),
 "PaddingValues": (["androidx.compose.foundation.layout"], r"\bPaddingValues\b"),
 "fillMaxSize": (["androidx.compose.foundation.layout"], r"\.fillMaxSize\("),
 "fillMaxWidth": (["androidx.compose.foundation.layout"], r"\.fillMaxWidth\("),
 "height": (["androidx.compose.foundation.layout"], r"\.height\("),
 "heightIn": (["androidx.compose.foundation.layout"], r"\.heightIn\("),
 "width": (["androidx.compose.foundation.layout"], r"\.width\("),
 "size": (["androidx.compose.foundation.layout"], r"(?<=[\w)])\s*\.size\("),
 "padding": (["androidx.compose.foundation.layout"], r"\.padding\("),
 "imePadding": (["androidx.compose.foundation.layout"], r"\.imePadding\("),
 "systemBarsPadding": (["androidx.compose.foundation.layout"], r"\.systemBarsPadding\("),
 "background": (["androidx.compose.foundation"], r"\.background\("),
 "BorderStroke": (["androidx.compose.foundation"], r"\bBorderStroke\b"),
 "Canvas": (["androidx.compose.foundation"], r"\bCanvas\s*\("),
 "horizontalScroll": (["androidx.compose.foundation"], r"\.horizontalScroll\("),
 "verticalScroll": (["androidx.compose.foundation"], r"\.verticalScroll\("),
 "rememberScrollState": (["androidx.compose.foundation"], r"\brememberScrollState\b"),
 "isSystemInDarkTheme": (["androidx.compose.foundation"], r"\bisSystemInDarkTheme\b"),
 "LazyColumn": (["androidx.compose.foundation.lazy"], r"\bLazyColumn\b"),
 "items": (["androidx.compose.foundation.lazy"], r"(?<![\w.])items\s*\("),
 "CircleShape": (["androidx.compose.foundation.shape"], r"\bCircleShape\b"),
 "RoundedCornerShape": (["androidx.compose.foundation.shape"], r"\bRoundedCornerShape\b"),
 "toggleable": (["androidx.compose.foundation.selection"], r"\.toggleable\("),
 "KeyboardOptions": (["androidx.compose.foundation.text"], r"\bKeyboardOptions\b"),
 "Button": (["androidx.compose.material3"], r"(?<![\w.])Button\s*\("),
 "ButtonDefaults": (["androidx.compose.material3"], r"\bButtonDefaults\b"),
 "OutlinedButton": (["androidx.compose.material3"], r"\bOutlinedButton\s*\("),
 "Card": (["androidx.compose.material3"], r"(?<![\w.])Card\s*\("),
 "CardDefaults": (["androidx.compose.material3"], r"\bCardDefaults\b"),
 "FilterChip": (["androidx.compose.material3"], r"\bFilterChip\s*\("),
 "FilterChipDefaults": (["androidx.compose.material3"], r"\bFilterChipDefaults\b"),
 "Icon": (["androidx.compose.material3"], r"(?<![\w.])Icon\s*\("),
 "IconButton": (["androidx.compose.material3"], r"\bIconButton\s*\("),
 "MaterialTheme": (["androidx.compose.material3"], r"\bMaterialTheme\b"),
 "Slider": (["androidx.compose.material3"], r"(?<![\w.])Slider\s*\("),
 "Switch": (["androidx.compose.material3"], r"(?<![\w.])Switch\s*\("),
 "Text": (["androidx.compose.material3"], r"(?<![\w.])Text\s*\("),
 "TextButton": (["androidx.compose.material3"], r"\bTextButton\s*\("),
 "AlertDialog": (["androidx.compose.material3"], r"\bAlertDialog\s*\("),
 "Checkbox": (["androidx.compose.material3"], r"(?<![\w.])Checkbox\s*\("),
 "LinearProgressIndicator": (["androidx.compose.material3"], r"\bLinearProgressIndicator\s*\("),
 "OutlinedTextField": (["androidx.compose.material3"], r"\bOutlinedTextField\s*\("),
 "Badge": (["androidx.compose.material3"], r"(?<![\w.])Badge\s*[\({]"),
 "BadgedBox": (["androidx.compose.material3"], r"\bBadgedBox\s*\("),
 "NavigationBar": (["androidx.compose.material3"], r"(?<![\w.])NavigationBar\s*[\({]"),
 "NavigationBarItem": (["androidx.compose.material3"], r"\bNavigationBarItem\s*\("),
 "Scaffold": (["androidx.compose.material3"], r"\bScaffold\s*\("),
 "Shapes": (["androidx.compose.material3"], r"(?<![\w.])Shapes\s*\("),
 "Typography": (["androidx.compose.material3"], r"(?<![\w.])Typography\s*\("),
 "darkColorScheme": (["androidx.compose.material3"], r"\bdarkColorScheme\b"),
 "lightColorScheme": (["androidx.compose.material3"], r"\blightColorScheme\b"),
 "ExperimentalMaterial3Api": (["androidx.compose.material3"], r"\bExperimentalMaterial3Api\b"),
 "Color": (["androidx.compose.ui.graphics", "android.graphics"], r"(?<![\w.])Color[.(]"),
 "Brush": (["androidx.compose.ui.graphics"], r"\bBrush\."),
 "Path": (["androidx.compose.ui.graphics"], r"(?<![\w.])Path\s*\("),
 "StrokeCap": (["androidx.compose.ui.graphics"], r"\bStrokeCap\b"),
 "StrokeJoin": (["androidx.compose.ui.graphics"], r"\bStrokeJoin\b"),
 "Shape": (["androidx.compose.ui.graphics"], r":\s*Shape\b"),
 "ImageVector": (["androidx.compose.ui.graphics.vector"], r"\bImageVector\b"),
 "Offset": (["androidx.compose.ui.geometry"], r"(?<![\w.])Offset\s*\("),
 "Size": (["androidx.compose.ui.geometry"], r"(?<![\w.])Size\s*\("),
 "CornerRadius": (["androidx.compose.ui.geometry"], r"\bCornerRadius\b"),
 "Stroke": (["androidx.compose.ui.graphics.drawscope"], r"(?<![\w.])Stroke\s*\("),
 "dp": (["androidx.compose.ui.unit"], r"\d\.dp\b|\)\.dp\b|\w\.dp\b"),
 "sp": (["androidx.compose.ui.unit"], r"\d\.sp\b"),
 "Dp": (["androidx.compose.ui.unit"], r":\s*Dp\b"),
 "TextStyle": (["androidx.compose.ui.text"], r"\bTextStyle\s*\("),
 "FontWeight": (["androidx.compose.ui.text.font"], r"\bFontWeight\b"),
 "TextAlign": (["androidx.compose.ui.text.style"], r"\bTextAlign\b"),
 "TextOverflow": (["androidx.compose.ui.text.style"], r"\bTextOverflow\b"),
 "ImeAction": (["androidx.compose.ui.text.input"], r"\bImeAction\b"),
 "KeyboardType": (["androidx.compose.ui.text.input"], r"\bKeyboardType\b"),
 "PasswordVisualTransformation": (["androidx.compose.ui.text.input"], r"\bPasswordVisualTransformation\b"),
 "VisualTransformation": (["androidx.compose.ui.text.input"], r"\bVisualTransformation\b"),
 "LocalContext": (["androidx.compose.ui.platform"], r"\bLocalContext\b"),
 "testTag": (["androidx.compose.ui.platform"], r"\.testTag\("),
 "Role": (["androidx.compose.ui.semantics"], r"\bRole\."),
 "semantics": (["androidx.compose.ui.semantics"], r"\.semantics\s*\{"),
 "contentDescription": (["androidx.compose.ui.semantics"], r"\{\s*contentDescription\s*="),
 "stringResource": (["androidx.compose.ui.res"], r"\bstringResource\b"),
 "collectAsStateWithLifecycle": (["androidx.lifecycle.compose"], r"\.collectAsStateWithLifecycle\b"),
 "viewModelScope": (["androidx.lifecycle"], r"\bviewModelScope\b"),
 "AndroidViewModel": (["androidx.lifecycle"], r"\bAndroidViewModel\b"),
 "rememberNavController": (["androidx.navigation.compose"], r"\brememberNavController\b"),
 "NavHost": (["androidx.navigation.compose"], r"\bNavHost\s*\("),
 "composable": (["androidx.navigation.compose"], r"(?<![\w.])composable\s*\("),
 "currentBackStackEntryAsState": (["androidx.navigation.compose"], r"\bcurrentBackStackEntryAsState\b"),
 "NavHostController": (["androidx.navigation"], r"\bNavHostController\b"),
 "delay": (["kotlinx.coroutines"], r"(?<![\w.])delay\s*\("),
 "launch": (["kotlinx.coroutines"], r"\blaunch\s*[\({]"),
 "withContext": (["kotlinx.coroutines"], r"\bwithContext\s*\("),
 "Dispatchers": (["kotlinx.coroutines"], r"\bDispatchers\b"),
 "Job": (["kotlinx.coroutines"], r"[:<]\s*Job\b"),
 "isActive": (["kotlinx.coroutines"], r"\bwhile\s*\(\s*isActive"),
 "withTimeoutOrNull": (["kotlinx.coroutines"], r"\bwithTimeoutOrNull\b"),
 "suspendCancellableCoroutine": (["kotlinx.coroutines"], r"\bsuspendCancellableCoroutine\b"),
 "CancellationException": (["kotlinx.coroutines", "kotlin.coroutines.cancellation"], r"\bCancellationException\b"),
 "Flow": (["kotlinx.coroutines.flow"], r"[:<]\s*Flow<"),
 "MutableStateFlow": (["kotlinx.coroutines.flow"], r"\bMutableStateFlow\b"),
 "StateFlow": (["kotlinx.coroutines.flow"], r"(?<![\w])StateFlow<"),
 "SharingStarted": (["kotlinx.coroutines.flow"], r"\bSharingStarted\b"),
 "combine": (["kotlinx.coroutines.flow"], r"(?<![\w])combine\s*[\({]|\.combine\s*[\({]"),
 "stateIn": (["kotlinx.coroutines.flow"], r"\.stateIn\("),
 "onEach": (["kotlinx.coroutines.flow"], r"\.onEach\s*\{"),
 "asStateFlow": (["kotlinx.coroutines.flow"], r"\.asStateFlow\("),
 "catch": (["kotlinx.coroutines.flow"], r"\.catch\s*\{"),
 "distinctUntilChanged": (["kotlinx.coroutines.flow"], r"\.distinctUntilChanged\("),
 "Mutex": (["kotlinx.coroutines.sync"], r"\bMutex\("),
 "withLock": (["kotlinx.coroutines.sync"], r"\.withLock\b"),
 "resume": (["kotlin.coroutines"], r"\bcont\.resume\("),
 "resumeWithException": (["kotlin.coroutines"], r"\bresumeWithException\("),
 "Context": (["android.content"], r"(?<![\w.])Context\b"),
 "Intent": (["android.content"], r"(?<![\w.])Intent\b"),
 "Bundle": (["android.os"], r"(?<![\w.])Bundle\b"),
 "Application": (["android.app"], r"(?<![\w.])Application\b"),
 "ConnectivityManager": (["android.net"], r"(?<![\w.])ConnectivityManager\b"),
 "NetworkCapabilities": (["android.net"], r"(?<![\w.])NetworkCapabilities\b"),
 "FileProvider": (["androidx.core.content"], r"(?<![\w.])FileProvider\b"),
 "File": (["java.io"], r"(?<![\w.])File\("),
 "Locale": (["java.util"], r"(?<![\w.])Locale\."),
 "TimeZone": (["java.util"], r"(?<![\w.])TimeZone\."),
 "Date": (["java.util"], r"(?<![\w.])Date\("),
 "SimpleDateFormat": (["java.text"], r"\bSimpleDateFormat\("),
 "IOException": (["java.io"], r"\bIOException\b"),
 "InterruptedIOException": (["java.io"], r"\bInterruptedIOException\b"),
 "JSONObject": (["org.json"], r"\bJSONObject\b"),
 "JSONException": (["org.json"], r"\bJSONException\b"),
 "roundToInt": (["kotlin.math"], r"\.roundToInt\("),
 "Intent2": (["android.content"], r"$^"),
}
# extra: icons are imported per-icon or by wildcard
ICON_RE = re.compile(r"Icons\.(AutoMirrored\.)?(Filled|Rounded|Outlined)\.(\w+)")

proj_names = {k: v for k, v in decl.items()}

for p in kt_files:
    c, text = code[p], raw[p]
    pk = pkg_of(text)
    ex, wild = imports_of(text)
    own = set(re.findall(r"\b(?:class|interface|object|fun|val|var|typealias)\s+(?:<[^>]*>\s*)?(?:\w+\.)?(\w+)", c))
    # --- library symbols
    for sym, (pkgs, rx) in LIB.items():
        if sym in own: continue
        if not re.search(rx, c): continue
        ok = any((f"{pp}.{sym}" in ex) or (pp in wild) for pp in pkgs)
        if not ok and pk in pkgs: ok = True
        if not ok:
            m = re.search(rx, c)
            report(p, c.count("\n", 0, m.start()) + 1, f"IMPORT: '{sym}' used but not imported (expected one of {pkgs})")
    # --- icons
    for m in ICON_RE.finditer(c):
        am, style, name = m.group(1), m.group(2), m.group(3)
        base = "androidx.compose.material.icons." + ("automirrored." if am else "") + style.lower()
        if not (f"{base}.{name}" in ex or base in wild):
            report(p, c.count("\n", 0, m.start()) + 1, f"IMPORT: icon '{name}' ({am or ''}{style}) not imported from {base}")
        if "androidx.compose.material.icons.Icons" not in ex and "androidx.compose.material.icons" not in wild:
            report(p, c.count("\n", 0, m.start()) + 1, "IMPORT: Icons not imported")
            break
    # --- project symbols
    for name, (dp, dfile, kind) in proj_names.items():
        if dp == pk: continue
        if os.sep + "test" + os.sep in dfile: continue
        if re.search(rf"(?<![\w.]){re.escape(name)}\b", c):
            if not (f"{dp}.{name}" in ex or dp in wild):
                m = re.search(rf"(?<![\w.]){re.escape(name)}\b", c)
                report(p, c.count("\n", 0, m.start()) + 1, f"IMPORT: project symbol '{name}' ({dp}) not imported")
    for name, dp in ext_fun.items():
        if dp == pk: continue
        if re.search(rf"\.{re.escape(name)}\s*\(", c):
            if not (f"{dp}.{name}" in ex or dp in wild):
                m = re.search(rf"\.{re.escape(name)}\s*\(", c)
                report(p, c.count("\n", 0, m.start()) + 1, f"IMPORT: extension '{name}' ({dp}) not imported")
    # --- unresolved imports of project packages
    for imp in ex:
        if imp.startswith("com.jalsuraksha.app."):
            pkg, _, sym = imp.rpartition(".")
            if sym not in decl and sym not in ext_fun and sym != "R":
                # could be nested class (Outer.Inner) -> check outer
                outer = pkg.rpartition(".")[2]
                if outer not in decl:
                    report(p, 1, f"IMPORT: '{imp}' does not match any project declaration")

# ---------------------------------------------------------------- call-site argument checks
def check_calls(p):
    c = code[p]
    for name, siglist in sigs.items():
        for m in re.finditer(rf"(?<![\w.]){re.escape(name)}\s*\(", c):
            # Skip declarations, including generic functions such as `fun <T> ChipRow(`.
            line_start = c.rfind("\n", 0, m.start()) + 1
            line_prefix = c[line_start:m.start()]
            if re.search(r"\bfun\s+(?:<[^>\n]*>\s*)?$", line_prefix): continue
            if re.search(r"\b(class|object)\s+$", line_prefix): continue
            args, endi = balanced_args(c, m.end() - 1)
            if args is None: continue
            parts = [a for a in split_top(args) if a.strip()]
            named, positional = [], 0
            for a in parts:
                nm = re.match(r"\s*(\w+)\s*=(?!=)", a)
                if nm: named.append(nm.group(1))
                else: positional += 1
            trailing = bool(re.match(r"\s*\{", c[endi + 1:endi + 40])) if endi is not None else False
            line = c.count("\n", 0, m.start()) + 1
            best_err = None
            for params in siglist:
                pnames = [x[0] for x in params]
                err = None
                for nm in named:
                    if nm not in pnames:
                        err = f"named argument '{nm}' is not a parameter of {name}({', '.join(pnames)})"
                        break
                if not err:
                    given = set(pnames[:positional]) | set(named)
                    if trailing and pnames: given.add(pnames[-1])
                    missing = [n for n, d in params if not d and n not in given]
                    if positional + (1 if trailing else 0) > len(params) + 0 and not named:
                        err = f"too many arguments for {name}"
                    elif missing:
                        err = f"missing required parameter(s) {missing} in call to {name}"
                if err is None:
                    best_err = None; break
                best_err = err
            if best_err:
                report(p, line, "CALL: " + best_err)

for p in kt_files:
    check_calls(p)

# ---------------------------------------------------------------- resources & XML
res_dir = os.path.join(SRC, "main", "res")
defined = set()
for d, _, fs in os.walk(res_dir):
    for f in fs:
        fp = os.path.join(d, f)
        folder = os.path.basename(d).split("-")[0]
        if f.endswith(".xml"):
            try:
                tree = ET.parse(fp)
            except ET.ParseError as e:
                report(fp, 1, f"XML: {e}")
                continue
            if folder == "values":
                for el in tree.getroot():
                    nm = el.get("name")
                    if nm: defined.add((el.tag, nm.replace(".", "_")))
            else:
                defined.add((folder, os.path.splitext(f)[0]))
        else:
            defined.add((folder, os.path.splitext(f)[0]))
manifest = os.path.join(SRC, "main", "AndroidManifest.xml")
try:
    ET.parse(manifest)
except ET.ParseError as e:
    report(manifest, 1, f"XML: {e}")

mt = open(manifest, encoding="utf-8").read()
refs = re.findall(r"@(\w+)/([\w.]+)", mt)
for d, _, fs in os.walk(res_dir):
    for f in fs:
        if f.endswith(".xml"):
            refs += re.findall(r"@(\w+)/([\w.]+)", open(os.path.join(d, f), encoding="utf-8").read())
for kind, name in refs:
    if kind in ("android",): continue
    nm = name.replace(".", "_")
    k = {"string": "string", "color": "color", "drawable": "drawable", "mipmap": "mipmap", "xml": "xml", "style": "style"}.get(kind, kind)
    if (k, nm) not in defined:
        report(manifest, 1, f"RES: @{kind}/{name} is referenced but not defined")
for p in kt_files:
    for m in re.finditer(r"\bR\.(\w+)\.(\w+)", raw[p]):
        k, nm = m.group(1), m.group(2)
        if (k, nm) not in defined:
            report(p, raw[p].count("\n", 0, m.start()) + 1, f"RES: R.{k}.{nm} not defined")

# ---------------------------------------------------------------- misc smells
for p in kt_files:
    t = raw[p]
    for m in re.finditer(r"\bTODO\b|\bFIXME\b", t):
        report(p, t.count("\n", 0, m.start()) + 1, "SMELL: TODO/FIXME left in code")
    for m in re.finditer(r"Log\.[dviwe]\(", t):
        report(p, t.count("\n", 0, m.start()) + 1, "SMELL: logging call (check for secrets)")
    for m in re.finditer(r"localStorage|sessionStorage", t):
        report(p, t.count("\n", 0, m.start()) + 1, "SMELL: browser storage in Kotlin?")
    if re.search(r"HttpLoggingInterceptor", t):
        report(p, 1, "SMELL: HttpLoggingInterceptor would log credentials")

print(f"Checked {len(kt_files)} Kotlin files, {len(sigs)} callable signatures, {len(decl)} top-level declarations.")
if problems:
    print(f"\n{len(problems)} finding(s):")
    for pr in sorted(set(problems)):
        print(" -", pr)
    sys.exit(1)
print("No findings.")
