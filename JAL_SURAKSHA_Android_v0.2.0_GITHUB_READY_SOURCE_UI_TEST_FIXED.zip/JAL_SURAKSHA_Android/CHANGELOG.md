# Changelog

## 0.2.0 checkpoint update - GitHub preparation (2026-11-12)

### Added
- GitHub Actions verification workflow for the 94 JVM tests, Android lint, debug compilation and 6 emulator UI tests.
- Manual-only GitHub Actions workflow for future Debug or unsigned Release APK artifacts; no APK was generated in this checkpoint.
- Test-inventory verification script and local build / CI documentation.
- Contributor guidance covering firmware contract changes, credentials and pump safety.

### Updated
- Corrected two false positives in the custom offline structural checker (top-level property imports and generic function declarations).
- Updated README and test report to clearly distinguish static checks from compilation and test execution.
- Preserved the app-side pump request gate, default-disabled state, firmware permission check, and status read-back confirmation.

### Not verified
- Gradle compilation, JVM test execution, Android lint, emulator UI tests, hardware behaviour, and ESP32 API compatibility remain unverified in this environment.
- The standard Gradle wrapper launchers and wrapper JAR remain absent because external downloads are unavailable. GitHub Actions installs Gradle 8.9 directly.

---

## 0.2.0 - clean rebuild from Master Prompt v1.1 (not yet built or run)

Replaces the 0.1.0 starter scaffold. The package name and application ID (`com.jalsuraksha.app`) are unchanged.
The starter's source was not available, so this is a rebuild, not a patch. See `docs/STAGE0_AUDIT.md`.

### Added
- Strict, typed status parser with tri-state pump and firmware permission; contradiction detection.
- OkHttp client off the main thread with timeouts, cancellation, Basic Auth, local-only host and DNS policy, no auto-retry of commands.
- Android Keystore (AES-256-GCM) credential storage; DataStore preferences.
- Onboarding, Home, Live monitor, Pump control, History, Events, Settings, Calibration wizard, Diagnostics.
- Pump request path with confirmation, read-back confirmation and an app-side "Pump requests" switch (off by default) in addition to the firmware lock.
- Advisory alert engine, link/staleness rules, honest analytics and charts (gaps stay gaps), CSV export.
- Light and dark themes, design tokens, interlock-chain visual.
- 94 JVM unit tests and 6 Compose UI tests (not executed).
- Documentation set under `docs/` and an offline structural checker under `tools/`.

### Removed
- The starter's local "safetyLock" switch and any path that turned missing pump data into OFF.
- Any hard-coded device IP.

### Superseded
- `FIRMWARE_INTEGRATION_CHECKLIST.md` from the starter: now `docs/API_CONTRACT.md` (section "Verify against your firmware") and `docs/HARDWARE_SAFETY_CHECKLIST.md`.

### Not done
- Gradle wrapper script and JAR (binary; no network). Properties file included.
- Compile, unit-test run, device run, ESP32 and pump verification, calibration.
- A firmware patch: the `.ino` was not supplied. Recommendations are in `docs/API_CONTRACT.md`.

### Files
- `app/build.gradle.kts`
- `app/proguard-rules.pro`
- `app/src/androidTest/java/com/jalsuraksha/app/PumpPanelTest.kt`
- `app/src/main/AndroidManifest.xml`
- `app/src/main/java/com/jalsuraksha/app/JalApplication.kt`
- `app/src/main/java/com/jalsuraksha/app/MainActivity.kt`
- `app/src/main/java/com/jalsuraksha/app/data/ApiContract.kt`
- `app/src/main/java/com/jalsuraksha/app/data/ApiModels.kt`
- `app/src/main/java/com/jalsuraksha/app/data/DeviceApi.kt`
- `app/src/main/java/com/jalsuraksha/app/data/EndpointValidator.kt`
- `app/src/main/java/com/jalsuraksha/app/data/EventStore.kt`
- `app/src/main/java/com/jalsuraksha/app/data/HistoryStore.kt`
- `app/src/main/java/com/jalsuraksha/app/data/Models.kt`
- `app/src/main/java/com/jalsuraksha/app/data/SecretStore.kt`
- `app/src/main/java/com/jalsuraksha/app/data/SettingsRepository.kt`
- `app/src/main/java/com/jalsuraksha/app/domain/AlertEngine.kt`
- `app/src/main/java/com/jalsuraksha/app/domain/Analytics.kt`
- `app/src/main/java/com/jalsuraksha/app/domain/Calibration.kt`
- `app/src/main/java/com/jalsuraksha/app/domain/CsvExport.kt`
- `app/src/main/java/com/jalsuraksha/app/domain/Formats.kt`
- `app/src/main/java/com/jalsuraksha/app/domain/LinkDeriver.kt`
- `app/src/main/java/com/jalsuraksha/app/domain/PumpGatePolicy.kt`
- `app/src/main/java/com/jalsuraksha/app/ui/AppViewModel.kt`
- `app/src/main/java/com/jalsuraksha/app/ui/EventText.kt`
- `app/src/main/java/com/jalsuraksha/app/ui/JalApp.kt`
- `app/src/main/java/com/jalsuraksha/app/ui/UiModels.kt`
- `app/src/main/java/com/jalsuraksha/app/ui/components/Charts.kt`
- `app/src/main/java/com/jalsuraksha/app/ui/components/Components.kt`
- `app/src/main/java/com/jalsuraksha/app/ui/screens/CalibrationScreen.kt`
- `app/src/main/java/com/jalsuraksha/app/ui/screens/DeviceForm.kt`
- `app/src/main/java/com/jalsuraksha/app/ui/screens/DiagnosticsScreen.kt`
- `app/src/main/java/com/jalsuraksha/app/ui/screens/EventCard.kt`
- `app/src/main/java/com/jalsuraksha/app/ui/screens/EventsScreen.kt`
- `app/src/main/java/com/jalsuraksha/app/ui/screens/HistoryScreen.kt`
- `app/src/main/java/com/jalsuraksha/app/ui/screens/HomeScreen.kt`
- `app/src/main/java/com/jalsuraksha/app/ui/screens/MonitorScreen.kt`
- `app/src/main/java/com/jalsuraksha/app/ui/screens/OnboardingScreen.kt`
- `app/src/main/java/com/jalsuraksha/app/ui/screens/PumpPanel.kt`
- `app/src/main/java/com/jalsuraksha/app/ui/screens/PumpScreen.kt`
- `app/src/main/java/com/jalsuraksha/app/ui/screens/SettingsScreen.kt`
- `app/src/main/java/com/jalsuraksha/app/ui/screens/SplashScreen.kt`
- `app/src/main/java/com/jalsuraksha/app/ui/screens/StatRow.kt`
- `app/src/main/java/com/jalsuraksha/app/ui/theme/Theme.kt`
- `app/src/main/res/drawable/ic_launcher_foreground.xml`
- `app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml`
- `app/src/main/res/mipmap-anydpi/ic_launcher.xml`
- `app/src/main/res/values/colors.xml`
- `app/src/main/res/values/strings.xml`
- `app/src/main/res/values/themes.xml`
- `app/src/main/res/xml/file_paths.xml`
- `app/src/main/res/xml/network_security_config.xml`
- `app/src/test/java/com/jalsuraksha/app/data/DeviceApiTest.kt`
- `app/src/test/java/com/jalsuraksha/app/data/EndpointValidatorTest.kt`
- `app/src/test/java/com/jalsuraksha/app/data/StatusParserTest.kt`
- `app/src/test/java/com/jalsuraksha/app/data/StorageFormatsTest.kt`
- `app/src/test/java/com/jalsuraksha/app/domain/AlertEngineTest.kt`
- `app/src/test/java/com/jalsuraksha/app/domain/AnalyticsTest.kt`
- `app/src/test/java/com/jalsuraksha/app/domain/CalibrationAndFormatsTest.kt`
- `app/src/test/java/com/jalsuraksha/app/domain/LinkDeriverTest.kt`
- `app/src/test/java/com/jalsuraksha/app/domain/PumpGatePolicyTest.kt`
- `docs/API_CONTRACT.md`
- `docs/ARCHITECTURE_AND_DESIGN.md`
- `docs/HARDWARE_SAFETY_CHECKLIST.md`
- `docs/STAGE0_AUDIT.md`
- `docs/TEST_REPORT.md`
- `gradle/wrapper/gradle-wrapper.properties`
- `tools/lint_kt.py`
- `README.md`
- `CHANGELOG.md`
- `build.gradle.kts`
- `settings.gradle.kts`
- `gradle.properties`
- `.gitignore`
