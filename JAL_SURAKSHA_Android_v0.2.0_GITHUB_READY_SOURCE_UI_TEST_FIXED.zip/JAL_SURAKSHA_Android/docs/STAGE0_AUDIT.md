# Stage 0 audit: the ten starter findings

## Inputs

The starter project ZIP (`JAL_SURAKSHA_Android_Studio.zip`) and the current `.ino` were **not** supplied with this build.
The ten findings below come from the Master Prompt v1.1 and the recheck report, not from reading the starter's source or the
firmware. This build is a clean re-implementation that keeps the package and application ID (`com.jalsuraksha.app`) and
the starter's version matrix. Nothing here has been compiled or run.

Status words: **Implemented** = code exists that addresses it (not compiled). **Partly** = needs something from you.

| # | Finding | What this build does | Status | Still needed |
|---|---|---|---|---|
| 1 | Network calls on the main thread | `DeviceApi` uses OkHttp's async `enqueue` bridged with `suspendCancellableCoroutine`; the body is read inside `withContext(Dispatchers.IO)`. Timeouts: connect 3 s, read 4 s, whole call 6 s (8 s for commands). Cancelling the coroutine cancels the call. Failures are mapped to a sealed `ApiError`. Commands are never auto-retried. | Implemented | Run `DeviceApiTest` and a device test. |
| 2 | Basic Auth missing | `Authorization` header built per request with `Credentials.basic`. Password stored with an AES-256-GCM key in the Android Keystore (`SecretStore`); username in DataStore. HTTP 401 is its own state (`AuthRequired`), event and banner. Credentials are never put in a URL, never logged (no logging calls exist) and are redacted in `toString`. | Implemented | Confirm the real firmware's auth scheme and which routes require it. |
| 3 | Pump lock modelled in the UI | No local safety switch. `pumpAvailable` becomes the read-only `FirmwarePumpPermission`. ON needs fresh data + permission ENABLED + a known pump state + a confirmation dialog. **Both ON and OFF also need the app-side Pump requests switch (Settings, off by default)** because the OFF route and the physical design are unverified. The draft status JSON has no lock-reason field, so the reason shown is generic. | Implemented | Verify routes against the `.ino`; bench-test; then turn the switch on yourself. |
| 4 | Missing pump field becomes OFF | Tri-state `PumpState {ON, OFF, UNKNOWN}`. Missing, wrong-typed, contradictory (ON while locked), stale or offline data shows UNKNOWN. The last reported value appears only as small "last reported" text. Stored samples keep UNKNOWN as `?`. | Implemented | - |
| 5 | Permissive parser | `StatusParser` reads only the keys in `ApiContract`. Wrong types become null/UNKNOWN with a warning; a non-object or an object with none of the known keys is "unsupported response"; `apiVersion` above 1 is rejected. Device-reported IP is labelled "Device IP"; otherwise the configured address is labelled "Configured address". | Implemented | Compare field names and types with the real sketch. |
| 6 | Global cleartext | Manifest does not set `usesCleartextTraffic`. Network Security Configuration permits cleartext app-wide, with the reason documented in the file, because it cannot express IP ranges. Restricted in code: `EndpointValidator` (private IPv4 / `.local` only), a second check in `DeviceApi`, `LocalOnlyDns` (refuses non-private results), no redirects, no other network client in the app. The UI and README state that Basic Auth over HTTP is not confidential and that port forwarding must not be used. | Implemented | Residual risk: the platform-level permission is app-wide. |
| 7 | Hard-coded IP | No default address; first run is empty. The address is persisted; "Test connection" and "Edit device" exist. DHCP changes are explained in error messages. No automatic discovery (the spec requires explicit consent and a reason before any scanning). | Implemented | - |
| 8 | No persistence / navigation / history | DataStore for preferences, Keystore for the password, five-tab navigation plus Pump, Device, Calibration and Diagnostics screens, onboarding, history, events, calibration wizard. | Implemented | Not exercised on a device. |
| 9 | Gradle wrapper | `gradle/wrapper/gradle-wrapper.properties` pinned to Gradle 8.9 (the minimum for AGP 8.7). `gradlew`, `gradlew.bat` and `gradle-wrapper.jar` are **not** included: the JAR is a binary and there was no network to fetch it. | Partly | Android Studio works without them. For the CLI run `gradle wrapper --gradle-version 8.9` once. |
| 10 | Version compatibility | AGP 8.7.3, Kotlin and Compose compiler plugin 2.0.21, Compose BOM 2024.12.01, compileSdk/targetSdk 35, Gradle 8.9, Java 17. Dependencies added: OkHttp 4.12.0, coroutines 1.9.0, Navigation Compose 2.8.5, DataStore 1.1.1, lifecycle 2.8.7, material-icons-extended. | Partly | The set has not been built together. Record the tested matrix in the README after a green build. |

## Things done differently on purpose

- History is a bounded CSV file instead of Room: Room needs KSP, whose version must match Kotlin exactly, and that could not be
  checked offline. The trade-off is simpler queries (all in memory) and no schema migrations.
- No Hilt: a small manual container avoids annotation-processing risk in an unbuilt project.
- OkHttp retries are disabled for pump commands so a timeout can never silently send a second command.
