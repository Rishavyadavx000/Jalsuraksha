# Build and continuous integration

## Declared toolchain

| Component | Project configuration |
|---|---|
| Android Gradle Plugin | 8.7.3 |
| Gradle | 8.9 |
| Kotlin Android + Compose compiler plugin | 2.0.21 |
| Android compile / target / minimum SDK | 35 / 35 / 24 |
| Java source and bytecode target | 17 |

This is the configured compatibility matrix, not a claim that the matrix has passed a build. The source-delivery environment
used for this checkpoint has Java 21 but no Android SDK, Gradle installation, emulator, or network/DNS access for downloading
the toolchain and dependencies.

## Gradle wrapper status

`gradle/wrapper/gradle-wrapper.properties` pins the intended Gradle distribution to 8.9. The binary wrapper JAR and the
`gradlew` / `gradlew.bat` launcher scripts are not included in this checkpoint. No substitute launcher is presented as the
official Gradle wrapper. For a local command-line build, install Gradle 8.9 and run the commands below from the repository
root. Android Studio can also be configured to use a local Gradle 8.9 installation.

Once Gradle 8.9 is installed and the machine has access to the Gradle distribution, the official wrapper can be generated
from the repository root and committed:

```bash
gradle wrapper --gradle-version 8.9 --distribution-type bin
git add gradlew gradlew.bat gradle/wrapper/gradle-wrapper.jar gradle/wrapper/gradle-wrapper.properties
```

After the official wrapper files are committed, switch the CI workflow back to wrapper execution and re-enable wrapper
validation. Until then, CI installs Gradle directly and skips wrapper validation deliberately.

```bash
python3 tools/verify_test_inventory.py
python3 tools/lint_kt.py .
gradle --no-daemon clean testDebugUnitTest lintDebug compileDebugKotlin
```

Instrumented Compose tests require a running API 35 emulator or attached test device:

```bash
gradle --no-daemon connectedDebugAndroidTest
```

## GitHub Actions

- `.github/workflows/verify.yml` runs on pushes, pull requests, and manual dispatch. It installs JDK 17, Android SDK 35 and
  Gradle 8.9; explicitly skips Gradle wrapper validation because the official wrapper files are absent and invokes the
  installed `gradle` executable; checks the expected 94 + 6 test inventory; runs the offline structural checker; compiles the debug variant;
  executes JVM unit tests and Android lint; and runs the six Compose UI tests on an API 35 emulator. Test and lint reports
  are uploaded as workflow artifacts even when a test step fails.
- `.github/workflows/manual-apk.yml` is manual-only (`workflow_dispatch`). Select `debug` or `release` in the Actions UI to
  build an APK and upload it as an artifact. It does not run during ordinary pushes or pull requests.

The workflow intentionally does not deploy, publish, sign, or distribute an APK. The release variant is unsigned. A signed
release requires a separately configured signing setup and secret handling.

## Evidence required before calling the project verified

1. A successful GitHub Actions `unit-lint-build` job with `testDebugUnitTest`, `lintDebug`, and `compileDebugKotlin` completed.
2. A successful `compose-ui-tests` job with `connectedDebugAndroidTest` completed on the emulator.
3. Manual device acceptance tests and the hardware safety checklist completed.
4. Firmware API contract checked against the actual ESP32 `.ino` and observed HTTP responses. The current contract remains a
   draft until this is done.

The app-side pump request switch must remain OFF until the firmware routes and safety behaviour have been verified. Never
connect the pump supply just to make an automated test pass.
