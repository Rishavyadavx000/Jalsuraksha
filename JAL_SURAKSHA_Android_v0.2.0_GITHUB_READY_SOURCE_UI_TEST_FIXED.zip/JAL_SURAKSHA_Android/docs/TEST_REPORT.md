# Test and verification report

**Checkpoint: 2026-11-12**

## 1. Result summary

| Check | Expected | Result in this workspace |
|---|---:|---|
| Kotlin source files inspected by structural checker | 49 | **PASS (static only)** 49 checked, no findings |
| Pure Kotlin data/domain compile subset | 10 source files | **PASS (partial)** compiled with local Kotlin 1.9.0 compiler |
| JVM unit-test inventory | 94 | **PASS (inventory only)** 94 `@Test` annotations found |
| Compose UI-test inventory | 6 | **PASS (inventory only)** 6 `@Test` annotations found |
| Full Gradle sync / Android Kotlin compilation | Successful | **Not run: Gradle and Android SDK unavailable** |
| `testDebugUnitTest` | All 94 pass | **Not run: dependencies could not be fetched** |
| `lintDebug` | No fatal issues | **Not run: Android Gradle Plugin unavailable** |
| `assembleDebug` | Successful | **Not run; APK packaging is reserved for the manual GitHub workflow** |
| `connectedDebugAndroidTest` | All 6 pass | **Not run: no emulator or Android SDK** |
| ESP32 API integration | Actual sketch matches API | **Unverified: `.ino` not supplied** |
| Pump / relay hardware | Interlocks and physical behaviour pass | **Not tested; no hardware supplied** |

No test execution or successful full Android Gradle build is claimed in this report. Only the limited 10-file pure Kotlin compile is verified.

## 2. Environment and reason tests are blocked

| Tool or resource | Observed state |
|---|---|
| Java | OpenJDK 21.0.12 present |
| Gradle executable | Not installed (`gradle` command not found) |
| Android SDK / `ANDROID_HOME` / `ANDROID_SDK_ROOT` | Not installed / unset |
| Android emulator or attached device | Not available |
| Kotlin compiler | `kotlinc` 1.9.0 available; used only for the 10-file pure Kotlin subset below. The configured Gradle Kotlin plugin is 2.0.21 and was not resolved. |
| Network and DNS | External host resolution unavailable; `services.gradle.org` could not be resolved |
| ESP32 firmware `.ino` | Not included in the supplied archive |
| Physical ESP32, relay, pump and flow sensor | Not available in this workspace |

Because Gradle and Android SDK artifacts could not be installed, it is not possible to run a full Android compilation, the
standard Gradle/JUnit task, Android lint, or instrumented UI tests here. A limited compile of 10 pure Kotlin data/domain source
files succeeded with the locally installed Kotlin 1.9.0 compiler; this does not validate Android, Compose, OkHttp, DataStore,
Keystore, Gradle plugin compatibility, or test execution. The repository now includes GitHub Actions workflows that install
the declared toolchain and perform the full checks on GitHub-hosted runners.

## 3. Static checks actually executed

### 3.1 Kotlin / XML structural checker

Command:

```bash
python3 tools/lint_kt.py .
```

Observed result:

```text
Checked 49 Kotlin files, 84 callable signatures, 104 top-level declarations.
No findings.
```

The checker checks bracket/string balance, package paths, selected import and project-symbol references, named arguments for
project call sites, XML parsing, resource references, and selected code smells. It is a custom offline structural checker.
It does not parse Kotlin with the Kotlin compiler and cannot detect all type-resolution, overload, Compose API, Gradle, or
Android resource compilation errors.

The checker was corrected in this checkpoint to index imported top-level properties and to avoid treating generic function
declarations as function calls. These were checker defects, not changes to app runtime code.

### 3.2 Test inventory

Command:

```bash
python3 tools/verify_test_inventory.py
```

Expected and observed test files:

| File | Cases | Coverage |
|---|---:|---|
| `StatusParserTest` | 15 | Status JSON parsing, missing/invalid values, tri-state pump, contradictions and API version |
| `EndpointValidatorTest` | 9 | Private addresses, ports, schemes, malformed/public hosts, credentials and paths |
| `DeviceApiTest` | 9 | Basic Auth, HTTP errors, request routes, host policy and secret redaction |
| `PumpGatePolicyTest` | 11 | App request switch, stale/offline state, firmware permission, pump state and command progress |
| `LinkDeriverTest` | 8 | Not configured, connecting, online, stale, offline, auth and unsupported states |
| `AlertEngineTest` | 14 | Flow alerts, restarts, pump/lock changes, contradictions, sensor, signal and link transitions |
| `AnalyticsTest` | 10 | Gaps, counter resets, pump runtime, empty values, buckets and flow series |
| `CalibrationAndFormatsTest` | 9 | Calibration math, invalid inputs, units, durations and signal formats |
| `StorageFormatsTest` | 9 | CSV/JSON round trips, locale, corrupt lines, quoting, clamping and calibration opt-in |
| **JVM unit tests total** | **94** | **Present; not executed** |
| `PumpPanelTest` (instrumented) | **6** | Locked firmware, app-side switch, stale state, disabled controls, ON confirmation and OFF behaviour |

The inventory script counts `@Test` annotations. It does not execute or validate the assertions.

### 3.3 Partial Kotlin compiler check

The local compiler is Kotlin 1.9.0, while the project declares Kotlin / Compose compiler plugin 2.0.21. The following ten
pure Kotlin data/domain files compiled successfully to a temporary JVM JAR with `-jvm-target 17`:

- `data/Models.kt`, `data/ApiModels.kt`, `data/EndpointValidator.kt`
- `domain/AlertEngine.kt`, `domain/Analytics.kt`, `domain/Calibration.kt`, `domain/CsvExport.kt`, `domain/Formats.kt`,
  `domain/LinkDeriver.kt`, `domain/PumpGatePolicy.kt`

This is only a partial source compile using a different Kotlin compiler version. It is not the Android Gradle build, does not
compile UI or Android-bound data classes, does not cover the full parser/network/storage code, and does not execute tests.

## 4. Gradle compatibility and repository setup

Declared project versions:

| Component | Version |
|---|---|
| Android Gradle Plugin | 8.7.3 |
| Gradle distribution | 8.9 |
| Kotlin Android / Compose compiler plugin | 2.0.21 |
| Compose BOM | 2024.12.01 |
| compileSdk / targetSdk / minSdk | 35 / 35 / 24 |
| Java source / target | 17 / 17 |

This pairing is configured but not compiled in this workspace. `gradle/wrapper/gradle-wrapper.properties` pins 8.9, but the
standard `gradlew`, `gradlew.bat`, and `gradle-wrapper.jar` are not included. No home-grown replacement is passed off as the
official wrapper. GitHub Actions uses `gradle/actions/setup-gradle` to install Gradle 8.9 directly.

Workflows added:

- `.github/workflows/verify.yml`: push, pull request and manual triggers; inventory and structural checks; debug compile;
  all JVM unit tests; Android lint; debug Kotlin compile; Compose UI tests on an API 35 emulator; report artifact uploads.
- `.github/workflows/manual-apk.yml`: manual `workflow_dispatch` only, with Debug or unsigned Release APK selection. It is
  not triggered by normal pushes or pull requests and was not run for this source delivery. The regular verification workflow
  does not publish an APK; the emulator test runner builds its test install packages only as required to execute UI tests.

See `docs/BUILD_AND_CI.md` for commands and evidence required before calling the source verified.

## 5. Pump safety review boundary

The code's existing fail-closed design remains in place:

1. The app-side pump-request setting defaults to `false`.
2. The app does not override firmware `pumpAvailable` permission.
3. A start request additionally requires fresh device data, firmware permission ENABLED, known pump state, and explicit user
   confirmation.
4. The command result is considered successful only after status read-back confirms the requested pump state.
5. Missing, stale, invalid, or contradictory pump data remains UNKNOWN, not OFF.
6. No pump command is sent automatically at startup.
7. The app cannot stop a pump when network connectivity is lost; a physical power cut-off remains required.

This is a source review only. It is not proof of behaviour on a relay or pump. Do not connect the pump supply or enable app-side
requests until the hardware checklist and real firmware contract have been checked.

## 6. Firmware contract status

`docs/API_CONTRACT.md` is still explicitly marked **DRAFT / UNVERIFIED**. The app currently expects the documented routes
and JSON fields from the earlier firmware draft, including `GET /api/status`, `POST /pump/on`, `POST /pump/off`, `pump`,
`pumpAvailable`, `flowLpm`, and `totalLiters`.

The supplied Android source ZIP and README did not contain the actual `.ino`. Therefore no claim is made about route names,
HTTP methods, field names, authentication, response codes, API version, relay lock behaviour, boot state, or run-time limits.
Do not silently adapt the app to guessed firmware behaviour. Obtain the actual sketch and verify its handlers and real HTTP
responses before changing the contract.

## 7. Required verification on GitHub / local Android environment

Run these commands from the repository root after installing JDK 17, Android SDK Platform 35 and Gradle 8.9:

```bash
python3 tools/verify_test_inventory.py
python3 tools/lint_kt.py .
gradle --no-daemon clean testDebugUnitTest lintDebug compileDebugKotlin
gradle --no-daemon connectedDebugAndroidTest
```

Acceptance criteria:

- Gradle configuration syncs and Kotlin/Compose code compiles with no errors.
- All 94 JVM tests pass.
- `lintDebug` completes without fatal issues; review any warnings.
- Debug Kotlin source compiles successfully. APK packaging is a separate, manual-only workflow and is not part of ordinary CI.
- All 6 instrumented tests pass on the configured emulator/device.
- GitHub Actions artifacts contain the JVM and instrumented XML/HTML reports.
- Manual testing verifies light/dark themes, accessibility, offline/stale states, history/export, calibration, and secure
  credential handling.
- The real firmware API contract and the hardware safety checklist are signed off before any connected pump test.

## 8. Manual device and hardware test plan

### Connection and credentials

- Verify correct local IP and credentials; test an incorrect IP and incorrect password.
- Confirm the phone and ESP32 are on the same local network.
- Turn Wi-Fi off, restore it, and check offline/reconnect states.
- Change the configured ESP32 address without reinstalling the app.
- Confirm credentials are not exposed in logs, URLs, diagnostics exports, or exception messages.

### Data and UI

- Compare live status values with the actual ESP32 JSON response.
- Confirm missing or invalid sensor values display as unavailable, not zero.
- Confirm stale data is clearly marked and chart gaps are not joined with fabricated values.
- Check theme modes, narrow display width, enlarged font, and TalkBack labels.
- Verify CSV exports, history retention, events and calibration display correction.

### Pump safety (pump power disconnected until checklist sign-off)

- Fresh install: pump-request switch is OFF and no command is transmitted at startup.
- Firmware permission false/unknown: ON remains blocked even when the app switch is enabled.
- Stale/offline data blocks both remote requests. Unknown or contradictory pump state blocks ON; while the device is reachable and the app-side request switch is enabled, the policy may still permit an OFF request as a safe-stop request.
- ON requires the dialog acknowledgement; accepted HTTP response alone does not show success.
- The UI reports success only after status read-back confirms the requested state.
- Network loss leaves the user with a clear warning to use the physical power cut-off.

Only after all software and hardware checks pass should the pump be powered for a controlled bench test.
