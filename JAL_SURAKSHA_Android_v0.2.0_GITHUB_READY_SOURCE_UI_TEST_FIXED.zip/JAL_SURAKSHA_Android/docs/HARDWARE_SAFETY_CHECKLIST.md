# Hardware safety checklist

Do not enable pump requests in the app (Settings > Pump requests) or set `PUMP_CONTROL_ENABLED` true in firmware until every
item in sections 1 to 4 is checked. If the pump is mains powered, have a qualified electrician do the wiring. Water and
electricity together can kill. Nothing in this app replaces a physical way to cut power.

## 1. Electrical

- [ ] The exact relay module model is written down here: ____________________
- [ ] The pump is switched through a relay or driver rated for its voltage and current (with margin). It is never driven directly from an ESP32 pin, and no pump power flows through any ESP32 pin.
- [ ] The relay input works with the ESP32's 3.3 V logic (or has a transistor or optocoupler stage designed for it).
- [ ] The pump's rated voltage, running current and start-up/stall current are known and are inside the relay's contact rating and the supply's capacity.
- [ ] The pump has its own regulated supply sized for the load, with wire gauge and fusing suited to that current.
- [ ] The relay module's logic level and polarity are known (many are active-LOW) and match the firmware.
- [ ] A DC pump has a flyback diode across it; the supply has a fuse sized for the pump.
- [ ] Mains wiring (if any) is in a closed, correctly rated enclosure with strain relief, an RCD/GFCI upstream, and no exposed conductors.
- [ ] ESP32 and pump supplies share a ground where required and are otherwise isolated as the relay design intends.
- [ ] Flow-sensor wiring is checked: a sensor that outputs 5 V pulses must not go straight into a 3.3 V ESP32 pin (use a divider or level shifter, or a pull-up to 3.3 V on an open-collector output). Confirm against your sensor's datasheet.
- [ ] The relay pin is not a boot-strapping pin or a flash pin (check the pin notes for your ESP32 board).

## 2. Firmware

- [ ] `PUMP_CONTROL_ENABLED` is false by default and the status JSON reports it as `pumpAvailable`.
- [ ] The relay is OFF at power-up, after a reset, after a brown-out and while Wi-Fi is down. (Power-cycle ten times with a multimeter or lamp on the relay output.)
- [ ] The firmware, not the app, checks every ON request against the lock and its own limits.
- [ ] A maximum run time exists in firmware, and the pump stops when it expires.
- [ ] You have decided what happens when Wi-Fi drops while the pump is ON (recommended: stop after a short timeout).
- [ ] Credentials in the sketch are not the defaults and are not committed to version control.

## 3. Mechanical and water

- [ ] The pump has water before it starts (primed or submerged as its datasheet requires). Dry running damages most pumps.
- [ ] Pipes, fittings and the flow sensor are sealed and supported; the sensor's flow direction arrow is correct.
- [ ] Leaks cannot reach the electronics or the mains wiring.
- [ ] There is a physical switch or plug that cuts pump power and you know where it is.

## 4. Bench tests, in this order (pump disconnected or its supply cut)

- [ ] With pump control disabled: `POST /pump/on` is rejected and the relay does not change.
- [ ] With the app's Pump requests switch off: both app buttons are disabled and say why.
- [ ] Enable control in firmware. Switch a harmless load (a lamp) through the relay: ON, then OFF, from curl and then from the app.
- [ ] App shows "Confirmed by the device" only after the device reports the new state. Unplug the ESP32 mid-command: the app must say "Request failed" or "Not confirmed", never success.
- [ ] Walk out of Wi-Fi range with the lamp ON: confirm what the firmware does (see section 2) and that the app shows the data as stale and the pump state as unknown.
- [ ] Reconnect: the app recovers without a restart.
- [ ] Only then connect the real pump, with water, and repeat ON/OFF.

## 5. Each time before running

- [ ] Water supply present, nothing leaking, enclosure closed.
- [ ] Phone shows the device Online and fresh data.
- [ ] You know how to cut power physically.

## 6. Flow-sensor calibration

- [ ] Run the Calibration wizard with a measured volume of at least a few litres, repeat at least twice, and compare. Until then the readings are **approximate**.
- [ ] If you change the pulses-per-litre constant in the sketch, re-flash and remove the app-side correction so it is not applied twice.

## Sign-off

| Item | Name | Date |
|---|---|---|
| Electrical review | | |
| Firmware review | | |
| Bench tests passed | | |
| First real run observed | | |
