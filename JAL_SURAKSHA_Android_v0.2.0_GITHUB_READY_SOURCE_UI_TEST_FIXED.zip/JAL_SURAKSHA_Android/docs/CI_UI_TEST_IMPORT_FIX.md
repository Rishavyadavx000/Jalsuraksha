# UI Test Import Fix

GitHub Actions Run #7 reached `:app:compileDebugAndroidTestKotlin` and failed because `PumpPanelTest.kt` imported `androidx.compose.ui.test.assertExists` as a top-level declaration. In the Compose test API used by this project, `assertExists()` is called as a member on `SemanticsNodeInteraction`; it should not be imported separately.

Correction: remove only the invalid import line. The assertion call remains unchanged, so the intended test behavior is preserved. No app runtime source, feature, test case, API, or pump-safety logic is changed.
