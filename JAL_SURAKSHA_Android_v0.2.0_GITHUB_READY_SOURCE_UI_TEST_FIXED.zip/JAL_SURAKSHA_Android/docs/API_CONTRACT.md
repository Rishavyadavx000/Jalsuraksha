# API contract (DRAFT, not verified against your firmware)

**Status: unverified.** The actual `.ino` was not available when the app was built. Everything below is the earlier
V2 firmware draft. If your sketch differs, the sketch is authoritative: change the contract in one place
(`ApiContract.kt`, plus the paths under Settings > Device > Advanced) and update this file and the tests.

## Transport

- HTTP/1.1 to the configured private address, port 80 unless set (`192.168.1.50` or `192.168.1.50:8080`).
- HTTP Basic Auth in the `Authorization` header (pre-emptive). Not encrypted.
- JSON responses. Redirects are not followed. Responses over 64 KB are truncated.
- Timeouts: connect 3 s, read 4 s, whole status call 6 s, whole command call 8 s. Commands are not retried.

## Routes

| Method | Path (default) | Purpose | Auth | Notes |
|---|---|---|---|---|
| GET | `/api/status` | Status JSON, polled while the app is visible | Basic | 200 with JSON; 401 if credentials are wrong |
| POST | `/pump/on` | Request pump ON | Basic | Firmware must reject it when pump control is disabled |
| POST | `/pump/off` | Request pump OFF | Basic | Empty body. Only sent when the app-side Pump requests switch is on |
| GET | `/` | Browser dashboard | Basic | Not used by the app |

## Status JSON

| Field | Type | Meaning | If missing or invalid the app shows |
|---|---|---|---|
| `pump` | boolean | true = ON | Pump state UNKNOWN (never OFF) |
| `pumpAvailable` | boolean | Firmware allows pump control | Permission UNKNOWN: ON stays blocked |
| `flowLpm` | number >= 0 | Flow, litres per minute | `--` and a "flow sensor not reporting" notice |
| `totalLiters` | number >= 0 | Device's cumulative total | `--` |
| `rssi` | integer -127..0 | Wi-Fi signal at the ESP32, dBm | `--` |
| `wifi` | string | Wi-Fi status text | `--` |
| `ip` | string | Device's own IP | Configured address is shown instead, labelled as such |
| `deviceId` (optional) | string | Stable device identity | "not reported" |
| `apiVersion` (optional) | integer | Contract version; the app supports up to 1 | "not reported"; above 1 is "unsupported response" |

At least one of `pump`, `pumpAvailable`, `flowLpm`, `totalLiters` must be present, otherwise the reply is treated as "not a
JAL-SURAKSHA response" (for example a router login page). `pump: true` together with `pumpAvailable: false` is
**contradictory**: the pump state becomes UNKNOWN and a critical event is raised.

Example:

```json
{"wifi":"Connected","ip":"192.168.1.50","rssi":-61,"pump":false,"pumpAvailable":false,"flowLpm":0.0,"totalLiters":12.5}
```

## How the app maps responses

| Result | App state |
|---|---|
| 200 + valid JSON | Online (until older than the stale limit, default 10 s) |
| 200 + invalid JSON / wrong shape / API version too new | Unsupported response |
| 401 | Credentials rejected |
| Other non-2xx | HTTP error (shown, counted as a failed poll) |
| Timeout / no route / connection refused | Counted as failure. After 3 in a row and no fresh data: Offline. Polling backs off up to 30 s |
| Name resolves to a public address | Refused |

## Pump commands

1. The app checks every gate (see README, Safety model) and, for ON, shows a confirmation dialog.
2. It sends the POST. A 2xx reply only means "accepted".
3. It then reads `/api/status` up to 4 times (first after 0.7 s, then every 1 s) until the device reports the requested state.
4. Outcomes: **Confirmed** (device reports the new state); **Not confirmed** (accepted but state unchanged); **Rejected** (HTTP
   error or 401); **Failed** (no completed request, state unknown). Only "Confirmed" is ever shown as success.
5. A timeout is never treated as "not executed": the state is read back regardless.

## Verify against your firmware before trusting this

Use a laptop on the same network. **Keep the pump disconnected or its supply cut while doing this.**

```
curl -i http://192.168.1.50/api/status                          # expect 401 if auth is on
curl -i -u USER:PASS http://192.168.1.50/api/status             # expect 200 and the JSON above
curl -i -u USER:PASS -X POST http://192.168.1.50/pump/on        # with control disabled: expect a rejection, relay unchanged
curl -i -u USER:PASS -X POST http://192.168.1.50/pump/off       # expect 2xx, relay stays OFF
```

Fill this in and keep it with the project:

| Check | Expected | Actual |
|---|---|---|
| Status route and method | GET `/api/status` | |
| Status needs auth | 401 without credentials | |
| Field names and types | as the table above | |
| `pumpAvailable` default at boot | false | |
| ON while disabled | non-2xx, relay unchanged | |
| ON route and method | POST `/pump/on` | |
| OFF route and method | POST `/pump/off` | |
| Pump OFF after reboot / power loss | yes | |
| Error body format | (document it) | |

## Recommended firmware changes (not applied: no `.ino` was supplied, so there is no patch)

1. Add `"apiVersion":1` and a stable `"deviceId"` to the status JSON.
2. Return a small JSON error on rejections, for example `{"error":"pump_control_disabled"}` with 403, so the app can show the
   firmware's reason instead of a generic one.
3. Keep `PUMP_CONTROL_ENABLED` false by default and report it as `pumpAvailable`.
4. Enforce limits in the firmware itself: maximum run time, optional dry-run protection, pump OFF at boot, reset, brown-out and
   after Wi-Fi loss. Consider a lease ("dead-man") timer: the pump keeps running only while the controller keeps renewing the
   request. This is the only way the system can stop the pump when the phone drops off the network.
5. Use POST only for state-changing routes. Add a short lockout after repeated 401s.
6. Optional: advertise mDNS (`MDNS.begin("jal-suraksha")`) so a `.local` name can work.
7. Expose the pulse count and calibration constant (read-only) if you want the calibration wizard to show them.
