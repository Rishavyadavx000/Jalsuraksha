# Architecture and design system

## 1. Layers

```
ui/        Compose screens, navigation, AppViewModel (single owner of connection state)
domain/    pure Kotlin rules: LinkDeriver, AlertEngine, PumpGatePolicy, Analytics, Calibration, Formats, CsvExport
data/      models, ApiContract + StatusParser, EndpointValidator, DeviceApi (OkHttp), SecretStore, SettingsRepository, HistoryStore, EventStore
```

`domain/` and most of `data/` have no Android UI dependencies, so almost all logic is covered by JVM unit tests.

| Class | Responsibility |
|---|---|
| `DeviceApi` | Suspend HTTP calls with timeouts, cancellation, Basic Auth, host policy, structured `ApiError`; never throws for network problems |
| `StatusParser` | Strict typed parse of the status JSON; invalid values become null/UNKNOWN plus a warning |
| `EndpointValidator` | Accepts only private IPv4 or `.local` hosts, validates ports and API paths |
| `SecretStore` | AES-256-GCM with a Keystore key; password never leaves this class unencrypted except in memory for a request |
| `SettingsRepository` | DataStore preferences, clamped on read and write |
| `HistoryStore` / `EventStore` | Bounded local files (CSV lines / JSON lines), atomic rewrite on prune |
| `LinkDeriver` | Turns poll bookkeeping into Online / Stale / Offline / Auth / Unsupported / Connecting / Not set up |
| `AlertEngine` | Episode-based advisory events, one event per episode |
| `PumpGatePolicy` | Which pump requests the UI may offer, and the reason when it may not |
| `Analytics` | Stats, volume per hour/day, flow series; counts only intervals the app actually observed |
| `AppViewModel` | Polling loop, pump command flow, persistence orchestration, exports |

## 2. Data flow

```
poll loop (foreground only)
  -> DeviceApi.fetchStatus      (IO thread, timeouts, Basic Auth)
  -> StatusParser               (strict; warnings kept)
  -> AppViewModel.handleStatus  (DeviceSnapshot, AlertEngine, recent samples, history file)
  -> UiSnapshot (1 Hz ticker)   (LinkDeriver, calibration applied for display only)
  -> screens
```

- One mutex serialises every status request, so requests never overlap (the ESP32 serves one client at a time).
- Polling starts on `ON_START` and is cancelled on `ON_STOP`: nothing talks to the network while the app is not visible.
- While the device is unreachable the interval doubles up to 30 s, then returns to normal on the first success.
- Storage failures are caught and reported in Diagnostics instead of crashing the polling coroutine.
- The `NavHost` builder captures no per-second state (each destination collects the snapshot itself), so the nav graph is not rebuilt every second.

## 3. State model

- **Link**: Online if the last success is no older than the stale limit (default 10 s); otherwise Stale; Offline after 3 consecutive failures; 401 and unsupported replies override.
- **Pump**: `ON / OFF / UNKNOWN`. Missing, wrong-typed, contradictory (ON while locked), stale or offline data is UNKNOWN.
- **Permission**: `ENABLED / LOCKED / UNKNOWN` from `pumpAvailable`. Read-only everywhere.
- **Values**: nullable numbers. `--` means "no valid value", never 0. Stale values are dimmed and labelled.

## 4. Pump request path

```
tap Turn on -> confirmation dialog (risk text + checkbox) -> requestPump(true)
  -> gate re-check (app switch, fresh data, firmware ENABLED, known state)
  -> POST (no retry) -> read /api/status up to 4 times -> Confirmed | Not confirmed | Rejected | Failed
```

Turn off skips the dialog and is prominent, but is subject to the same app-side switch and fresh-data rule.
The firmware re-checks everything; the app gate is only a UX guard.

## 5. Persistence

- Raw device values are stored. The optional calibration factor is applied at display time, so removing it restores the originals.
- Samples are written at most every 10 s (and on a pump state change); retention is 1, 7 or 30 days (default 7), pruned at startup.
- History reflects only what the app received. Analytics ignore gaps longer than three sample intervals, so volume is never attributed across a period the app did not see, and empty buckets are drawn as a dash, not as zero.

## 6. Decisions and trade-offs

| Decision | Why | Cost |
|---|---|---|
| Bounded CSV file instead of Room | Room needs KSP, which must match Kotlin exactly and could not be checked offline | All queries in memory; fine for days of 10 s samples |
| Manual DI instead of Hilt | No annotation-processing risk in an unbuilt project | A little boilerplate |
| No network scanning | The spec requires explicit consent and a reason | Fixing a changed DHCP address is manual |
| App-wide cleartext + code restrictions | NSC cannot express private IP ranges | Documented residual risk |
| Polling only in the foreground | Simple, battery-friendly, no background service | No notifications; alerts only while open |
| Calibration is display-side | Firmware constant is not exposed by the API | The wizard can suggest a value but cannot apply it |

## 7. Design system

**Direction:** calm and instrument-like. Deep navy for the connection hero, one teal accent, generous whitespace, no decoration
that is not information. Status is never colour-only: every chip carries text and usually an icon.

| Token | Light | Dark |
|---|---|---|
| Background / surface | `#F2F6FA` / white | `#071526` / `#0E2238` |
| Primary (teal) | `#0F766E` | `#5EEAD4` |
| Hero (navy) | `#0B2A4A` | `#0B2A4A` |
| Success / warning / danger / info | `#15803D` / `#B45309` / `#B91C1C` / `#0369A1` | `#4ADE80` / `#FBBF24` / `#F87171` / `#38BDF8` |
| Text / secondary text | `#0B1F33` / `#475569` | `#E6EEF6` / `#A9BBCE` |

Typography: the platform sans-serif, one family. Scale 30/24/20/16/14/12/11 sp; big readings 38 sp bold with tabular numerals so digits
do not jitter. Radii follow hierarchy: hero 28, card 20, tile and button 14, field 12, chip pill. Spacing steps 4/8/12/16/24/32 dp.
Touch targets are at least 48 dp. Every icon-only button has a content description. Charts expose a text description.

**Signature element: the interlock chain.** On the Pump screen four links (App, Connection, Firmware, Pump state) light up as each
gate is satisfied and show why when one is not. It turns a disabled button into an explanation.

**Honest charts.** Lines are drawn only through real points and are broken wherever data is missing; bars with no observation are
a dash, not zero; empty charts say so.

**Copy.** Sentence case, plain language, errors say what to check next, heuristics are called heuristics. Units sit beside every
metric (L/min, L, dBm). Flow uses 2 decimals, volume 3 (1 above 1000), per the spec.

## 8. State coverage

| State | Where it is handled |
|---|---|
| Loading / connecting | Splash (never blocks beyond 2.5 s), "Waiting for the first reading", History progress bar |
| Empty | No device set up, No history, No events, chart "Waiting for sensor data" |
| Offline / stale | Banner, dimmed values, "Last known" text, pump shown as unknown |
| Locked | Pump chip, interlock chain, reason under the buttons |
| Error | Auth, unsupported response, HTTP, timeout each have their own message; storage errors in Diagnostics |

## 9. Not done (and why it is safe to say so)

Background monitoring and notifications, haptics, snackbars, localisation (English only), biometric lock, mDNS discovery,
HTTPS, Room, screenshots of the running app (the app has never been run).
