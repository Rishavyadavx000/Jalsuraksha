# JAL-SURAKSHA Android

Native Android companion app (Kotlin, Jetpack Compose, Material 3) for an ESP32 water-flow monitor and pump controller.
It talks to the ESP32 directly over your own Wi-Fi or your phone's hotspot. There is no cloud account, no analytics,
no ads and no remote (internet) control.

## Status of this delivery - read this first

| Item | Status |
|---|---|
| Source project | Existing Kotlin + Jetpack Compose feature set and premium Material 3 UI retained in this checkpoint. |
| Gradle sync and compile | **Not run in this environment.** Java 21 is present, but Gradle, Android SDK and network/DNS access are unavailable. |
| Unit tests | 94 cases present. **Not executed.** |
| Instrumented UI tests | 6 cases present. **Not executed.** |
| Source checks | Structural checker and 94 + 6 inventory pass; 10 pure Kotlin data/domain files also compile with local `kotlinc` 1.9.0. This is not the full Android build or test execution. |
| Debug APK | **Not built**, as requested. |
| GitHub CI | Added JVM/lint/build and emulator UI-test workflows. Not run from this offline workspace. |
| ESP32 integration | **Not verified.** The actual `.ino` was not supplied; `docs/API_CONTRACT.md` remains a draft. |
| Pump control | App-side request switch remains OFF by default; firmware permission remains authoritative. No real-hardware test was run. |
| Sensor calibration | **Not calibrated.** The 450 pulses/L figure is a draft assumption. |

See `docs/TEST_REPORT.md` for exact checks, limitations and acceptance steps. Do not treat static checks as a successful
Gradle compile or executed tests.

## Build and run

Requirements: Android Studio Ladybug (2024.2.1) or newer, which bundles a suitable JDK (17+) and manages the Android SDK.
In the SDK Manager install **Android SDK Platform 35**. The app runs on Android 7.0 (API 24) and newer.

1. Unzip and open the `JAL_SURAKSHA_Android` folder in Android Studio (File > Open).
2. Install Android SDK Platform 35 and configure Gradle 8.9 with JDK 17. The target toolchain is listed below.
3. Connect a phone with USB debugging on (or start an emulator) and press Run.
4. Follow the first-run setup: enter the ESP32's address and, if your sketch uses Basic Auth, its username and password.

The standard Gradle wrapper launcher and JAR are not included in this source checkpoint. For command-line tasks, install
Gradle 8.9 and use `gradle` (not `./gradlew`). GitHub Actions installs Gradle 8.9 directly; see `docs/BUILD_AND_CI.md`.

**If the build fails:** open Build > Build Output, copy the first red error and send it back. Most first-build problems
are a single missing import or a version mismatch and are quick to fix.

### Command line

Install Gradle 8.9 locally, then run the source checks and verification tasks:

```bash
python3 tools/verify_test_inventory.py
python3 tools/lint_kt.py .
gradle --no-daemon clean testDebugUnitTest lintDebug compileDebugKotlin
gradle --no-daemon connectedDebugAndroidTest  # needs an API 35 emulator or device
```

The regular verification workflow does not publish a standalone APK. Use the manual-only `Manual APK build` workflow in
GitHub Actions when APK packaging is required. It supports Debug and unsigned Release artifacts.

### Version matrix (declared, not verified as a built set)

| Component | Version |
|---|---|
| Android Gradle Plugin | 8.7.3 |
| Gradle | 8.9 |
| Kotlin and Compose compiler plugin | 2.0.21 |
| Compose BOM | 2024.12.01 |
| compileSdk / targetSdk / minSdk | 35 / 35 / 24 |
| Java target | 17 |
| OkHttp | 4.12.0 |
| kotlinx.coroutines | 1.9.0 |
| Lifecycle / Navigation Compose / DataStore | 2.8.7 / 2.8.5 / 1.1.1 |

This is a declared compatibility set. It is not yet a confirmed build matrix. Update the table after CI has passed.

## Connecting to the ESP32

- The phone and the ESP32 must be on the same network. Two common setups: the ESP32 joins the phone's hotspot, or both
  join one router.
- Find the ESP32's IP address in the Arduino Serial Monitor after a reset (check the baud rate in your sketch; the draft
  used 57600) or in the hotspot's list of connected devices. The address can change when the hotspot restarts. Fix it under
  Settings > Device.
- Accepted addresses: private IPv4 (`10.x`, `172.16-31.x`, `192.168.x`, `169.254.x`) or a `.local` name. Public addresses
  are refused in code. `.local` names resolve on some Android versions and networks only; an IP address always works.
- HTTP only. Basic Auth over plain HTTP is not encrypted: other devices on the same network can observe it. Use a network
  you trust. **Never expose the ESP32 through router port forwarding or the public internet.**

## What the app does

| Area | Implemented |
|---|---|
| Onboarding | Welcome, pre-connection checks, device form with Test connection, secure credential entry |
| Home | Connection state, last update, flow and total volume, 10-minute chart, pump panel, alerts |
| Live monitor | 5/15/30/60-minute chart, now/average/peak, signal, sensor state, calibration state |
| Pump control | State, firmware permission, interlock chain, confirmation, read-back confirmation, run time (only if observed) |
| History | 6 h / 24 h / 7 d / 30 d, flow chart, volume per hour or day, summary, CSV export |
| Events | Offline, stale, auth, no-flow-while-ON, flow-while-OFF, high flow, weak signal, restarts, pump changes; acknowledge; CSV export |
| Settings | Device, polling, alert thresholds, pump-request switch, theme, units, retention, clear data, forget device |
| Calibration | Wizard that compares the device total against a measured volume; optional app-side display correction |
| Diagnostics | Connection, last reading, parser notes, contract in use, phone network, shareable report without secrets |

Deliberately **not** implemented: cloud or remote control, background polling or notifications (polling stops when the app is
not visible), network scanning (needs explicit consent per the spec), HTTPS, biometric app lock, haptics, snackbars,
localisation, a Room database (history is a bounded local file).

## Safety model

1. The firmware is the only authority. The app never overrides `pumpAvailable` and never shows a local "unlock" switch.
2. Every pump request first needs the **app-side Pump requests switch** (Settings; off by default), because the API has not
   been verified against the real firmware.
3. ON additionally needs fresh data, firmware permission ENABLED, a known pump state, and a confirmation dialog.
4. A 2xx reply means "accepted", not "done". The app reports success only after the device itself reports the new state, and
   says "not confirmed" otherwise.
5. Stale, missing, invalid or contradictory pump data is shown as UNKNOWN, never as OFF.
6. No pump request is ever sent at startup or automatically.
7. The app cannot stop the pump if the connection drops. Keep a physical way to cut power. See
   `docs/HARDWARE_SAFETY_CHECKLIST.md`.

## Security model

- Password: AES-256-GCM, key held in the Android Keystore; username and other preferences in DataStore.
- Credentials are only sent in the `Authorization` header to the configured local address; never in a URL; no logging calls
  exist in the code; `toString` redacts.
- Cleartext HTTP is permitted at the platform level because Network Security Configuration cannot express IP ranges, and is
  restricted in code: address validation, a second check inside `DeviceApi`, a DNS guard that refuses non-private results,
  and redirects disabled. Details are in `app/src/main/res/xml/network_security_config.xml`.
- `allowBackup` is off. Exports are written to the app cache and shared through a `FileProvider`.

## Project layout

```
JAL_SURAKSHA_Android/
  app/src/main/java/com/jalsuraksha/app/
    data/      models, API contract + strict parser, endpoint validation, OkHttp client, Keystore store, DataStore settings, history/event files
    domain/    link/staleness rules, alert engine, pump gate, analytics, calibration maths, formatting, CSV
    ui/        AppViewModel, navigation, theme/, components/, screens/
  app/src/test/            JVM unit tests (94)
  app/src/androidTest/     Compose UI tests (6)
  docs/                    audit, API contract, hardware checklist, architecture, test report
```

## Data stored on the phone

| Data | Where | Notes |
|---|---|---|
| Password | `SharedPreferences` file, AES-GCM ciphertext; key in Android Keystore | never logged, never in backups |
| Address, username, thresholds, theme, units, calibration | DataStore | no secrets |
| Samples (time, flow, total, pump, RSSI) | `files/history/samples.csv` | only what the app received while open |
| Events | `files/history/events.jsonl` | max 500, pruned by retention |
| CSV exports | `cache/exports/` | only the latest is kept |

## Troubleshooting

| Symptom | Likely cause and fix |
|---|---|
| "No answer" / timeout | ESP32 off, wrong network, or hotspot restarted and the IP changed. Check Settings > Device and the ESP32's Serial Monitor. |
| "Cannot reach the device" | Wrong IP, or the phone is on another network. Diagnostics shows the phone's active network. |
| "Credentials rejected" (401) | Username or password differs from the sketch. Re-enter under Settings > Device. |
| "Unsupported response" | The firmware answered but not with the expected JSON. Compare with `docs/API_CONTRACT.md`. |
| Pump buttons are disabled | Read the one-line reason under the buttons. The interlock chain on the Pump screen shows which gate is closed. |
| Values show `--` | The device sent no valid value for that field. This is shown honestly, never as 0. |

## Known limitations

- Not compiled, tested on a device or checked against real firmware (see the status table).
- History exists only for time the app was open and connected; gaps are shown as gaps. It is not device-persisted data.
- Alerts are advisory, work only while the app is open, and the flow-based ones are heuristics.
- The Gradle wrapper launcher scripts and JAR are missing; install Gradle 8.9 locally or use the included GitHub Actions workflows (see `docs/BUILD_AND_CI.md`).
- Pulse count and the firmware's calibration constant are not exposed by the draft API, so the calibration wizard works from
  the device's litre total and cannot change the firmware.

## Documents

- `docs/STAGE0_AUDIT.md` - the ten starter findings and how each is handled
- `docs/API_CONTRACT.md` - routes, JSON schema, error mapping, how to verify against your `.ino`, firmware recommendations
- `docs/HARDWARE_SAFETY_CHECKLIST.md` - sign off before any pump test
- `docs/ARCHITECTURE_AND_DESIGN.md` - architecture, design system, key decisions
- `docs/TEST_REPORT.md` - what was and was not tested, plus the manual test plan
- `docs/BUILD_AND_CI.md` - supported local build steps and GitHub Actions workflows
- `CONTRIBUTING.md` - safety and change requirements
- `.github/workflows/verify.yml` - unit tests, lint, debug compile and emulator UI tests
- `.github/workflows/manual-apk.yml` - manual-only future APK workflow
- `CHANGELOG.md` - files created and replaced
