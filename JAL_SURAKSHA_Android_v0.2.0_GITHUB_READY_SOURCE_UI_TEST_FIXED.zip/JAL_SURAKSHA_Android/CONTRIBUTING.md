# Contributing

1. Preserve the existing Kotlin/Compose feature set and Material 3 design system.
2. Keep pump controls fail-closed: missing, stale, invalid, contradictory, or unverified firmware data must never be
   interpreted as permission to start the pump. Do not remove either the app-side request gate or firmware-side checks.
3. Do not change endpoint names, JSON fields, authentication, or pump semantics based on assumptions. Verify changes against
   the actual ESP32 firmware and update `docs/API_CONTRACT.md` plus the corresponding tests.
4. Add or update unit tests for domain/data changes and Compose UI tests for safety-critical UI changes.
5. Run `python3 tools/verify_test_inventory.py`, `python3 tools/lint_kt.py .`, `gradle testDebugUnitTest lintDebug`, and
   `gradle connectedDebugAndroidTest` before proposing a change when the toolchain is available.
6. Never add real device passwords, API credentials, signing keys, keystores, local IPs from a real installation, or private
   hardware logs to the repository.

See [docs/BUILD_AND_CI.md](docs/BUILD_AND_CI.md), [docs/HARDWARE_SAFETY_CHECKLIST.md](docs/HARDWARE_SAFETY_CHECKLIST.md),
and [docs/API_CONTRACT.md](docs/API_CONTRACT.md).
