# JAL-SURAKSHA Android v0.2.0 - change report

**Prepared:** 2026-11-12
**Input:** `JAL_SURAKSHA_Android_v0.2.0_source.zip` and `JAL_SURAKSHA_README.md`

## Executive summary

The source project has been retained and prepared for repeatable verification through GitHub Actions. The existing application
screens, Compose components, Material 3 theme, data layer, domain logic, and tests were not rewritten or stripped. This
checkpoint focuses on repository quality, test inventory integrity, CI configuration, and honest test reporting.

The offline structural checks now pass. The 94 JVM test annotations and 6 instrumented UI test annotations are confirmed.
A 10-file pure Kotlin data/domain subset also compiles with the locally available Kotlin 1.9.0 compiler. However, no Gradle
sync, full Android compile, standard Gradle/JUnit execution, Android lint task, emulator test, or APK build could be run in the
current environment because Gradle and the Android SDK are absent and external DNS/network access is unavailable. Therefore
this report does not claim that full-project compilation errors have been eliminated or that all test cases pass.

## Changes made

### 1. Repository automation

- Added `.github/workflows/verify.yml` for push, pull request, and manual verification runs.
- The JVM job installs JDK 17, Android SDK Platform 35, and Gradle 8.9; verifies test counts; runs the Kotlin/XML structural
  checker; runs `testDebugUnitTest`, `lintDebug`, and `compileDebugKotlin`; then uploads reports. It does not publish or upload an APK.
- The Compose UI job launches an API 35 emulator and runs `connectedDebugAndroidTest`; it uploads instrumentation reports.
- Added `.github/workflows/manual-apk.yml`, which is triggered only through the GitHub Actions `workflow_dispatch` UI. It
  can build a Debug APK or an unsigned Release APK and upload the artifact. This workflow was not run and no APK is included.

### 2. Static checker repair

Updated `tools/lint_kt.py`:

- Top-level `val` / `var` properties are indexed as project declarations so legitimate property imports are not reported as
  unresolved. This resolves the false positive for `MetricStyle`.
- Generic function declarations such as `fun <T> ChipRow(...)` are no longer parsed as function call sites. This resolves
  the false positive for `ChipRow`.
- The repository root defaults to the tool's parent project directory when no path argument is supplied.

Observed run:

```text
Checked 49 Kotlin files, 84 callable signatures, 104 top-level declarations.
No findings.
```

This remains a custom structural checker, not a Kotlin compiler.

### 2.1 Partial Kotlin compilation

The local `kotlinc` is version 1.9.0, whereas the project config declares Kotlin 2.0.21. Ten pure Kotlin data/domain source files
(`Models`, `ApiModels`, `EndpointValidator`, `AlertEngine`, `Analytics`, `Calibration`, `CsvExport`, `Formats`, `LinkDeriver`,
`PumpGatePolicy`) compiled successfully with JVM target 17 to a temporary JAR. This does not include Android/Compose code,
Android-bound repositories, OkHttp, JSON parser code, the complete project, or any tests.

### 3. Test inventory guard

Added executable `tools/verify_test_inventory.py`. It checks the existing test annotations and fails CI if the inventory
changes unexpectedly:

```text
test: 94 @Test annotations across 9 Kotlin files (expected 94) [OK]
androidTest: 6 @Test annotations across 1 Kotlin files (expected 6) [OK]
Inventory matches the documented 94 JVM + 6 instrumented UI tests.
Note: inventory counting is not test execution.
```

### 4. Documentation

- Updated `README.md` to report actual checkpoint state, local command-line commands, missing wrapper files, CI workflows and
  verification limits.
- Reworked `docs/TEST_REPORT.md` to record exact environment blockers, static-check results, test inventory, firmware status,
  pump-safety boundary and complete post-checkout acceptance plan.
- Added `docs/BUILD_AND_CI.md` with the configured Gradle/AGP/Kotlin/SDK matrix, local commands, workflows, and evidence
  required before calling the project verified.
- Added `CONTRIBUTING.md` with rules for code changes, firmware compatibility, credentials and pump safety.
- Updated `CHANGELOG.md` with this checkpoint's repository changes.

## Preserved application behaviour and safety

No files under `app/src/main/java` or `app/src/main/res` were changed in this checkpoint. The existing UI and feature
implementation remain in the archive. The pump gate is not weakened:

- `pumpRequestsEnabled` remains false by default.
- Firmware `pumpAvailable` remains the authority; the app does not provide an override.
- ON still needs fresh status, firmware permission ENABLED, known pump state, and a confirmation step.
- Device read-back remains necessary before a command is called confirmed.
- Invalid, missing, stale or contradictory pump status is not converted to OFF.
- The app does not send automatic pump commands at startup.
- The device may not be remotely stoppable if the phone loses connection; the physical power cut-off remains essential.

The actual ESP32 `.ino` was not included. The draft route and JSON contract has not been checked against the real firmware.
No assumptions have been promoted to confirmed compatibility.

## Toolchain and compatibility status

The project declares:

| Component | Version |
|---|---|
| Android Gradle Plugin | 8.7.3 |
| Gradle | 8.9 |
| Kotlin / Compose compiler plugin | 2.0.21 |
| Compose BOM | 2024.12.01 |
| compileSdk / targetSdk / minSdk | 35 / 35 / 24 |
| Java bytecode target | 17 |

The properties file pins Gradle 8.9, but the official wrapper JAR and launcher scripts were not present in the provided
source and could not be downloaded. The CI workflows install Gradle 8.9 directly through the setup action; local CLI users
must install Gradle 8.9 until the official wrapper files are generated and committed.

## Verification performed in this workspace

| Command | Result |
|---|---|
| `python3 tools/verify_test_inventory.py` | Passed inventory check: 94 + 6 |
| `python3 tools/lint_kt.py .` | Passed: 49 Kotlin files, no structural findings |
| Partial `kotlinc` compile | Passed: 10 pure Kotlin data/domain files using Kotlin 1.9.0, JVM target 17 |
| `gradle --version` | Blocked: Gradle not installed |
| `./gradlew testDebugUnitTest` | Not runnable: wrapper launcher/JAR missing |
| `gradle testDebugUnitTest` | Not runnable: Gradle not installed; network DNS unavailable |
| `gradle lintDebug` | Not run: Gradle/AGP unavailable |
| `gradle assembleDebug` | Not run; APK packaging is reserved for the manual GitHub workflow |
| `gradle connectedDebugAndroidTest` | Not run: no Gradle, SDK or emulator |
| ESP32 hardware verification | Not run: actual sketch and hardware unavailable |

## Remaining actions before calling v0.2.0 build-verified

1. Push the repository to GitHub and run the `Android verification` workflow.
2. Fix any real compiler/API errors reported by `compileDebugKotlin`, `testDebugUnitTest`, or `lintDebug`; do not infer success
   from the static checker.
3. Confirm all 94 JVM tests pass and all 6 Compose UI tests pass on the API 35 emulator. Review uploaded XML/HTML reports.
4. Add the actual ESP32 `.ino`, inspect its route handlers and response JSON, and update `docs/API_CONTRACT.md` only from
   observed firmware behaviour.
5. Complete `docs/HARDWARE_SAFETY_CHECKLIST.md` with pump power disconnected until it is explicitly safe to conduct a
   controlled bench test.

**Bottom line:** this checkpoint is GitHub-CI prepared and statically checked, but it is not yet compile-verified, test-verified,
firmware-verified, or hardware-verified.
