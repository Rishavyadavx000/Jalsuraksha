package com.jalsuraksha.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.jalsuraksha.app.R
import com.jalsuraksha.app.ui.theme.Jal
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withTimeoutOrNull

/**
 * Brand moment while saved settings load. Never blocks: after 2.5 s it continues regardless.
 * A longer brand introduction is shown only on the very first launch.
 */
@Composable
fun SplashScreen(ready: Boolean, firstLaunch: Boolean, onFinished: () -> Unit) {
    val readyNow by rememberUpdatedState(ready)
    val firstNow by rememberUpdatedState(firstLaunch)
    val finish by rememberUpdatedState(onFinished)

    LaunchedEffect(Unit) {
        val startedAt = System.currentTimeMillis()
        withTimeoutOrNull(2_500L) { snapshotFlow { readyNow }.first { it } }
        val minShowMs = if (firstNow) 1_400L else 600L
        val elapsed = System.currentTimeMillis() - startedAt
        if (elapsed < minShowMs) {
            delay(minShowMs - elapsed)
        }
        finish()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Jal.colors.hero)
            .systemBarsPadding(),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(32.dp),
        ) {
            Box(
                modifier = Modifier
                    .size(88.dp)
                    .background(Color(0x1F5EEAD4), CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    Icons.Filled.WaterDrop,
                    contentDescription = null,
                    tint = Color(0xFF5EEAD4),
                    modifier = Modifier.size(44.dp),
                )
            }
            Spacer(Modifier.height(24.dp))
            Text(
                stringResource(R.string.app_name),
                style = MaterialTheme.typography.headlineLarge,
                color = Jal.colors.onHero,
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "Smart water management",
                style = MaterialTheme.typography.bodyLarge,
                color = Jal.colors.onHeroMuted,
                textAlign = TextAlign.Center,
            )
        }
    }
}
