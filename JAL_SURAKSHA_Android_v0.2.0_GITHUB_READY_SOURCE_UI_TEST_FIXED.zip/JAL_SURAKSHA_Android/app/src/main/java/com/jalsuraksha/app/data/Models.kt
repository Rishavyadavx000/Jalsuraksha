package com.jalsuraksha.app.data

/** Pump state as reported by the device. UNKNOWN is the safe value for missing, invalid or contradictory data. */
enum class PumpState { ON, OFF, UNKNOWN }

/** The firmware's own permission to run the pump (`pumpAvailable`). Read-only in the app, never overridable. */
enum class FirmwarePumpPermission { ENABLED, LOCKED, UNKNOWN }

/** One validated status reading from the ESP32. Nullable fields mean "the device did not provide a valid value". */
data class DeviceStatus(
    val wifi: String?,
    val ip: String?,
    val rssiDbm: Int?,
    val pump: PumpState,
    val pumpPermission: FirmwarePumpPermission,
    val flowLpm: Double?,
    val totalLiters: Double?,
    val deviceId: String?,
    val apiVersion: Int?,
    val receivedAtMs: Long,
    /** True when the device reported pump ON while pump control is locked; the pump state is then UNKNOWN. */
    val contradictoryPump: Boolean = false,
    val warnings: List<String> = emptyList(),
)

/** A stored reading. Values are raw device values; calibration is applied only at display time. */
data class Sample(
    val tMs: Long,
    val flowLpm: Double?,
    val totalLiters: Double?,
    val pump: PumpState,
    val rssiDbm: Int?,
)

enum class Severity { INFO, WARNING, CRITICAL }

enum class EventType {
    DEVICE_OFFLINE,
    DEVICE_ONLINE,
    AUTH_FAILED,
    DATA_STALE,
    UNSUPPORTED_API,
    SENSOR_UNAVAILABLE,
    NO_FLOW_WHILE_ON,
    FLOW_WHILE_OFF,
    HIGH_FLOW,
    WEAK_SIGNAL,
    DEVICE_REBOOT,
    PUMP_STATE_CHANGED,
    PUMP_LOCK_CHANGED,
    PUMP_STATUS_CONTRADICTION,
    PUMP_COMMAND,
    CALIBRATION_SAVED,
}

data class EventRecord(
    val id: Long,
    val tMs: Long,
    val severity: Severity,
    val type: EventType,
    val message: String,
    val acknowledged: Boolean = false,
)

enum class ThemeMode { SYSTEM, LIGHT, DARK }

enum class VolumeUnit { LITERS, US_GALLONS }

enum class LinkState { NOT_CONFIGURED, CONNECTING, ONLINE, STALE, OFFLINE, AUTH_REQUIRED, UNSUPPORTED }

/** Everything the app knows about its connection to the device right now. */
data class DeviceSnapshot(
    val status: DeviceStatus? = null,
    val lastSuccessMs: Long? = null,
    val lastAttemptMs: Long? = null,
    val consecutiveFailures: Int = 0,
    val lastError: ApiError? = null,
    val lastLatencyMs: Long? = null,
    val successCount: Int = 0,
    val failureCount: Int = 0,
    /** A local problem (storage, keystore) that is not the device's fault. Shown in Diagnostics. */
    val internalError: String? = null,
)
