package com.jalsuraksha.app.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.Call
import okhttp3.Callback
import okhttp3.Credentials
import okhttp3.Dns
import okhttp3.HttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import java.io.IOException
import java.io.InterruptedIOException
import java.net.InetAddress
import java.net.UnknownHostException
import java.util.concurrent.TimeUnit
import kotlin.coroutines.cancellation.CancellationException
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** Held in memory only while a request is built. toString never prints the password. */
class DeviceCredentials(val username: String, val password: String) {
    val isUsable: Boolean get() = username.isNotBlank() && password.isNotEmpty()

    override fun toString(): String = "DeviceCredentials(username=$username, password=<redacted>)"
}

class Endpoint(
    val host: String,
    val port: Int,
    val statusPath: String,
    val pumpOnPath: String,
    val pumpOffPath: String,
    val credentials: DeviceCredentials?,
) {
    override fun toString(): String =
        "Endpoint(${EndpointValidator.baseUrl(host, port)}, hasCredentials=${credentials?.isUsable == true})"
}

/** Refuses any resolved address that is not private or link-local, so a .local name cannot point at the internet. */
object LocalOnlyDns : Dns {
    override fun lookup(hostname: String): List<InetAddress> {
        val local = Dns.SYSTEM.lookup(hostname).filter { EndpointValidator.isLocalAddress(it) }
        if (local.isEmpty()) {
            throw UnknownHostException("$hostname did not resolve to a private or link-local address")
        }
        return local
    }
}

/**
 * Typed HTTP client for the ESP32. Every call is a suspend function that never blocks the caller's
 * thread, is cancelled with its coroutine, has hard timeouts, and returns a structured outcome
 * instead of throwing. Credentials go only in the Authorization header and are never logged.
 */
class DeviceApi(
    client: OkHttpClient = defaultClient(),
    private val hostPolicy: (String) -> Boolean = { EndpointValidator.isAllowedHost(it) },
) {
    private val statusClient: OkHttpClient = client.newBuilder()
        .callTimeout(6, TimeUnit.SECONDS)
        .build()

    // Commands are not idempotent: never let the HTTP stack silently retry them.
    private val commandClient: OkHttpClient = client.newBuilder()
        .callTimeout(8, TimeUnit.SECONDS)
        .retryOnConnectionFailure(false)
        .build()

    suspend fun fetchStatus(
        ep: Endpoint,
        clock: () -> Long = { System.currentTimeMillis() },
    ): ApiOutcome<DeviceStatus> {
        return when (val raw = request(ep, ep.statusPath, post = false, client = statusClient)) {
            is Raw.Fail -> ApiOutcome.Failure(raw.error)
            is Raw.Reply -> when {
                raw.code == 401 -> ApiOutcome.Failure(ApiError.AuthRequired)
                raw.code in 200..299 -> when (val parsed = StatusParser.parse(raw.body, clock())) {
                    is ParseResult.Ok -> ApiOutcome.Success(parsed.status, raw.code, raw.latencyMs)
                    is ParseResult.Invalid -> ApiOutcome.Failure(ApiError.BadResponse(parsed.reason))
                }
                else -> ApiOutcome.Failure(ApiError.HttpError(raw.code, raw.body.take(200)))
            }
        }
    }

    /** A 2xx reply only means the device accepted the request. The caller must read the state back. */
    suspend fun sendPump(ep: Endpoint, on: Boolean): ApiOutcome<Unit> {
        val path = if (on) ep.pumpOnPath else ep.pumpOffPath
        return when (val raw = request(ep, path, post = true, client = commandClient)) {
            is Raw.Fail -> ApiOutcome.Failure(raw.error)
            is Raw.Reply -> when {
                raw.code == 401 -> ApiOutcome.Failure(ApiError.AuthRequired)
                raw.code in 200..299 -> ApiOutcome.Success(Unit, raw.code, raw.latencyMs)
                else -> ApiOutcome.Failure(ApiError.HttpError(raw.code, raw.body.take(200)))
            }
        }
    }

    private sealed interface Raw {
        data class Reply(val code: Int, val body: String, val latencyMs: Long) : Raw
        data class Fail(val error: ApiError) : Raw
    }

    private suspend fun request(ep: Endpoint, path: String, post: Boolean, client: OkHttpClient): Raw {
        if (!hostPolicy(ep.host)) {
            return Raw.Fail(ApiError.InvalidEndpoint("${ep.host} is not a private network address."))
        }
        val url = try {
            HttpUrl.Builder().scheme("http").host(ep.host).port(ep.port).encodedPath(path).build()
        } catch (e: IllegalArgumentException) {
            return Raw.Fail(ApiError.InvalidEndpoint("The address or API path is not valid."))
        }

        val builder = Request.Builder().url(url).header("Accept", "application/json")
        val creds = ep.credentials
        if (creds != null && creds.isUsable) {
            builder.header("Authorization", Credentials.basic(creds.username, creds.password))
        }
        if (post) {
            builder.post(ByteArray(0).toRequestBody(null))
        } else {
            builder.get()
        }

        val startedNs = System.nanoTime()
        return try {
            val response = client.newCall(builder.build()).await()
            withContext(Dispatchers.IO) {
                response.use { r ->
                    val body = r.peekBody(ApiContract.MAX_BODY_BYTES).string()
                    Raw.Reply(r.code, body, (System.nanoTime() - startedNs) / 1_000_000L)
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: InterruptedIOException) {
            Raw.Fail(ApiError.Timeout)
        } catch (e: UnknownHostException) {
            Raw.Fail(ApiError.Unreachable("the name did not resolve to a local address"))
        } catch (e: IOException) {
            Raw.Fail(ApiError.Unreachable(e.message ?: e.javaClass.simpleName))
        }
    }

    companion object {
        fun defaultClient(): OkHttpClient = OkHttpClient.Builder()
            .connectTimeout(3, TimeUnit.SECONDS)
            .readTimeout(4, TimeUnit.SECONDS)
            .writeTimeout(4, TimeUnit.SECONDS)
            .followRedirects(false)
            .followSslRedirects(false)
            .dns(LocalOnlyDns)
            .build()
    }
}

/** Suspends until the call completes; cancelling the coroutine cancels the HTTP call. */
private suspend fun Call.await(): Response = suspendCancellableCoroutine { cont ->
    cont.invokeOnCancellation { cancel() }
    enqueue(object : Callback {
        override fun onResponse(call: Call, response: Response) {
            if (cont.isActive) cont.resume(response) else response.close()
        }

        override fun onFailure(call: Call, e: IOException) {
            if (cont.isActive) cont.resumeWithException(e)
        }
    })
}
