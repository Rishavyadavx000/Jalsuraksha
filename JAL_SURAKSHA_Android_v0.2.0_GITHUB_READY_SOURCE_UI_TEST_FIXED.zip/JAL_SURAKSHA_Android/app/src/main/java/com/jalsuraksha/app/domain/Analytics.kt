package com.jalsuraksha.app.domain

import com.jalsuraksha.app.data.PumpState
import com.jalsuraksha.app.data.Sample
import java.util.Calendar
import java.util.TimeZone

data class ChartPoint(val tMs: Long, val value: Double)

/** Points plus the largest time gap that may still be joined by a line. Anything wider is drawn as a break. */
data class FlowSeries(val points: List<ChartPoint>, val maxGapMs: Long)

data class UsageStats(
    val sampleCount: Int,
    val observedMs: Long,
    val volumeLiters: Double,
    val peakFlowLpm: Double?,
    val avgFlowLpm: Double?,
    val pumpOnMs: Long,
    val counterResets: Int,
)

/** liters == null means "this app observed nothing in this slot", which is different from 0 litres. */
data class UsageSlot(val startMs: Long, val liters: Double?)

enum class BucketSize { HOUR, DAY }

/**
 * Everything here counts only intervals between two consecutive samples that are no further apart
 * than maxGapMs. Volume across a longer gap is NOT attributed to any time; nothing is interpolated.
 */
object Analytics {
    const val RESET_EPSILON_L = 0.05

    fun stats(samples: List<Sample>, maxGapMs: Long): UsageStats {
        val sorted = samples.sortedBy { it.tMs }

        var flowSum = 0.0
        var flowCount = 0
        var peak: Double? = null
        for (s in sorted) {
            val f = s.flowLpm ?: continue
            flowSum += f
            flowCount += 1
            val p = peak
            peak = if (p == null || f > p) f else p
        }

        var observed = 0L
        var volume = 0.0
        var pumpOn = 0L
        var resets = 0
        for (i in 1 until sorted.size) {
            val a = sorted[i - 1]
            val b = sorted[i]
            val dt = b.tMs - a.tMs
            if (dt <= 0L || dt > maxGapMs) continue
            observed += dt
            if (a.pump == PumpState.ON && b.pump == PumpState.ON) {
                pumpOn += dt
            }
            val ta = a.totalLiters
            val tb = b.totalLiters
            if (ta != null && tb != null) {
                val delta = tb - ta
                if (delta >= 0.0) {
                    volume += delta
                } else if (delta < -RESET_EPSILON_L) {
                    resets += 1
                }
            }
        }

        return UsageStats(
            sampleCount = sorted.size,
            observedMs = observed,
            volumeLiters = volume,
            peakFlowLpm = peak,
            avgFlowLpm = if (flowCount > 0) flowSum / flowCount else null,
            pumpOnMs = pumpOn,
            counterResets = resets,
        )
    }

    fun usageSlots(
        samples: List<Sample>,
        size: BucketSize,
        tz: TimeZone,
        maxGapMs: Long,
        startMs: Long,
        endMs: Long,
    ): List<UsageSlot> {
        val sorted = samples.sortedBy { it.tMs }
        val liters = HashMap<Long, Double>()
        val observed = HashMap<Long, Long>()
        val volumeKnown = HashSet<Long>()

        for (i in 1 until sorted.size) {
            val a = sorted[i - 1]
            val b = sorted[i]
            val dt = b.tMs - a.tMs
            if (dt <= 0L || dt > maxGapMs) continue
            val key = bucketStart(b.tMs, size, tz)
            observed[key] = (observed[key] ?: 0L) + dt
            val ta = a.totalLiters
            val tb = b.totalLiters
            if (ta != null && tb != null) {
                volumeKnown.add(key)
                val delta = tb - ta
                if (delta >= 0.0) {
                    liters[key] = (liters[key] ?: 0.0) + delta
                }
            }
        }

        return bucketStarts(startMs, endMs, size, tz).map { start ->
            val hasData = (observed[start] ?: 0L) > 0L && start in volumeKnown
            UsageSlot(start, if (hasData) (liters[start] ?: 0.0) else null)
        }
    }

    /** Averages flow into equal time buckets. Empty buckets produce no point, so gaps stay visible. */
    fun flowSeries(samples: List<Sample>, startMs: Long, endMs: Long, buckets: Int): FlowSeries {
        val n = buckets.coerceAtLeast(1)
        val width = ((endMs - startMs) / n).coerceAtLeast(1L)
        val sums = DoubleArray(n)
        val counts = IntArray(n)
        for (s in samples) {
            val f = s.flowLpm ?: continue
            if (s.tMs < startMs || s.tMs > endMs) continue
            val idx = ((s.tMs - startMs) / width).toInt().coerceIn(0, n - 1)
            sums[idx] += f
            counts[idx] += 1
        }
        val points = ArrayList<ChartPoint>()
        for (i in 0 until n) {
            if (counts[i] > 0) {
                points.add(ChartPoint(startMs + i * width + width / 2, sums[i] / counts[i]))
            }
        }
        return FlowSeries(points, width * 3 / 2)
    }

    fun bucketStart(tMs: Long, size: BucketSize, tz: TimeZone): Long {
        val cal = Calendar.getInstance(tz)
        cal.timeInMillis = tMs
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        if (size == BucketSize.DAY) {
            cal.set(Calendar.HOUR_OF_DAY, 0)
        }
        return cal.timeInMillis
    }

    fun bucketStarts(startMs: Long, endMs: Long, size: BucketSize, tz: TimeZone): List<Long> {
        val out = ArrayList<Long>()
        val cal = Calendar.getInstance(tz)
        cal.timeInMillis = bucketStart(startMs, size, tz)
        val field = if (size == BucketSize.HOUR) Calendar.HOUR_OF_DAY else Calendar.DAY_OF_YEAR
        var guard = 0
        while (cal.timeInMillis <= endMs && guard < 1000) {
            out.add(cal.timeInMillis)
            cal.add(field, 1)
            guard += 1
        }
        return out
    }

    /**
     * Start (as first seen by this app) of the current pump-ON streak, or null when the app did not
     * see the pump switch from OFF to ON, in which case no run time is claimed.
     */
    fun observedOnStreakStartMs(samples: List<Sample>, maxGapMs: Long): Long? {
        val sorted = samples.sortedBy { it.tMs }
        if (sorted.isEmpty() || sorted.last().pump != PumpState.ON) return null
        var i = sorted.size - 1
        while (i > 0 &&
            sorted[i - 1].pump == PumpState.ON &&
            sorted[i].tMs - sorted[i - 1].tMs <= maxGapMs
        ) {
            i -= 1
        }
        if (i == 0) return null
        val before = sorted[i - 1]
        return if (before.pump == PumpState.OFF && sorted[i].tMs - before.tMs <= maxGapMs) sorted[i].tMs else null
    }
}
