package com.jalsuraksha.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.jalsuraksha.app.data.LinkState
import com.jalsuraksha.app.domain.ChartPoint
import com.jalsuraksha.app.domain.Formats
import com.jalsuraksha.app.domain.FlowSeries
import com.jalsuraksha.app.ui.UiSnapshot
import com.jalsuraksha.app.ui.components.ChipRow
import com.jalsuraksha.app.ui.components.JalCard
import com.jalsuraksha.app.ui.components.JalOutlinedButton
import com.jalsuraksha.app.ui.components.LineChart
import com.jalsuraksha.app.ui.components.MetricTile
import com.jalsuraksha.app.ui.components.ScreenHeader
import com.jalsuraksha.app.ui.components.StatusChip
import com.jalsuraksha.app.ui.components.Tone
import com.jalsuraksha.app.ui.theme.JalSpacing

private val RANGES = listOf(
    "5 min" to 5L * 60_000L,
    "15 min" to 15L * 60_000L,
    "30 min" to 30L * 60_000L,
    "1 hour" to 60L * 60_000L,
)

@Composable
fun MonitorScreen(ui: UiSnapshot, onOpenCalibration: () -> Unit) {
    var rangeIndex by rememberSaveable { mutableStateOf(1) }
    val unit = ui.settings.unit
    val stale = ui.link != LinkState.ONLINE
    val rangeMs = RANGES[rangeIndex].second
    val start = ui.nowMs - rangeMs

    val window = ui.recent.filter { it.tMs >= start }
    val points = window.mapNotNull { s ->
        val f = s.flowLpm
        if (f != null) ChartPoint(s.tMs, Formats.flowValue(f, unit)) else null
    }
    val flows = window.mapNotNull { it.flowLpm }
    val average = if (flows.isEmpty()) null else flows.average()
    val peak = flows.maxOrNull()
    val gapMs = maxOf(ui.settings.pollIntervalSec * 3_000L, 12_000L)

    val linkTone = when (ui.link) {
        LinkState.ONLINE -> Tone.SUCCESS
        LinkState.CONNECTING, LinkState.STALE -> Tone.WARNING
        LinkState.OFFLINE, LinkState.AUTH_REQUIRED, LinkState.UNSUPPORTED -> Tone.DANGER
        LinkState.NOT_CONFIGURED -> Tone.NEUTRAL
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
    ) {
        ScreenHeader(
            title = "Live monitor",
            subtitle = ui.ageMs?.let { "Updated ${Formats.age(it)}" } ?: "No reading yet",
            trailing = { StatusChip(Formats.linkLabel(ui.link), linkTone) },
        )
        Column(
            modifier = Modifier.padding(horizontal = JalSpacing.lg),
            verticalArrangement = Arrangement.spacedBy(JalSpacing.md),
        ) {
            ChipRow(
                options = RANGES.mapIndexed { i, r -> r.first to i },
                selected = rangeIndex,
                onSelect = { rangeIndex = it },
            )

            JalCard {
                Text("Flow rate", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(JalSpacing.sm))
                LineChart(
                    series = FlowSeries(points, gapMs),
                    startMs = start,
                    endMs = ui.nowMs,
                    unit = Formats.flowUnit(unit),
                    description = "Line chart of flow rate over the last ${RANGES[rangeIndex].first}",
                    startLabel = Formats.shortClock(start),
                    endLabel = Formats.shortClock(ui.nowMs),
                    height = 220.dp,
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    "Real readings only. A break in the line means the app received nothing.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(JalSpacing.md)) {
                MetricTile(
                    label = "Now",
                    value = Formats.flow(ui.flowLpm, unit),
                    unit = Formats.flowUnit(unit),
                    modifier = Modifier.weight(1f),
                    caption = if (stale) "Last known (stale)" else null,
                    dimmed = stale,
                )
                MetricTile(
                    label = "Average",
                    value = Formats.flow(average, unit),
                    unit = Formats.flowUnit(unit),
                    modifier = Modifier.weight(1f),
                    caption = "This window",
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(JalSpacing.md)) {
                MetricTile(
                    label = "Peak",
                    value = Formats.flow(peak, unit),
                    unit = Formats.flowUnit(unit),
                    modifier = Modifier.weight(1f),
                    caption = "This window",
                )
                MetricTile(
                    label = "Total volume",
                    value = Formats.volume(ui.totalLiters, unit),
                    unit = Formats.volumeUnit(unit),
                    modifier = Modifier.weight(1f),
                    caption = "Device counter",
                    dimmed = stale,
                )
            }

            JalCard {
                Text("Sensor and signal", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(JalSpacing.sm))
                val status = ui.status
                StatRow("Flow sensor", if (status?.flowLpm != null) "Reporting" else "No valid reading")
                StatRow(
                    "Wi-Fi signal",
                    status?.rssiDbm?.let { "${Formats.signalQuality(it)} ($it dBm)" } ?: "--",
                )
                StatRow("Pulse count", "Not provided by the firmware API")
            }

            JalCard {
                Text("Calibration", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(4.dp))
                val s = ui.settings
                val factorText = String.format(java.util.Locale.US, "%.3f", s.calFactor)
                Text(
                    when {
                        s.calApplied && s.calDateMs > 0L ->
                            "An app-side correction of x$factorText is applied to displayed values (saved ${Formats.dateTime(s.calDateMs)}). The firmware's own constant is unchanged."
                        s.calDateMs > 0L ->
                            "A calibration result (x$factorText) is saved but not applied to displayed values."
                        else ->
                            "No calibration recorded. Readings use the firmware's pulses-per-litre constant, which this app cannot see (the draft used 450; verify it in your sketch)."
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(JalSpacing.md))
                JalOutlinedButton(
                    text = "Calibration wizard",
                    onClick = onOpenCalibration,
                    icon = Icons.Filled.Build,
                )
            }
            Spacer(Modifier.height(JalSpacing.lg))
        }
    }
}
