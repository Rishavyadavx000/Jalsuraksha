package com.jalsuraksha.app.data

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Stores the device password encrypted with an AES-256-GCM key that lives in the Android Keystore.
 * The key never leaves the keystore; only ciphertext is written to app-private storage.
 * The username is not secret and lives in normal settings. The password is never logged.
 */
class SecretStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    /** Last problem with the keystore, shown in Diagnostics. Never contains secret values. */
    @Volatile
    var lastError: String? = null
        private set

    @Synchronized
    fun hasPassword(): Boolean = prefs.contains(KEY_PASSWORD)

    @Synchronized
    fun getPassword(): String? {
        val stored = prefs.getString(KEY_PASSWORD, null) ?: return null
        return try {
            val raw = Base64.decode(stored, Base64.NO_WRAP)
            if (raw.size <= IV_BYTES) {
                lastError = "The saved password is corrupt. Enter it again in Settings."
                return null
            }
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(
                Cipher.DECRYPT_MODE,
                secretKey(),
                GCMParameterSpec(TAG_BITS, raw.copyOfRange(0, IV_BYTES)),
            )
            String(cipher.doFinal(raw, IV_BYTES, raw.size - IV_BYTES), Charsets.UTF_8)
        } catch (e: Exception) {
            lastError = "Could not decrypt the saved password (${e.javaClass.simpleName}). Enter it again in Settings."
            null
        }
    }

    /** Pass null or an empty string to remove the saved password. Returns false if it could not be stored. */
    @Synchronized
    fun setPassword(password: String?): Boolean {
        if (password.isNullOrEmpty()) {
            prefs.edit().remove(KEY_PASSWORD).apply()
            return true
        }
        return try {
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.ENCRYPT_MODE, secretKey())
            val sealed = cipher.iv + cipher.doFinal(password.toByteArray(Charsets.UTF_8))
            prefs.edit().putString(KEY_PASSWORD, Base64.encodeToString(sealed, Base64.NO_WRAP)).apply()
            lastError = null
            true
        } catch (e: Exception) {
            lastError = "Could not encrypt the password (${e.javaClass.simpleName}); it was not saved."
            false
        }
    }

    @Synchronized
    fun clear() {
        prefs.edit().clear().apply()
        try {
            val ks = KeyStore.getInstance(KEYSTORE).apply { load(null) }
            if (ks.containsAlias(KEY_ALIAS)) ks.deleteEntry(KEY_ALIAS)
        } catch (e: Exception) {
            lastError = "Could not remove the keystore key (${e.javaClass.simpleName})."
        }
    }

    private fun secretKey(): SecretKey {
        val ks = KeyStore.getInstance(KEYSTORE).apply { load(null) }
        val existing = ks.getKey(KEY_ALIAS, null)
        if (existing is SecretKey) return existing
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, KEYSTORE)
        generator.init(
            KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT,
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build(),
        )
        return generator.generateKey()
    }

    private companion object {
        const val PREFS_NAME = "jal_secrets"
        const val KEY_PASSWORD = "device_password"
        const val KEYSTORE = "AndroidKeyStore"
        const val KEY_ALIAS = "jal_suraksha_credentials_v1"
        const val TRANSFORMATION = "AES/GCM/NoPadding"
        const val IV_BYTES = 12
        const val TAG_BITS = 128
    }
}
