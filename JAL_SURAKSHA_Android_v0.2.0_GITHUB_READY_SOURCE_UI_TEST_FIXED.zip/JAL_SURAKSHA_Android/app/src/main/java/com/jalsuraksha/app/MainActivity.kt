package com.jalsuraksha.app

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.jalsuraksha.app.data.ThemeMode
import com.jalsuraksha.app.ui.AppViewModel
import com.jalsuraksha.app.ui.JalApp
import com.jalsuraksha.app.ui.theme.JalTheme

class MainActivity : ComponentActivity() {

    private val viewModel: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Poll only while the app is visible. Stopping here also stops all network traffic.
        lifecycle.addObserver(
            LifecycleEventObserver { _, event ->
                when (event) {
                    Lifecycle.Event.ON_START -> viewModel.onAppForeground()
                    Lifecycle.Event.ON_STOP -> viewModel.onAppBackground()
                    else -> Unit
                }
            },
        )

        setContent {
            val ui by viewModel.ui.collectAsStateWithLifecycle()
            val dark = when (ui.settings.theme) {
                ThemeMode.SYSTEM -> isSystemInDarkTheme()
                ThemeMode.LIGHT -> false
                ThemeMode.DARK -> true
            }

            // Keep system bar icon colours in step with the in-app theme choice.
            DisposableEffect(dark) {
                enableEdgeToEdge(
                    statusBarStyle = SystemBarStyle.auto(Color.TRANSPARENT, Color.TRANSPARENT) { dark },
                    navigationBarStyle = SystemBarStyle.auto(LIGHT_SCRIM, DARK_SCRIM) { dark },
                )
                onDispose { }
            }

            JalTheme(darkTheme = dark) {
                JalApp(viewModel, ui)
            }
        }
    }

    private companion object {
        val LIGHT_SCRIM: Int = Color.argb(0xE6, 0xFF, 0xFF, 0xFF)
        val DARK_SCRIM: Int = Color.argb(0x80, 0x1B, 0x1B, 0x1B)
    }
}
