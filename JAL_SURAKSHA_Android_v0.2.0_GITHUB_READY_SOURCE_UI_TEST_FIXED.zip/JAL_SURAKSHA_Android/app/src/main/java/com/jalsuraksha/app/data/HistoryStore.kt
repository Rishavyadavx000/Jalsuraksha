package com.jalsuraksha.app.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale

/** One sample per line: epochMs,flowLpm,totalLiters,pump(1/0/?),rssiDbm. Empty field = no valid value. */
object SampleCsv {
    fun line(s: Sample): String {
        val pump = when (s.pump) {
            PumpState.ON -> "1"
            PumpState.OFF -> "0"
            PumpState.UNKNOWN -> "?"
        }
        return listOf(
            s.tMs.toString(),
            s.flowLpm?.let { number(it) } ?: "",
            s.totalLiters?.let { number(it) } ?: "",
            pump,
            s.rssiDbm?.toString() ?: "",
        ).joinToString(",")
    }

    fun parse(line: String): Sample? {
        val p = line.split(",")
        if (p.size < 5) return null
        val t = p[0].trim().toLongOrNull() ?: return null
        val pump = when (p[3].trim()) {
            "1" -> PumpState.ON
            "0" -> PumpState.OFF
            else -> PumpState.UNKNOWN
        }
        return Sample(
            tMs = t,
            flowLpm = p[1].trim().toDoubleOrNull(),
            totalLiters = p[2].trim().toDoubleOrNull(),
            pump = pump,
            rssiDbm = p[4].trim().toIntOrNull(),
        )
    }

    // Always Locale.US so a comma-decimal phone locale cannot corrupt the file.
    private fun number(v: Double): String = String.format(Locale.US, "%.3f", v)
}

/**
 * Local, app-collected history. These are the readings THIS APP received while it was running and
 * connected; they are not device-persisted measurements and gaps are never filled in.
 */
class HistoryStore(private val dir: File) {
    private val mutex = Mutex()
    private val file: File get() = File(dir, "samples.csv")

    suspend fun append(sample: Sample) {
        withContext(Dispatchers.IO) {
            mutex.withLock {
                dir.mkdirs()
                file.appendText(SampleCsv.line(sample) + "\n")
            }
        }
    }

    suspend fun loadSince(sinceMs: Long): List<Sample> = withContext(Dispatchers.IO) {
        mutex.withLock {
            val out = ArrayList<Sample>()
            if (file.exists()) {
                file.forEachLine { line ->
                    val s = SampleCsv.parse(line)
                    if (s != null && s.tMs >= sinceMs) {
                        out.add(s)
                    }
                }
            }
            out
        }
    }

    /** Drops samples older than the cutoff. Returns how many were removed. */
    suspend fun prune(olderThanMs: Long): Int = withContext(Dispatchers.IO) {
        mutex.withLock {
            var dropped = 0
            if (file.exists()) {
                val kept = ArrayList<String>()
                file.forEachLine { line ->
                    val s = SampleCsv.parse(line)
                    if (s != null && s.tMs >= olderThanMs) {
                        kept.add(line)
                    } else {
                        dropped += 1
                    }
                }
                if (dropped > 0) {
                    if (kept.isEmpty()) {
                        file.delete()
                    } else {
                        val tmp = File(dir, "samples.csv.tmp")
                        val content = kept.joinToString("\n", postfix = "\n")
                        tmp.writeText(content)
                        if (!tmp.renameTo(file)) {
                            file.writeText(content)
                            tmp.delete()
                        }
                    }
                }
            }
            dropped
        }
    }

    suspend fun clear() {
        withContext(Dispatchers.IO) {
            mutex.withLock {
                file.delete()
            }
        }
    }

    suspend fun count(): Int = withContext(Dispatchers.IO) {
        mutex.withLock {
            var n = 0
            if (file.exists()) {
                file.forEachLine { _ -> n += 1 }
            }
            n
        }
    }

    suspend fun sizeBytes(): Long = withContext(Dispatchers.IO) {
        mutex.withLock { if (file.exists()) file.length() else 0L }
    }
}
