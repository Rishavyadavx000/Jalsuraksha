package com.jalsuraksha.app

import android.app.Application
import com.jalsuraksha.app.data.DeviceApi
import com.jalsuraksha.app.data.EventStore
import com.jalsuraksha.app.data.HistoryStore
import com.jalsuraksha.app.data.SecretStore
import com.jalsuraksha.app.data.SettingsRepository
import java.io.File

/** Manual dependency container. Small enough that a DI framework would only add build risk. */
class AppContainer(app: Application) {
    val settingsRepository = SettingsRepository(app)
    val secretStore = SecretStore(app)
    val deviceApi = DeviceApi()
    private val dataDir = File(app.filesDir, "history")
    val historyStore = HistoryStore(dataDir)
    val eventStore = EventStore(dataDir)
}

class JalApplication : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}
