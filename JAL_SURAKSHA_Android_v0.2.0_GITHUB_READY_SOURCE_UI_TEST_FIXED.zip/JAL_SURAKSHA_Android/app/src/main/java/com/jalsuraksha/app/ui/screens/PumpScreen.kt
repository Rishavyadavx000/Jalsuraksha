package com.jalsuraksha.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.jalsuraksha.app.data.LinkState
import com.jalsuraksha.app.data.PumpState
import com.jalsuraksha.app.domain.Analytics
import com.jalsuraksha.app.domain.Formats
import com.jalsuraksha.app.ui.EventText
import com.jalsuraksha.app.ui.UiSnapshot
import com.jalsuraksha.app.ui.components.InfoBanner
import com.jalsuraksha.app.ui.components.JalCard
import com.jalsuraksha.app.ui.components.ScreenHeader
import com.jalsuraksha.app.ui.components.SectionTitle
import com.jalsuraksha.app.ui.components.Tone
import com.jalsuraksha.app.ui.theme.JalSpacing

@Composable
fun PumpScreen(
    ui: UiSnapshot,
    onRequestPump: (Boolean) -> Unit,
    onDismissResult: () -> Unit,
    onBack: () -> Unit,
) {
    val gapMs = maxOf(ui.settings.pollIntervalSec * 3_000L, 12_000L)
    val onSince = Analytics.observedOnStreakStartMs(ui.recent, gapMs)
    val pumpEvents = ui.events.filter { it.type in EventText.pumpTypes }.take(8)

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
    ) {
        ScreenHeader(title = "Pump control", subtitle = ui.settings.deviceName, onBack = onBack)
        Column(
            modifier = Modifier.padding(horizontal = JalSpacing.lg),
            verticalArrangement = Arrangement.spacedBy(JalSpacing.md),
        ) {
            PumpControlPanel(
                ui = ui,
                onRequest = onRequestPump,
                showChain = true,
                onDismissResult = onDismissResult,
            )

            JalCard {
                Text("Run time and limits", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(JalSpacing.sm))
                val running = ui.status?.pump == PumpState.ON && ui.link == LinkState.ONLINE
                StatRow(
                    "Current run",
                    when {
                        running && onSince != null ->
                            "${Formats.duration(ui.nowMs - onSince)} (since ${Formats.shortClock(onSince)}, measured by this app)"
                        running -> "Unavailable: this app did not see the run start"
                        ui.link != LinkState.ONLINE -> "Unavailable while not connected"
                        else -> "Pump is not running"
                    },
                )
                StatRow("Firmware run limit", "Not reported by the firmware API")
                Text(
                    "The app does not enforce a maximum run time and does not pretend to. A run limit is only trustworthy when the firmware enforces it.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            InfoBanner(
                tone = Tone.WARNING,
                title = "This is not an emergency stop",
                message = "If anything looks wrong, switch the pump off at its power supply. The OFF button needs a working network and a responding ESP32.",
                icon = Icons.Filled.Warning,
            )

            JalCard {
                Text("Before enabling pump control in firmware", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(JalSpacing.sm))
                val items = listOf(
                    "Switch the pump through a relay or driver rated for it, never directly from a GPIO pin.",
                    "Fit a flyback diode across a DC pump and a fuse in its supply.",
                    "Make sure the pump is OFF at boot and after any firmware reset.",
                    "Never run the pump dry, and keep a physical way to cut its power.",
                )
                for (item in items) {
                    Text(
                        "- $item",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(bottom = 4.dp),
                    )
                }
                Text(
                    "Full list: docs/HARDWARE_SAFETY_CHECKLIST.md",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            SectionTitle("Recent pump events")
            if (pumpEvents.isEmpty()) {
                Text(
                    "No pump events recorded yet.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            } else {
                for (e in pumpEvents) {
                    EventCard(event = e, showSuggestion = false)
                }
            }
            Spacer(Modifier.height(JalSpacing.lg))
        }
    }
}
