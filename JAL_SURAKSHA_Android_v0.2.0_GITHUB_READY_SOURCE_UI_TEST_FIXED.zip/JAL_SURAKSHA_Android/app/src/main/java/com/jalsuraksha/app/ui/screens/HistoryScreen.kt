package com.jalsuraksha.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.jalsuraksha.app.domain.BucketSize
import com.jalsuraksha.app.domain.FlowSeries
import com.jalsuraksha.app.domain.Formats
import com.jalsuraksha.app.ui.AppViewModel
import com.jalsuraksha.app.ui.ExportKind
import com.jalsuraksha.app.ui.HistoryRange
import com.jalsuraksha.app.ui.HistoryUi
import com.jalsuraksha.app.ui.UiSnapshot
import com.jalsuraksha.app.ui.components.BarChart
import com.jalsuraksha.app.ui.components.BarDatum
import com.jalsuraksha.app.ui.components.ChipRow
import com.jalsuraksha.app.ui.components.EmptyState
import com.jalsuraksha.app.ui.components.InfoBanner
import com.jalsuraksha.app.ui.components.JalCard
import com.jalsuraksha.app.ui.components.JalOutlinedButton
import com.jalsuraksha.app.ui.components.LineChart
import com.jalsuraksha.app.ui.components.ScreenHeader
import com.jalsuraksha.app.ui.components.SectionTitle
import com.jalsuraksha.app.ui.components.Tone
import com.jalsuraksha.app.ui.theme.JalSpacing
import kotlinx.coroutines.launch

@Composable
fun HistoryScreen(vm: AppViewModel, ui: UiSnapshot) {
    val history by vm.history.collectAsStateWithLifecycle()
    val ranges = HistoryRange.values().toList()
    var rangeIndex by rememberSaveable { mutableStateOf(1) }
    val range = ranges[rangeIndex]
    val unit = ui.settings.unit
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    LaunchedEffect(rangeIndex) { vm.loadHistory(range) }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
    ) {
        ScreenHeader(
            title = "History",
            subtitle = "Collected by this app while connected",
            trailing = {
                IconButton(onClick = {
                    scope.launch {
                        val intent = vm.buildExportIntent(ExportKind.SAMPLES, range)
                        if (intent != null) context.startActivity(intent)
                    }
                }) {
                    Icon(Icons.Filled.Share, contentDescription = "Export flow data as CSV")
                }
            },
        )
        Column(
            modifier = Modifier.padding(horizontal = JalSpacing.lg),
            verticalArrangement = Arrangement.spacedBy(JalSpacing.md),
        ) {
            ChipRow(
                options = ranges.mapIndexed { i, r -> r.label to i },
                selected = rangeIndex,
                onSelect = { rangeIndex = it },
            )

            when (val h = history) {
                is HistoryUi.Loading -> LinearProgressIndicator(Modifier.fillMaxWidth())
                is HistoryUi.Ready -> {
                    if (h.stats.sampleCount == 0) {
                        EmptyState(
                            icon = Icons.Filled.History,
                            title = "No history for this period",
                            message = "Readings are saved while the app is open and connected to the device. Keep the app running to build history.",
                        )
                    } else {
                        val shortRange = h.range.durationMs <= 24L * 3_600_000L
                        val label: (Long) -> String = { t ->
                            if (shortRange) Formats.shortClock(t) else Formats.dateTime(t)
                        }
                        val series = FlowSeries(
                            points = h.flow.points.map { it.copy(value = Formats.flowValue(it.value, unit)) },
                            maxGapMs = h.flow.maxGapMs,
                        )
                        JalCard {
                            Text("Average flow", style = MaterialTheme.typography.titleMedium)
                            Spacer(Modifier.height(JalSpacing.sm))
                            LineChart(
                                series = series,
                                startMs = h.startMs,
                                endMs = h.endMs,
                                unit = Formats.flowUnit(unit),
                                description = "Line chart of average flow over the last ${h.range.label}",
                                startLabel = label(h.startMs),
                                endLabel = label(h.endMs),
                                emptyText = "No flow readings in this period",
                            )
                        }

                        val perLabel = if (h.bucketSize == BucketSize.HOUR) "hour" else "day"
                        val bars = h.usage.map { slot ->
                            BarDatum(
                                label = if (h.bucketSize == BucketSize.HOUR) Formats.shortClock(slot.startMs) else Formats.day(slot.startMs),
                                value = slot.liters?.let { Formats.volumeValue(it, unit) },
                            )
                        }
                        JalCard {
                            Text(
                                "Volume per $perLabel (${Formats.volumeUnit(unit)})",
                                style = MaterialTheme.typography.titleMedium,
                            )
                            Spacer(Modifier.height(JalSpacing.sm))
                            BarChart(
                                bars = bars,
                                description = "Bar chart of observed volume per $perLabel",
                                emptyText = "No volume totals in this period",
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                "A dash means the app observed nothing in that $perLabel. It is not zero usage.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }

                        JalCard {
                            Text("Summary", style = MaterialTheme.typography.titleMedium)
                            Spacer(Modifier.height(JalSpacing.sm))
                            StatRow(
                                "Volume (observed)",
                                "${Formats.volume(h.stats.volumeLiters, unit)} ${Formats.volumeUnit(unit)}",
                            )
                            StatRow(
                                "Peak flow (averaged samples)",
                                "${Formats.flow(h.stats.peakFlowLpm, unit)} ${Formats.flowUnit(unit)}",
                            )
                            StatRow(
                                "Average flow",
                                "${Formats.flow(h.stats.avgFlowLpm, unit)} ${Formats.flowUnit(unit)}",
                            )
                            StatRow("Pump ON (observed)", Formats.duration(h.stats.pumpOnMs))
                            StatRow("Time observed", Formats.duration(h.stats.observedMs))
                            StatRow("Device restarts seen", h.stats.counterResets.toString())
                            StatRow("Samples", h.stats.sampleCount.toString())
                        }

                        InfoBanner(
                            tone = Tone.INFO,
                            title = "How these numbers are made",
                            message = "App-collected estimates. Only intervals while this app was connected are counted. Time the app was closed or offline is not counted and nothing is filled in.",
                        )

                        SectionTitle("Pump and connection events")
                        if (h.events.isEmpty()) {
                            Text(
                                "No pump or connection events in this period.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        } else {
                            for (e in h.events.take(12)) {
                                EventCard(event = e, showSuggestion = false)
                            }
                        }

                        JalOutlinedButton(
                            text = "Export flow data (CSV)",
                            onClick = {
                                scope.launch {
                                    val intent = vm.buildExportIntent(ExportKind.SAMPLES, h.range)
                                    if (intent != null) context.startActivity(intent)
                                }
                            },
                            icon = Icons.Filled.Share,
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                }
            }
            Spacer(Modifier.height(JalSpacing.lg))
        }
    }
}
