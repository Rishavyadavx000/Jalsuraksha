package com.jalsuraksha.app.ui.screens

import android.content.Intent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.jalsuraksha.app.data.ApiContract
import com.jalsuraksha.app.data.EndpointValidator
import com.jalsuraksha.app.data.shortLabel
import com.jalsuraksha.app.data.userMessage
import com.jalsuraksha.app.domain.Formats
import com.jalsuraksha.app.ui.AppViewModel
import com.jalsuraksha.app.ui.UiSnapshot
import com.jalsuraksha.app.ui.components.InfoBanner
import com.jalsuraksha.app.ui.components.JalCard
import com.jalsuraksha.app.ui.components.JalOutlinedButton
import com.jalsuraksha.app.ui.components.ScreenHeader
import com.jalsuraksha.app.ui.components.Tone
import com.jalsuraksha.app.ui.theme.JalSpacing

@Composable
fun DiagnosticsScreen(vm: AppViewModel, ui: UiSnapshot, onBack: () -> Unit) {
    var storage by remember { mutableStateOf("...") }
    LaunchedEffect(ui.events.size) { storage = vm.storageSummary() }
    val context = LocalContext.current

    val s = ui.settings
    val d = ui.device
    val st = ui.status
    val baseUrl = if (s.isConfigured) EndpointValidator.baseUrl(s.host, s.port) else "Not set"
    val network = vm.networkSummary()
    val keystoreNote = vm.secretStoreNote()

    val report = buildString {
        appendLine("JAL-SURAKSHA diagnostics (no passwords included)")
        appendLine("App version: ${vm.appVersion}")
        appendLine("Link state: ${Formats.linkLabel(ui.link)}")
        appendLine("Device address: $baseUrl")
        appendLine("Credentials: username ${if (s.username.isBlank()) "not set" else "set"}, password ${if (ui.hasPassword) "saved" else "not saved"}")
        appendLine("Last success: ${ui.ageMs?.let { Formats.age(it) } ?: "never"}")
        appendLine("Latency: ${d.lastLatencyMs?.let { "$it ms" } ?: "--"}")
        appendLine("Consecutive failures: ${d.consecutiveFailures}; polls ok/failed: ${d.successCount}/${d.failureCount}")
        appendLine("Last error: ${d.lastError?.shortLabel() ?: "none"}")
        appendLine("Pump: ${st?.pump?.name ?: "--"}; firmware permission: ${st?.pumpPermission?.name ?: "--"}")
        appendLine("Raw flow: ${st?.flowLpm?.let { String.format(java.util.Locale.US, "%.3f L/min", it) } ?: "--"}")
        appendLine("Raw total: ${st?.totalLiters?.let { String.format(java.util.Locale.US, "%.3f L", it) } ?: "--"}")
        appendLine("RSSI: ${st?.rssiDbm?.let { "$it dBm" } ?: "--"}")
        appendLine("Parser notes: ${if (st == null || st.warnings.isEmpty()) "none" else st.warnings.joinToString(" | ")}")
        appendLine("Paths: ${s.statusPath}, ${s.pumpOnPath}, ${s.pumpOffPath}")
        appendLine("Phone network: $network")
        appendLine("Storage: $storage")
        appendLine("Internal note: ${d.internalError ?: "none"}")
        appendLine("Keystore note: ${keystoreNote ?: "none"}")
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
    ) {
        ScreenHeader(title = "Diagnostics", subtitle = "Passwords are never shown", onBack = onBack)
        Column(
            modifier = Modifier.padding(horizontal = JalSpacing.lg),
            verticalArrangement = Arrangement.spacedBy(JalSpacing.md),
        ) {
            JalCard {
                Text("Connection", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(JalSpacing.sm))
                StatRow("State", Formats.linkLabel(ui.link))
                StatRow("Device address", baseUrl)
                StatRow(
                    "Credentials",
                    "${if (s.username.isBlank()) "no username" else "username set"}, ${if (ui.hasPassword) "password saved" else "no password"}",
                )
                StatRow("Last success", ui.ageMs?.let { Formats.age(it) } ?: "never")
                StatRow("Response time", d.lastLatencyMs?.let { "$it ms" } ?: "--")
                StatRow("Consecutive failures", d.consecutiveFailures.toString())
                StatRow("Polls ok / failed", "${d.successCount} / ${d.failureCount}")
                StatRow("Last error", d.lastError?.shortLabel() ?: "none")
                val err = d.lastError
                if (err != null) {
                    Text(
                        err.userMessage(),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            JalCard {
                Text("Latest reading from the device", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(JalSpacing.sm))
                if (st == null) {
                    Text(
                        "Nothing received yet.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                } else {
                    StatRow("Pump", st.pump.name)
                    StatRow("Firmware permission", st.pumpPermission.name)
                    StatRow("Flow (raw)", st.flowLpm?.let { String.format(java.util.Locale.US, "%.3f L/min", it) } ?: "--")
                    StatRow("Total (raw)", st.totalLiters?.let { String.format(java.util.Locale.US, "%.3f L", it) } ?: "--")
                    StatRow("Wi-Fi signal", st.rssiDbm?.let { "$it dBm" } ?: "--")
                    StatRow("Reported IP", st.ip ?: "--")
                    StatRow("Wi-Fi status", st.wifi ?: "--")
                    StatRow("Device id", st.deviceId ?: "not reported")
                    StatRow("API version", st.apiVersion?.toString() ?: "not reported")
                    if (st.warnings.isNotEmpty()) {
                        Spacer(Modifier.height(JalSpacing.sm))
                        Text("Parser notes", style = MaterialTheme.typography.titleSmall)
                        for (w in st.warnings) {
                            Text(
                                "- $w",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            }

            JalCard {
                Text("API contract in use", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(JalSpacing.sm))
                StatRow("Status", "GET ${s.statusPath}")
                StatRow("Pump ON", "POST ${s.pumpOnPath}")
                StatRow("Pump OFF", "POST ${s.pumpOffPath}")
                StatRow(
                    "JSON fields",
                    listOf(
                        ApiContract.KEY_PUMP,
                        ApiContract.KEY_PUMP_AVAILABLE,
                        ApiContract.KEY_FLOW_LPM,
                        ApiContract.KEY_TOTAL_LITERS,
                        ApiContract.KEY_RSSI,
                        ApiContract.KEY_WIFI,
                        ApiContract.KEY_IP,
                    ).joinToString(", "),
                )
                Spacer(Modifier.height(JalSpacing.sm))
                InfoBanner(
                    tone = Tone.WARNING,
                    title = "Not verified against your firmware",
                    message = "These routes and field names come from the V2 firmware draft. The actual .ino was not available when the app was built. See docs/API_CONTRACT.md.",
                )
            }

            JalCard {
                Text("This phone", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(JalSpacing.sm))
                StatRow("Active network", network)
                Text(
                    "If this phone is the hotspot that the ESP32 joined, Mobile data is normal. If both are on a router, the phone should show Wi-Fi on the same network as the ESP32.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(JalSpacing.sm))
                StatRow("App version", vm.appVersion)
                StatRow("Stored data", storage)
                StatRow("Internal note", d.internalError ?: "none")
                StatRow("Keystore note", keystoreNote ?: "none")
            }

            Row(horizontalArrangement = Arrangement.spacedBy(JalSpacing.md)) {
                JalOutlinedButton(
                    text = "Refresh now",
                    onClick = { vm.refreshNow() },
                    icon = Icons.Filled.Refresh,
                    modifier = Modifier.weight(1f),
                )
                JalOutlinedButton(
                    text = "Share report",
                    onClick = {
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_SUBJECT, "JAL-SURAKSHA diagnostics")
                            putExtra(Intent.EXTRA_TEXT, report)
                        }
                        context.startActivity(Intent.createChooser(send, "Share diagnostics"))
                    },
                    icon = Icons.Filled.Share,
                    modifier = Modifier.weight(1f),
                )
            }
            Spacer(Modifier.height(JalSpacing.lg))
        }
    }
}
