package com.jalsuraksha.app.domain

import com.jalsuraksha.app.data.ApiError
import com.jalsuraksha.app.data.DeviceSnapshot
import com.jalsuraksha.app.data.LinkState

/** Turns raw poll bookkeeping into the connection state the UI shows. Pure, so it is unit-tested. */
object LinkDeriver {
    const val OFFLINE_AFTER_FAILURES = 3

    fun derive(configured: Boolean, snap: DeviceSnapshot, nowMs: Long, staleAfterMs: Long): LinkState {
        if (!configured) return LinkState.NOT_CONFIGURED

        when (snap.lastError) {
            is ApiError.AuthRequired -> return LinkState.AUTH_REQUIRED
            is ApiError.BadResponse -> return LinkState.UNSUPPORTED
            else -> Unit
        }

        val last = snap.lastSuccessMs
        if (last == null) {
            return if (snap.consecutiveFailures == 0) LinkState.CONNECTING else LinkState.OFFLINE
        }

        val age = nowMs - last
        return when {
            age <= staleAfterMs -> LinkState.ONLINE
            snap.consecutiveFailures >= OFFLINE_AFTER_FAILURES -> LinkState.OFFLINE
            else -> LinkState.STALE
        }
    }
}
