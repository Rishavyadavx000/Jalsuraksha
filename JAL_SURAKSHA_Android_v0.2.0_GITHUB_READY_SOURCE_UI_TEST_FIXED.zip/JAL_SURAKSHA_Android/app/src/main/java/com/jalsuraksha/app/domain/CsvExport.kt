package com.jalsuraksha.app.domain

import com.jalsuraksha.app.data.EventRecord
import com.jalsuraksha.app.data.Sample
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/** Builds CSV text. Timestamps are written both as local time with offset and as UTC epoch milliseconds. */
object CsvExport {

    fun samples(samples: List<Sample>, factor: Double, tz: TimeZone = TimeZone.getDefault()): String {
        val fmt = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.US)
        fmt.timeZone = tz
        val sb = StringBuilder()
        sb.append("timestamp_local,epoch_ms,flow_lpm,total_liters,pump,rssi_dbm,calibration_factor_applied\n")
        for (s in samples.sortedBy { it.tMs }) {
            sb.append(fmt.format(Date(s.tMs))).append(',')
            sb.append(s.tMs).append(',')
            sb.append(s.flowLpm?.let { num(it * factor) } ?: "").append(',')
            sb.append(s.totalLiters?.let { num(it * factor) } ?: "").append(',')
            sb.append(s.pump.name).append(',')
            sb.append(s.rssiDbm?.toString() ?: "").append(',')
            sb.append(num(factor)).append('\n')
        }
        return sb.toString()
    }

    fun events(events: List<EventRecord>, tz: TimeZone = TimeZone.getDefault()): String {
        val fmt = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.US)
        fmt.timeZone = tz
        val sb = StringBuilder()
        sb.append("timestamp_local,epoch_ms,severity,type,acknowledged,message\n")
        for (e in events.sortedBy { it.tMs }) {
            sb.append(fmt.format(Date(e.tMs))).append(',')
            sb.append(e.tMs).append(',')
            sb.append(e.severity.name).append(',')
            sb.append(e.type.name).append(',')
            sb.append(e.acknowledged).append(',')
            sb.append(quote(e.message)).append('\n')
        }
        return sb.toString()
    }

    private fun quote(text: String): String = "\"" + text.replace("\"", "\"\"") + "\""

    private fun num(v: Double): String = String.format(Locale.US, "%.3f", v)
}
