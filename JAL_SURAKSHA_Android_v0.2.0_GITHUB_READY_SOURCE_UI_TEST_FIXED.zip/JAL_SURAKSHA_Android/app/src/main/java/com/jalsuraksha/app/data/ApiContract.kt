package com.jalsuraksha.app.data

import org.json.JSONException
import org.json.JSONObject

/**
 * The one place that describes the HTTP/JSON contract with the ESP32.
 *
 * These values come from the earlier V2 firmware DRAFT. They have NOT been verified against the
 * actual .ino (it was not supplied with this build). If the real sketch differs, change them here
 * (paths can also be edited under Settings > Device > Advanced) and update docs/API_CONTRACT.md.
 */
object ApiContract {
    const val DEFAULT_STATUS_PATH = "/api/status"
    const val DEFAULT_PUMP_ON_PATH = "/pump/on"
    const val DEFAULT_PUMP_OFF_PATH = "/pump/off"

    const val KEY_WIFI = "wifi"
    const val KEY_IP = "ip"
    const val KEY_RSSI = "rssi"
    const val KEY_PUMP = "pump"
    const val KEY_PUMP_AVAILABLE = "pumpAvailable"
    const val KEY_FLOW_LPM = "flowLpm"
    const val KEY_TOTAL_LITERS = "totalLiters"

    // Optional fields. Parsed only when present; the app never requires them.
    const val KEY_DEVICE_ID = "deviceId"
    const val KEY_API_VERSION = "apiVersion"

    const val MAX_SUPPORTED_API_VERSION = 1
    const val MAX_BODY_BYTES = 64L * 1024L
}

sealed interface ParseResult {
    data class Ok(val status: DeviceStatus) : ParseResult
    data class Invalid(val reason: String) : ParseResult
}

/**
 * Strict, typed parser for the status JSON. Invalid values become null/UNKNOWN with a warning;
 * the app never guesses alternative key names and never turns missing data into "OFF" or "0".
 */
object StatusParser {

    fun parse(body: String, nowMs: Long): ParseResult {
        val json = try {
            JSONObject(body)
        } catch (e: JSONException) {
            return ParseResult.Invalid("the response is not a JSON object")
        }

        val known = listOf(
            ApiContract.KEY_PUMP,
            ApiContract.KEY_PUMP_AVAILABLE,
            ApiContract.KEY_FLOW_LPM,
            ApiContract.KEY_TOTAL_LITERS,
        )
        if (known.none { json.has(it) }) {
            return ParseResult.Invalid("none of the expected status fields (pump, pumpAvailable, flowLpm, totalLiters) are present")
        }

        val warnings = mutableListOf<String>()

        val apiVersion = readApiVersion(json, warnings)
        if (apiVersion != null && apiVersion > ApiContract.MAX_SUPPORTED_API_VERSION) {
            return ParseResult.Invalid(
                "the device reports API version $apiVersion but this app supports up to ${ApiContract.MAX_SUPPORTED_API_VERSION}",
            )
        }

        var pump = readPump(json, warnings)
        val permission = readPermission(json, warnings)
        var contradictory = false
        if (pump == PumpState.ON && permission == FirmwarePumpPermission.LOCKED) {
            contradictory = true
            pump = PumpState.UNKNOWN
            warnings += "The device reports the pump ON while pump control is locked. The two values contradict each other, so the pump state is shown as unknown."
        }

        val status = DeviceStatus(
            wifi = readText(json, ApiContract.KEY_WIFI, warnings),
            ip = readText(json, ApiContract.KEY_IP, warnings),
            rssiDbm = readRssi(json, warnings),
            pump = pump,
            pumpPermission = permission,
            flowLpm = readNonNegative(json, ApiContract.KEY_FLOW_LPM, warnings),
            totalLiters = readNonNegative(json, ApiContract.KEY_TOTAL_LITERS, warnings),
            deviceId = readText(json, ApiContract.KEY_DEVICE_ID, warnings),
            apiVersion = apiVersion,
            receivedAtMs = nowMs,
            contradictoryPump = contradictory,
            warnings = warnings.toList(),
        )
        return ParseResult.Ok(status)
    }

    /** Returns null for an absent key or JSON null. */
    private fun JSONObject.rawValue(key: String): Any? {
        if (!has(key)) return null
        val v = opt(key)
        return if (v == null || v === JSONObject.NULL) null else v
    }

    private fun readNonNegative(json: JSONObject, key: String, warnings: MutableList<String>): Double? {
        val v = json.rawValue(key) ?: return null
        if (v !is Number) {
            warnings += "$key has the wrong type (expected a number) and was ignored."
            return null
        }
        val d = v.toDouble()
        if (!d.isFinite() || d < 0.0) {
            warnings += "$key is not a finite, non-negative number and was ignored."
            return null
        }
        return d
    }

    private fun readRssi(json: JSONObject, warnings: MutableList<String>): Int? {
        val v = json.rawValue(ApiContract.KEY_RSSI) ?: return null
        val d = (v as? Number)?.toDouble()
        if (d == null || !d.isFinite() || d != Math.rint(d) || d < -127.0 || d > 0.0) {
            warnings += "rssi is not a whole number between -127 and 0 dBm and was ignored."
            return null
        }
        return d.toInt()
    }

    private fun readApiVersion(json: JSONObject, warnings: MutableList<String>): Int? {
        val v = json.rawValue(ApiContract.KEY_API_VERSION) ?: return null
        val d = (v as? Number)?.toDouble()
        if (d == null || !d.isFinite() || d != Math.rint(d) || d < 0.0 || d > 1_000_000.0) {
            warnings += "apiVersion is not a valid whole number and was ignored."
            return null
        }
        return d.toInt()
    }

    private fun readText(json: JSONObject, key: String, warnings: MutableList<String>): String? {
        val v = json.rawValue(key) ?: return null
        if (v !is String) {
            warnings += "$key has the wrong type (expected text) and was ignored."
            return null
        }
        val clean = v.filter { !it.isISOControl() }.trim().take(64)
        return clean.ifEmpty { null }
    }

    private fun readPump(json: JSONObject, warnings: MutableList<String>): PumpState {
        return when (val v = json.rawValue(ApiContract.KEY_PUMP)) {
            null -> {
                warnings += "pump is missing, so the pump state is unknown."
                PumpState.UNKNOWN
            }
            is Boolean -> if (v) PumpState.ON else PumpState.OFF
            else -> {
                warnings += "pump has the wrong type (expected true or false), so the pump state is unknown."
                PumpState.UNKNOWN
            }
        }
    }

    private fun readPermission(json: JSONObject, warnings: MutableList<String>): FirmwarePumpPermission {
        return when (val v = json.rawValue(ApiContract.KEY_PUMP_AVAILABLE)) {
            null -> {
                warnings += "pumpAvailable is missing, so pump control stays locked in the app."
                FirmwarePumpPermission.UNKNOWN
            }
            is Boolean -> if (v) FirmwarePumpPermission.ENABLED else FirmwarePumpPermission.LOCKED
            else -> {
                warnings += "pumpAvailable has the wrong type (expected true or false), so pump control stays locked in the app."
                FirmwarePumpPermission.UNKNOWN
            }
        }
    }
}
