package com.jalsuraksha.app.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONException
import org.json.JSONObject
import java.io.File

/** One JSON object per line. JSONObject escapes newlines, so a message can never break the file format. */
object EventJson {
    fun toLine(e: EventRecord): String = JSONObject()
        .put("id", e.id)
        .put("t", e.tMs)
        .put("sev", e.severity.name)
        .put("type", e.type.name)
        .put("msg", e.message)
        .put("ack", e.acknowledged)
        .toString()

    fun parse(line: String): EventRecord? = try {
        val o = JSONObject(line)
        EventRecord(
            id = o.getLong("id"),
            tMs = o.getLong("t"),
            severity = Severity.valueOf(o.getString("sev")),
            type = EventType.valueOf(o.getString("type")),
            message = o.getString("msg"),
            acknowledged = o.optBoolean("ack", false),
        )
    } catch (e: JSONException) {
        null
    } catch (e: IllegalArgumentException) {
        null
    }
}

class EventStore(private val dir: File) {
    private val mutex = Mutex()
    private val file: File get() = File(dir, "events.jsonl")

    suspend fun loadAll(): List<EventRecord> = withContext(Dispatchers.IO) {
        mutex.withLock { readAll() }
    }

    suspend fun append(event: EventRecord) {
        withContext(Dispatchers.IO) {
            mutex.withLock {
                dir.mkdirs()
                file.appendText(EventJson.toLine(event) + "\n")
            }
        }
    }

    suspend fun replaceAll(events: List<EventRecord>) {
        withContext(Dispatchers.IO) {
            mutex.withLock {
                dir.mkdirs()
                if (events.isEmpty()) {
                    file.delete()
                } else {
                    val tmp = File(dir, "events.jsonl.tmp")
                    val content = events.joinToString("\n", postfix = "\n") { EventJson.toLine(it) }
                    tmp.writeText(content)
                    if (!tmp.renameTo(file)) {
                        file.writeText(content)
                        tmp.delete()
                    }
                }
            }
        }
    }

    suspend fun clear() {
        withContext(Dispatchers.IO) {
            mutex.withLock {
                file.delete()
            }
        }
    }

    private fun readAll(): List<EventRecord> {
        val out = ArrayList<EventRecord>()
        if (file.exists()) {
            file.forEachLine { line ->
                val e = EventJson.parse(line)
                if (e != null) {
                    out.add(e)
                }
            }
        }
        return out
    }
}
