package com.jalsuraksha.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.jalsuraksha.app.data.Severity
import com.jalsuraksha.app.ui.AppViewModel
import com.jalsuraksha.app.ui.ExportKind
import com.jalsuraksha.app.ui.HistoryRange
import com.jalsuraksha.app.ui.UiSnapshot
import com.jalsuraksha.app.ui.components.ChipRow
import com.jalsuraksha.app.ui.components.EmptyState
import com.jalsuraksha.app.ui.components.JalOutlinedButton
import com.jalsuraksha.app.ui.components.ScreenHeader
import com.jalsuraksha.app.ui.theme.JalSpacing
import kotlinx.coroutines.launch

@Composable
fun EventsScreen(vm: AppViewModel, ui: UiSnapshot) {
    var filter by rememberSaveable { mutableStateOf(0) }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    val filtered = when (filter) {
        1 -> ui.events.filter { it.severity != Severity.INFO }
        2 -> ui.events.filter { it.severity == Severity.INFO }
        else -> ui.events
    }
    val padding = Modifier.padding(horizontal = JalSpacing.lg)

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(JalSpacing.md),
        contentPadding = PaddingValues(bottom = JalSpacing.xl),
    ) {
        item {
            ScreenHeader(
                title = "Events",
                subtitle = "Advisory alerts and pump activity",
            )
        }
        item {
            ChipRow(
                options = listOf("All" to 0, "Needs attention" to 1, "Info" to 2),
                selected = filter,
                onSelect = { filter = it },
                modifier = padding,
            )
        }
        item {
            Row(modifier = padding.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(JalSpacing.sm)) {
                TextButton(
                    onClick = { vm.acknowledgeAll() },
                    enabled = ui.events.any { !it.acknowledged },
                ) { Text("Acknowledge all") }
                JalOutlinedButton(
                    text = "Export CSV",
                    onClick = {
                        scope.launch {
                            val intent = vm.buildExportIntent(ExportKind.EVENTS, HistoryRange.D30)
                            if (intent != null) context.startActivity(intent)
                        }
                    },
                    icon = Icons.Filled.Share,
                    enabled = ui.events.isNotEmpty(),
                )
            }
        }
        if (filtered.isEmpty()) {
            item {
                EmptyState(
                    icon = Icons.Filled.Notifications,
                    title = "No events here",
                    message = "Alerts appear when the device goes offline, readings look unusual or the pump state changes. They are advisory and only work while this app is open.",
                )
            }
        } else {
            items(filtered, key = { it.id }) { e ->
                EventCard(
                    event = e,
                    modifier = padding,
                    onAcknowledge = { vm.acknowledge(e.id) },
                )
            }
        }
        item {
            Text(
                "Events are heuristics based on what this app observes while it is open. They are not a safety system.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = padding,
            )
        }
    }
}
