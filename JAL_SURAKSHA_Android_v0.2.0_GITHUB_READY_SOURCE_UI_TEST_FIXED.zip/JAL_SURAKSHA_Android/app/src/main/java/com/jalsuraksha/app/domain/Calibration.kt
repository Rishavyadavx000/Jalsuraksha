package com.jalsuraksha.app.domain

/**
 * Flow-sensor calibration maths.
 *
 *   reported = pulses / firmwarePulsesPerLiter
 *   true     = pulses / truePulsesPerLiter
 *   factor   = measured / reported
 *   truePulsesPerLiter = firmwarePulsesPerLiter * reported / measured = firmwarePulsesPerLiter / factor
 *
 * The app cannot change the firmware's constant. It reports the suggested value so it can be edited
 * in the sketch, and can optionally apply the factor to what it DISPLAYS (app-side only).
 */
object Calibration {
    /** Draft assumption from the V2 firmware sketch, not verified against the real .ino. */
    const val DEFAULT_FIRMWARE_PULSES_PER_LITER = 450.0

    data class Result(
        val factor: Double,
        val suggestedPulsesPerLiter: Double,
        /** False when the correction is outside 0.5x..2x, which usually means a mistake rather than drift. */
        val plausible: Boolean,
    )

    fun compute(reportedLiters: Double, measuredLiters: Double, firmwarePulsesPerLiter: Double): Result? {
        if (!reportedLiters.isFinite() || !measuredLiters.isFinite() || !firmwarePulsesPerLiter.isFinite()) return null
        if (reportedLiters <= 0.0 || measuredLiters <= 0.0 || firmwarePulsesPerLiter <= 0.0) return null
        val factor = measuredLiters / reportedLiters
        return Result(
            factor = factor,
            suggestedPulsesPerLiter = firmwarePulsesPerLiter / factor,
            plausible = factor in 0.5..2.0,
        )
    }
}
