package com.jalsuraksha.app.ui

import com.jalsuraksha.app.data.EventType
import com.jalsuraksha.app.data.Severity
import com.jalsuraksha.app.ui.components.Tone

/** Human wording for events. Flow-based rules are described as heuristics because that is what they are. */
object EventText {

    fun title(type: EventType): String = when (type) {
        EventType.DEVICE_OFFLINE -> "Device offline"
        EventType.DEVICE_ONLINE -> "Connection restored"
        EventType.AUTH_FAILED -> "Credentials rejected"
        EventType.DATA_STALE -> "Data is stale"
        EventType.UNSUPPORTED_API -> "Unsupported response"
        EventType.SENSOR_UNAVAILABLE -> "Flow reading unavailable"
        EventType.NO_FLOW_WHILE_ON -> "No flow while the pump is ON"
        EventType.FLOW_WHILE_OFF -> "Flow while the pump is OFF"
        EventType.HIGH_FLOW -> "High flow"
        EventType.WEAK_SIGNAL -> "Weak Wi-Fi signal"
        EventType.DEVICE_REBOOT -> "Device restarted"
        EventType.PUMP_STATE_CHANGED -> "Pump state changed"
        EventType.PUMP_LOCK_CHANGED -> "Pump control permission changed"
        EventType.PUMP_STATUS_CONTRADICTION -> "Contradictory pump status"
        EventType.PUMP_COMMAND -> "Pump command"
        EventType.CALIBRATION_SAVED -> "Calibration saved"
    }

    fun suggestion(type: EventType): String? = when (type) {
        EventType.DEVICE_OFFLINE ->
            "Check the ESP32's power and that this phone is on the same Wi-Fi or hotspot. If the pump might be running, switch it off at its power supply."
        EventType.AUTH_FAILED ->
            "Update the username and password under Settings > Device."
        EventType.DATA_STALE ->
            "Do not rely on the displayed values until the connection recovers."
        EventType.UNSUPPORTED_API ->
            "Compare the firmware's status response with docs/API_CONTRACT.md."
        EventType.SENSOR_UNAVAILABLE ->
            "Check the flow sensor wiring and that the firmware reports flowLpm."
        EventType.NO_FLOW_WHILE_ON ->
            "Consider stopping the pump and checking the water supply, priming, blockages and sensor wiring."
        EventType.FLOW_WHILE_OFF ->
            "Inspect the plumbing for leaks, bypasses or gravity flow, and check the sensor for noise."
        EventType.HIGH_FLOW ->
            "Check for open outlets or a leak."
        EventType.WEAK_SIGNAL ->
            "Move the ESP32 or the phone closer, or reduce obstacles between them."
        EventType.DEVICE_REBOOT ->
            "Totals restarted. Compare readings across the restart with care."
        EventType.PUMP_LOCK_CHANGED ->
            "Pump permission is decided by the firmware and cannot be changed from this app."
        EventType.PUMP_STATUS_CONTRADICTION ->
            "Treat the pump state as unknown and check the hardware directly."
        EventType.DEVICE_ONLINE,
        EventType.PUMP_STATE_CHANGED,
        EventType.PUMP_COMMAND,
        EventType.CALIBRATION_SAVED,
        -> null
    }

    fun severityLabel(s: Severity): String = when (s) {
        Severity.INFO -> "Info"
        Severity.WARNING -> "Warning"
        Severity.CRITICAL -> "Critical"
    }

    fun severityTone(s: Severity): Tone = when (s) {
        Severity.INFO -> Tone.INFO
        Severity.WARNING -> Tone.WARNING
        Severity.CRITICAL -> Tone.DANGER
    }

    val pumpTypes: Set<EventType> = setOf(
        EventType.PUMP_STATE_CHANGED,
        EventType.PUMP_COMMAND,
        EventType.PUMP_LOCK_CHANGED,
        EventType.PUMP_STATUS_CONTRADICTION,
    )
}
