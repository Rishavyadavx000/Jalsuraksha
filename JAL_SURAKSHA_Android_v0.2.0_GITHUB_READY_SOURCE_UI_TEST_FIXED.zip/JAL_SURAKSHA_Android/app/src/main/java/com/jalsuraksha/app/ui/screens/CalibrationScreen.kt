package com.jalsuraksha.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import com.jalsuraksha.app.data.LinkState
import com.jalsuraksha.app.data.VolumeUnit
import com.jalsuraksha.app.domain.Calibration
import com.jalsuraksha.app.domain.Formats
import com.jalsuraksha.app.ui.AppViewModel
import com.jalsuraksha.app.ui.UiSnapshot
import com.jalsuraksha.app.ui.components.InfoBanner
import com.jalsuraksha.app.ui.components.JalButton
import com.jalsuraksha.app.ui.components.JalCard
import com.jalsuraksha.app.ui.components.JalOutlinedButton
import com.jalsuraksha.app.ui.components.ScreenHeader
import com.jalsuraksha.app.ui.components.SwitchRow
import com.jalsuraksha.app.ui.components.Tone
import com.jalsuraksha.app.ui.theme.JalShapes
import com.jalsuraksha.app.ui.theme.JalSpacing
import java.util.Locale

/**
 * Flow-sensor calibration. It never turns the pump on and never changes the firmware: it compares the
 * device's own total before and after a known volume, then reports the correction factor and the
 * pulses-per-litre value to put in the sketch. Applying the factor to what this app DISPLAYS is optional.
 */
@Composable
fun CalibrationScreen(vm: AppViewModel, ui: UiSnapshot, onBack: () -> Unit) {
    val settings = ui.settings
    val unit = settings.unit
    var step by rememberSaveable { mutableStateOf(0) }
    var firmwarePplText by rememberSaveable { mutableStateOf(trimNumber(settings.calFirmwarePpl)) }
    var startTotal by rememberSaveable { mutableStateOf<Double?>(null) }
    var reported by rememberSaveable { mutableStateOf<Double?>(null) }
    var measuredText by rememberSaveable { mutableStateOf("") }
    var applyCorrection by rememberSaveable { mutableStateOf(false) }
    var problem by remember { mutableStateOf<String?>(null) }

    // Raw device values: calibration must be computed from what the firmware reports, not from corrected display values.
    val rawTotal = ui.status?.totalLiters
    val live = ui.link == LinkState.ONLINE && rawTotal != null
    val firmwarePpl = firmwarePplText.replace(',', '.').toDoubleOrNull()

    Column(
        Modifier
            .fillMaxSize()
            .imePadding()
            .verticalScroll(rememberScrollState()),
    ) {
        ScreenHeader(title = "Calibration", subtitle = "Check the flow sensor against a known volume", onBack = onBack)
        Column(
            modifier = Modifier.padding(horizontal = JalSpacing.lg),
            verticalArrangement = Arrangement.spacedBy(JalSpacing.md),
        ) {
            if (problem != null) {
                InfoBanner(Tone.WARNING, "Cannot continue", problem ?: "", icon = Icons.Filled.Warning)
            }

            when (step) {
                0 -> {
                    JalCard {
                        Text("What you need", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(JalSpacing.sm))
                        Text(
                            "A container of known volume, such as a marked bucket or measuring jug, and a way to run that water through the sensor with your normal procedure. " +
                                "This wizard never switches the pump on.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Spacer(Modifier.height(JalSpacing.md))
                        OutlinedTextField(
                            value = firmwarePplText,
                            onValueChange = { firmwarePplText = it },
                            label = { Text("Pulses per litre set in the firmware") },
                            supportingText = {
                                Text("The draft sketch used 450. Check the constant in your .ino; the app cannot read it.")
                            },
                            isError = firmwarePpl == null || firmwarePpl <= 0.0,
                            singleLine = true,
                            shape = JalShapes.field,
                            modifier = Modifier.fillMaxWidth(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal, imeAction = ImeAction.Done),
                        )
                    }
                    if (settings.calDateMs > 0L) {
                        InfoBanner(
                            tone = Tone.INFO,
                            title = "A calibration is already saved",
                            message = "Factor x${String.format(Locale.US, "%.3f", settings.calFactor)} on ${Formats.dateTime(settings.calDateMs)}" +
                                if (settings.calApplied) ", applied to displayed values." else ", not applied.",
                            icon = Icons.Filled.Info,
                            action = {
                                TextButton(onClick = {
                                    vm.updateSettings {
                                        it.copy(calFactor = 1.0, calApplied = false, calDateMs = 0L, calSuggestedPpl = 0.0)
                                    }
                                }) { Text("Remove saved calibration") }
                            },
                        )
                    }
                    JalButton(
                        text = "Start",
                        onClick = { problem = null; step = 1 },
                        enabled = firmwarePpl != null && firmwarePpl > 0.0,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }

                1 -> {
                    JalCard {
                        Text("1. Record the starting total", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(JalSpacing.sm))
                        StatRow("Device total now", if (rawTotal != null) "${Formats.volume(rawTotal, VolumeUnit.LITERS)} L" else "--")
                        Text(
                            "Make sure no water is flowing, then record the reading.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    if (!live) {
                        InfoBanner(Tone.WARNING, "Needs a live connection", "Wait until the device shows Online with a total volume.", icon = Icons.Filled.Warning)
                    }
                    JalButton(
                        text = "Record start",
                        onClick = {
                            startTotal = rawTotal
                            problem = null
                            step = 2
                        },
                        enabled = live,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    TextButton(onClick = { step = 0 }) { Text("Back") }
                }

                2 -> {
                    JalCard {
                        Text("2. Run the known volume through the sensor", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(JalSpacing.sm))
                        Text(
                            "Pass exactly your measured amount of water through the sensor, then stop and press Record end. " +
                                "Use at least a few litres for a useful result.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Spacer(Modifier.height(JalSpacing.sm))
                        StatRow("Started at", startTotal?.let { "${Formats.volume(it, VolumeUnit.LITERS)} L" } ?: "--")
                        StatRow("Device total now", if (rawTotal != null) "${Formats.volume(rawTotal, VolumeUnit.LITERS)} L" else "--")
                    }
                    if (!live) {
                        InfoBanner(Tone.WARNING, "Needs a live connection", "Wait until the device shows Online with a total volume.", icon = Icons.Filled.Warning)
                    }
                    JalButton(
                        text = "Record end",
                        onClick = {
                            val start = startTotal
                            val end = rawTotal
                            if (start == null || end == null) {
                                problem = "No starting or ending reading is available."
                            } else if (end < start - 0.05) {
                                problem = "The device total went backwards, so it probably restarted. Start again."
                                startTotal = null
                                step = 1
                            } else if (end - start < 0.05) {
                                problem = "The device total did not increase. Run water through the sensor and try again."
                            } else {
                                reported = end - start
                                problem = null
                                step = 3
                            }
                        },
                        enabled = live,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    TextButton(onClick = { startTotal = null; step = 1 }) { Text("Start over") }
                }

                else -> {
                    val reportedLiters = reported
                    val measuredInput = measuredText.replace(',', '.').toDoubleOrNull()
                    val measuredLiters = measuredInput?.let {
                        if (unit == VolumeUnit.LITERS) it else it * Formats.LITERS_PER_US_GALLON
                    }
                    val result = if (reportedLiters != null && measuredLiters != null && firmwarePpl != null) {
                        Calibration.compute(reportedLiters, measuredLiters, firmwarePpl)
                    } else {
                        null
                    }

                    JalCard {
                        Text("3. Enter what you actually measured", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(JalSpacing.sm))
                        StatRow(
                            "Device reported",
                            reportedLiters?.let { "${Formats.volume(it, unit)} ${Formats.volumeUnit(unit)}" } ?: "--",
                        )
                        Spacer(Modifier.height(JalSpacing.sm))
                        OutlinedTextField(
                            value = measuredText,
                            onValueChange = { measuredText = it },
                            label = { Text("Measured volume (${Formats.volumeUnit(unit)})") },
                            singleLine = true,
                            isError = measuredText.isNotBlank() && measuredInput == null,
                            shape = JalShapes.field,
                            modifier = Modifier.fillMaxWidth(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal, imeAction = ImeAction.Done),
                        )
                    }

                    if (result != null) {
                        JalCard {
                            Text("Result", style = MaterialTheme.typography.titleMedium)
                            Spacer(Modifier.height(JalSpacing.sm))
                            StatRow("Correction factor", "x${String.format(Locale.US, "%.3f", result.factor)}")
                            StatRow("Firmware now", "${trimNumber(firmwarePpl ?: 0.0)} pulses/L")
                            StatRow("Suggested for the sketch", "${String.format(Locale.US, "%.1f", result.suggestedPulsesPerLiter)} pulses/L")
                            Spacer(Modifier.height(JalSpacing.sm))
                            Text(
                                "To fix this at the source, set the pulses-per-litre constant in your sketch to the suggested value and re-flash. The app cannot change the firmware.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        if (!result.plausible) {
                            InfoBanner(
                                tone = Tone.WARNING,
                                title = "That is a large correction",
                                message = "A factor outside 0.5 to 2 usually means a measuring or wiring mistake rather than sensor drift. Repeat the test before saving.",
                                icon = Icons.Filled.Warning,
                            )
                        }
                        JalCard {
                            SwitchRow(
                                label = "Apply the correction to values shown in this app",
                                description = "Display only. Readings stored by the device are unchanged. You can switch this off later.",
                                checked = applyCorrection,
                                onChange = { applyCorrection = it },
                            )
                        }
                        JalButton(
                            text = "Save result",
                            onClick = {
                                vm.saveCalibration(
                                    factor = result.factor,
                                    firmwarePpl = firmwarePpl ?: Calibration.DEFAULT_FIRMWARE_PULSES_PER_LITER,
                                    suggestedPpl = result.suggestedPulsesPerLiter,
                                    apply = applyCorrection,
                                )
                                onBack()
                            },
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                    JalOutlinedButton(
                        text = "Start over",
                        onClick = {
                            startTotal = null
                            reported = null
                            measuredText = ""
                            step = 1
                        },
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            }
            Spacer(Modifier.height(JalSpacing.lg))
        }
    }
}

private fun trimNumber(v: Double): String =
    if (v == Math.rint(v)) String.format(Locale.US, "%.0f", v) else String.format(Locale.US, "%.2f", v)
