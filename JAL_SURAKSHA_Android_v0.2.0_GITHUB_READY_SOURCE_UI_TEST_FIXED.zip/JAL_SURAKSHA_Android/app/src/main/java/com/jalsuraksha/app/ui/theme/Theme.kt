package com.jalsuraksha.app.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/*
 * Design tokens. Direction: calm, instrument-like, deep navy with a single teal accent.
 * Status is never colour-only (every chip carries text and usually an icon).
 * Radii follow hierarchy: hero 28, card 20, tile/button 14, field 12, chip pill.
 */

private val LightScheme = lightColorScheme(
    primary = Color(0xFF0F766E),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFCCFBF1),
    onPrimaryContainer = Color(0xFF042F2E),
    secondary = Color(0xFF123A63),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFDCE8F5),
    onSecondaryContainer = Color(0xFF0B2A4A),
    tertiary = Color(0xFF0369A1),
    onTertiary = Color.White,
    background = Color(0xFFF2F6FA),
    onBackground = Color(0xFF0B1F33),
    surface = Color.White,
    onSurface = Color(0xFF0B1F33),
    surfaceVariant = Color(0xFFE6EDF4),
    onSurfaceVariant = Color(0xFF475569),
    outline = Color(0xFF7B8DA1),
    outlineVariant = Color(0xFFD5DEE8),
    error = Color(0xFFB91C1C),
    onError = Color.White,
    errorContainer = Color(0xFFFEE2E2),
    onErrorContainer = Color(0xFF7F1D1D),
)

private val DarkScheme = darkColorScheme(
    primary = Color(0xFF5EEAD4),
    onPrimary = Color(0xFF042F2E),
    primaryContainer = Color(0xFF115E59),
    onPrimaryContainer = Color(0xFFCCFBF1),
    secondary = Color(0xFF9CC3EA),
    onSecondary = Color(0xFF0B2A4A),
    secondaryContainer = Color(0xFF16406B),
    onSecondaryContainer = Color(0xFFDCE8F5),
    tertiary = Color(0xFF7DD3FC),
    onTertiary = Color(0xFF082F49),
    background = Color(0xFF071526),
    onBackground = Color(0xFFE6EEF6),
    surface = Color(0xFF0E2238),
    onSurface = Color(0xFFE6EEF6),
    surfaceVariant = Color(0xFF16304B),
    onSurfaceVariant = Color(0xFFA9BBCE),
    outline = Color(0xFF5F7790),
    outlineVariant = Color(0xFF244560),
    error = Color(0xFFFCA5A5),
    onError = Color(0xFF450A0A),
    errorContainer = Color(0xFF7F1D1D),
    onErrorContainer = Color(0xFFFEE2E2),
)

/** Semantic colours Material 3 has no slot for. */
@Immutable
class JalColors(
    val success: Color,
    val successContainer: Color,
    val onSuccessContainer: Color,
    val warning: Color,
    val warningContainer: Color,
    val onWarningContainer: Color,
    val info: Color,
    val infoContainer: Color,
    val onInfoContainer: Color,
    val danger: Color,
    val dangerContainer: Color,
    val onDangerContainer: Color,
    val neutralContainer: Color,
    val onNeutralContainer: Color,
    val hero: Color,
    val onHero: Color,
    val onHeroMuted: Color,
)

private val LightJalColors = JalColors(
    success = Color(0xFF15803D),
    successContainer = Color(0xFFDCFCE7),
    onSuccessContainer = Color(0xFF14532D),
    warning = Color(0xFFB45309),
    warningContainer = Color(0xFFFEF3C7),
    onWarningContainer = Color(0xFF78350F),
    info = Color(0xFF0369A1),
    infoContainer = Color(0xFFE0F2FE),
    onInfoContainer = Color(0xFF0C4A6E),
    danger = Color(0xFFB91C1C),
    dangerContainer = Color(0xFFFEE2E2),
    onDangerContainer = Color(0xFF7F1D1D),
    neutralContainer = Color(0xFFE6EDF4),
    onNeutralContainer = Color(0xFF334155),
    hero = Color(0xFF0B2A4A),
    onHero = Color.White,
    onHeroMuted = Color(0xFFB6C8DB),
)

private val DarkJalColors = JalColors(
    success = Color(0xFF4ADE80),
    successContainer = Color(0xFF0F3D26),
    onSuccessContainer = Color(0xFFBBF7D0),
    warning = Color(0xFFFBBF24),
    warningContainer = Color(0xFF4A3205),
    onWarningContainer = Color(0xFFFDE68A),
    info = Color(0xFF38BDF8),
    infoContainer = Color(0xFF0C3550),
    onInfoContainer = Color(0xFFBAE6FD),
    danger = Color(0xFFF87171),
    dangerContainer = Color(0xFF4C1111),
    onDangerContainer = Color(0xFFFECACA),
    neutralContainer = Color(0xFF1B3047),
    onNeutralContainer = Color(0xFFCBD5E1),
    hero = Color(0xFF0B2A4A),
    onHero = Color.White,
    onHeroMuted = Color(0xFFB6C8DB),
)

private val LocalJalColors = staticCompositionLocalOf { LightJalColors }

object Jal {
    val colors: JalColors
        @Composable
        @ReadOnlyComposable
        get() = LocalJalColors.current
}

object JalShapes {
    val hero = RoundedCornerShape(28.dp)
    val card = RoundedCornerShape(20.dp)
    val tile = RoundedCornerShape(14.dp)
    val field = RoundedCornerShape(12.dp)
    val pill = RoundedCornerShape(50)
}

object JalSpacing {
    val xs = 4.dp
    val sm = 8.dp
    val md = 12.dp
    val lg = 16.dp
    val xl = 24.dp
    val xxl = 32.dp
}

private val JalTypography = Typography(
    headlineLarge = TextStyle(fontSize = 30.sp, lineHeight = 36.sp, fontWeight = FontWeight.SemiBold),
    headlineMedium = TextStyle(fontSize = 24.sp, lineHeight = 30.sp, fontWeight = FontWeight.SemiBold),
    titleLarge = TextStyle(fontSize = 20.sp, lineHeight = 26.sp, fontWeight = FontWeight.SemiBold),
    titleMedium = TextStyle(fontSize = 16.sp, lineHeight = 22.sp, fontWeight = FontWeight.SemiBold),
    titleSmall = TextStyle(fontSize = 14.sp, lineHeight = 20.sp, fontWeight = FontWeight.SemiBold),
    bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 24.sp),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 20.sp),
    bodySmall = TextStyle(fontSize = 12.sp, lineHeight = 17.sp),
    labelLarge = TextStyle(fontSize = 14.sp, lineHeight = 20.sp, fontWeight = FontWeight.Medium),
    labelMedium = TextStyle(fontSize = 12.sp, lineHeight = 16.sp, fontWeight = FontWeight.Medium),
    labelSmall = TextStyle(fontSize = 11.sp, lineHeight = 14.sp, fontWeight = FontWeight.Medium),
)

/** Big readings. Tabular numerals keep digits from jittering as values change. */
val MetricStyle = TextStyle(
    fontSize = 38.sp,
    lineHeight = 42.sp,
    fontWeight = FontWeight.Bold,
    fontFeatureSettings = "tnum",
)

private val JalMaterialShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(20.dp),
    extraLarge = RoundedCornerShape(28.dp),
)

@Composable
fun JalTheme(darkTheme: Boolean, content: @Composable () -> Unit) {
    CompositionLocalProvider(LocalJalColors provides (if (darkTheme) DarkJalColors else LightJalColors)) {
        MaterialTheme(
            colorScheme = if (darkTheme) DarkScheme else LightScheme,
            typography = JalTypography,
            shapes = JalMaterialShapes,
            content = content,
        )
    }
}
