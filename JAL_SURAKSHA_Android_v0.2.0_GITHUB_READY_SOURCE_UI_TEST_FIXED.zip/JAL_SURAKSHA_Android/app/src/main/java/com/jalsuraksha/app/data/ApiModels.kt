package com.jalsuraksha.app.data

/** Transport and protocol failures, kept separate from device-reported state. */
sealed interface ApiError {
    data object NotConfigured : ApiError
    data class InvalidEndpoint(val reason: String) : ApiError
    data object Timeout : ApiError
    data class Unreachable(val detail: String) : ApiError
    data object AuthRequired : ApiError
    data class HttpError(val code: Int, val bodySnippet: String) : ApiError
    data class BadResponse(val reason: String) : ApiError
}

sealed interface ApiOutcome<out T> {
    data class Success<out T>(val value: T, val httpCode: Int, val latencyMs: Long) : ApiOutcome<T>
    data class Failure(val error: ApiError) : ApiOutcome<Nothing>
}

/** Plain-language explanation that tells the person what to check next. */
fun ApiError.userMessage(): String = when (this) {
    is ApiError.NotConfigured ->
        "No device address is saved yet. Add the ESP32 address first."
    is ApiError.InvalidEndpoint ->
        reason
    is ApiError.Timeout ->
        "The device did not answer in time. Check that the ESP32 is powered and that the phone and the ESP32 are on the same Wi-Fi or hotspot."
    is ApiError.Unreachable ->
        "Could not reach the device ($detail). If the hotspot or router restarted, the ESP32 may have a new IP address."
    is ApiError.AuthRequired ->
        "The device is reachable but rejected the username or password (HTTP 401)."
    is ApiError.HttpError ->
        "The device answered with HTTP $code."
    is ApiError.BadResponse ->
        "The device answered, but not with a status the app understands: $reason."
}

/** Short label for the diagnostics screen and CSV/event text. */
fun ApiError.shortLabel(): String = when (this) {
    is ApiError.NotConfigured -> "Not configured"
    is ApiError.InvalidEndpoint -> "Invalid address"
    is ApiError.Timeout -> "Timeout"
    is ApiError.Unreachable -> "Unreachable"
    is ApiError.AuthRequired -> "Authentication required (401)"
    is ApiError.HttpError -> "HTTP $code"
    is ApiError.BadResponse -> "Unsupported response"
}
