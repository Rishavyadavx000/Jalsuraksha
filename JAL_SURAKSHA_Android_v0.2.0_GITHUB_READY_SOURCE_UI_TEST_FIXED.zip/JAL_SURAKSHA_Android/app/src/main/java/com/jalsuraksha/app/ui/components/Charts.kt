package com.jalsuraksha.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.jalsuraksha.app.domain.ChartPoint
import com.jalsuraksha.app.domain.FlowSeries
import java.util.Locale

/**
 * Time-series line chart that draws ONLY real points. When two neighbouring points are further
 * apart than series.maxGapMs the line is broken, so missing data looks missing rather than flat.
 */
@Composable
fun LineChart(
    series: FlowSeries,
    startMs: Long,
    endMs: Long,
    unit: String,
    description: String,
    startLabel: String,
    endLabel: String,
    modifier: Modifier = Modifier,
    height: Dp = 180.dp,
    emptyText: String = "Waiting for sensor data",
) {
    val line = MaterialTheme.colorScheme.primary
    val grid = MaterialTheme.colorScheme.outlineVariant
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    val points = series.points
    val maxValue = points.maxOfOrNull { it.value } ?: 0.0
    val yMax = niceCeil(maxOf(1.0, maxValue * 1.15))

    Column(modifier.semantics { contentDescription = description }) {
        Box(Modifier.fillMaxWidth().height(height)) {
            Canvas(Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height
                for (i in 0..3) {
                    val y = h * i / 3f
                    drawLine(grid, Offset(0f, y), Offset(w, y), strokeWidth = 1f)
                }
                if (points.isEmpty() || endMs <= startMs) return@Canvas

                val span = (endMs - startMs).toFloat()
                fun xOf(t: Long): Float = (((t - startMs).toFloat()) / span).coerceIn(0f, 1f) * w
                fun yOf(v: Double): Float = h - (v / yMax).toFloat().coerceIn(0f, 1f) * h

                val segments = ArrayList<ArrayList<ChartPoint>>()
                var prevT = Long.MIN_VALUE
                for (p in points) {
                    val startNew = segments.isEmpty() || p.tMs - prevT > series.maxGapMs
                    if (startNew) {
                        segments.add(ArrayList())
                    }
                    segments.last().add(p)
                    prevT = p.tMs
                }

                for (seg in segments) {
                    if (seg.size == 1) {
                        drawCircle(line, radius = 3.dp.toPx(), center = Offset(xOf(seg[0].tMs), yOf(seg[0].value)))
                    } else {
                        val path = Path()
                        path.moveTo(xOf(seg[0].tMs), yOf(seg[0].value))
                        for (i in 1 until seg.size) {
                            path.lineTo(xOf(seg[i].tMs), yOf(seg[i].value))
                        }
                        val fill = Path()
                        fill.addPath(path)
                        fill.lineTo(xOf(seg.last().tMs), h)
                        fill.lineTo(xOf(seg.first().tMs), h)
                        fill.close()
                        drawPath(
                            fill,
                            brush = Brush.verticalGradient(
                                listOf(line.copy(alpha = 0.22f), line.copy(alpha = 0f)),
                            ),
                        )
                        drawPath(
                            path,
                            color = line,
                            style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round),
                        )
                    }
                }
            }
            Text(
                String.format(Locale.getDefault(), "%.0f %s", yMax, unit),
                style = MaterialTheme.typography.labelSmall,
                color = muted,
                modifier = Modifier.align(Alignment.TopStart),
            )
            Text(
                "0",
                style = MaterialTheme.typography.labelSmall,
                color = muted,
                modifier = Modifier.align(Alignment.BottomStart),
            )
            if (points.isEmpty()) {
                Text(
                    emptyText,
                    style = MaterialTheme.typography.bodyMedium,
                    color = muted,
                    modifier = Modifier.align(Alignment.Center),
                )
            }
        }
        Row(
            modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(startLabel, style = MaterialTheme.typography.labelSmall, color = muted)
            Text(endLabel, style = MaterialTheme.typography.labelSmall, color = muted)
        }
    }
}

/** A bar with value == null means "nothing was observed in this slot" and is drawn as a thin dash, not as 0. */
data class BarDatum(val label: String, val value: Double?)

@Composable
fun BarChart(
    bars: List<BarDatum>,
    description: String,
    modifier: Modifier = Modifier,
    height: Dp = 140.dp,
    emptyText: String = "No usage recorded yet",
) {
    val barColor = MaterialTheme.colorScheme.primary
    val missing = MaterialTheme.colorScheme.outlineVariant
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    val maxValue = niceCeil(maxOf(1.0, (bars.maxOfOrNull { it.value ?: 0.0 } ?: 0.0) * 1.1))
    val anyData = bars.any { it.value != null }

    Column(modifier.semantics { contentDescription = description }) {
        Box(Modifier.fillMaxWidth().height(height)) {
            Canvas(Modifier.fillMaxSize()) {
                val n = bars.size.coerceAtLeast(1)
                val slot = size.width / n
                val barW = slot * 0.62f
                val minBar = 2.dp.toPx()
                bars.forEachIndexed { i, b ->
                    val x = slot * i + (slot - barW) / 2f
                    val v = b.value
                    if (v == null) {
                        drawRoundRect(
                            color = missing,
                            topLeft = Offset(x, size.height - 3.dp.toPx()),
                            size = Size(barW, 3.dp.toPx()),
                            cornerRadius = CornerRadius(2.dp.toPx()),
                        )
                    } else {
                        val bh = (((v / maxValue).toFloat()).coerceIn(0f, 1f) * size.height).coerceAtLeast(minBar)
                        drawRoundRect(
                            color = barColor,
                            topLeft = Offset(x, size.height - bh),
                            size = Size(barW, bh),
                            cornerRadius = CornerRadius(4.dp.toPx()),
                        )
                    }
                }
            }
            if (!anyData) {
                Text(
                    emptyText,
                    style = MaterialTheme.typography.bodyMedium,
                    color = muted,
                    modifier = Modifier.align(Alignment.Center),
                )
            }
        }
        if (bars.size >= 2) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text(bars.first().label, style = MaterialTheme.typography.labelSmall, color = muted)
                Text(bars[bars.size / 2].label, style = MaterialTheme.typography.labelSmall, color = muted)
                Text(bars.last().label, style = MaterialTheme.typography.labelSmall, color = muted)
            }
        }
    }
}

private fun niceCeil(v: Double): Double {
    if (v <= 1.0) return 1.0
    val pow = Math.pow(10.0, Math.floor(Math.log10(v)))
    val f = v / pow
    val nice = when {
        f <= 1.0 -> 1.0
        f <= 2.0 -> 2.0
        f <= 5.0 -> 5.0
        else -> 10.0
    }
    return nice * pow
}
