package com.jalsuraksha.app.ui.screens

import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.jalsuraksha.app.data.EventRecord
import com.jalsuraksha.app.data.Severity
import com.jalsuraksha.app.domain.Formats
import com.jalsuraksha.app.ui.EventText
import com.jalsuraksha.app.ui.components.JalCard
import com.jalsuraksha.app.ui.components.StatusChip
import com.jalsuraksha.app.ui.theme.JalShapes

@Composable
internal fun EventCard(
    event: EventRecord,
    modifier: Modifier = Modifier,
    onAcknowledge: (() -> Unit)? = null,
    showSuggestion: Boolean = true,
) {
    val icon = when (event.severity) {
        Severity.INFO -> Icons.Filled.Info
        Severity.WARNING -> Icons.Filled.Warning
        Severity.CRITICAL -> Icons.Filled.Error
    }
    JalCard(modifier = modifier, shape = JalShapes.tile) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            StatusChip(EventText.severityLabel(event.severity), EventText.severityTone(event.severity), icon = icon)
            Spacer(Modifier.weight(1f))
            Text(
                Formats.dateTime(event.tMs),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Spacer(Modifier.height(8.dp))
        Text(EventText.title(event.type), style = MaterialTheme.typography.titleSmall)
        Spacer(Modifier.height(2.dp))
        Text(
            event.message,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        val suggestion = if (showSuggestion) EventText.suggestion(event.type) else null
        if (suggestion != null) {
            Spacer(Modifier.height(6.dp))
            Text("What to do: $suggestion", style = MaterialTheme.typography.bodySmall)
        }
        if (event.acknowledged) {
            Spacer(Modifier.height(6.dp))
            Row {
                Text(
                    "Acknowledged",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.width(4.dp))
            }
        } else if (onAcknowledge != null) {
            TextButton(onClick = onAcknowledge) { Text("Acknowledge") }
        }
    }
}
