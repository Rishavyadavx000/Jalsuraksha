package com.jalsuraksha.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import com.jalsuraksha.app.data.AppSettings
import com.jalsuraksha.app.data.EndpointValidator
import com.jalsuraksha.app.ui.DeviceInput
import com.jalsuraksha.app.ui.TestKind
import com.jalsuraksha.app.ui.TestUi
import com.jalsuraksha.app.ui.components.InfoBanner
import com.jalsuraksha.app.ui.components.JalButton
import com.jalsuraksha.app.ui.components.JalOutlinedButton
import com.jalsuraksha.app.ui.components.Tone
import com.jalsuraksha.app.ui.theme.JalShapes
import com.jalsuraksha.app.ui.theme.JalSpacing

/**
 * Connection profile form shared by onboarding and Settings > Device. The password field is held
 * only in memory (never saved in instance state) and a blank field means "keep the saved password".
 */
@Composable
fun DeviceSetupForm(
    initial: AppSettings,
    hasPassword: Boolean,
    test: TestUi,
    saveLabel: String,
    saveError: String?,
    onTest: (DeviceInput) -> Unit,
    onSave: (DeviceInput) -> Unit,
    modifier: Modifier = Modifier,
) {
    var name by rememberSaveable { mutableStateOf(initial.deviceName) }
    var address by rememberSaveable { mutableStateOf(initial.addressDisplay) }
    var username by rememberSaveable { mutableStateOf(initial.username) }
    var password by remember { mutableStateOf("") }
    var showPassword by remember { mutableStateOf(false) }
    var clearPassword by remember { mutableStateOf(false) }
    var advanced by rememberSaveable { mutableStateOf(false) }
    var statusPath by rememberSaveable { mutableStateOf(initial.statusPath) }
    var pumpOnPath by rememberSaveable { mutableStateOf(initial.pumpOnPath) }
    var pumpOffPath by rememberSaveable { mutableStateOf(initial.pumpOffPath) }

    val parsed = EndpointValidator.parse(address)
    val addressError = if (address.isNotBlank() && parsed is EndpointValidator.Result.Invalid) parsed.reason else null
    val addressOk = parsed is EndpointValidator.Result.Valid
    val pathsOk = listOf(statusPath, pumpOnPath, pumpOffPath).all { EndpointValidator.isValidPath(it) }
    val canSubmit = addressOk && pathsOk

    fun buildInput() = DeviceInput(
        name = name,
        address = address,
        username = username,
        password = if (password.isEmpty()) null else password,
        clearPassword = clearPassword,
        statusPath = statusPath,
        pumpOnPath = pumpOnPath,
        pumpOffPath = pumpOffPath,
    )

    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(JalSpacing.md)) {
        OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            label = { Text("Device name") },
            singleLine = true,
            shape = JalShapes.field,
            modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
        )

        OutlinedTextField(
            value = address,
            onValueChange = { address = it },
            label = { Text("ESP32 address") },
            placeholder = { Text("192.168.1.50") },
            singleLine = true,
            isError = addressError != null,
            supportingText = {
                Text(addressError ?: "An IPv4 address on your network, or a .local name. Add :port if it is not 80.")
            },
            shape = JalShapes.field,
            modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Next),
        )

        OutlinedTextField(
            value = username,
            onValueChange = { username = it },
            label = { Text("Username (if your sketch uses Basic Auth)") },
            singleLine = true,
            shape = JalShapes.field,
            modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
        )

        OutlinedTextField(
            value = password,
            onValueChange = {
                password = it
                if (it.isNotEmpty()) clearPassword = false
            },
            label = { Text("Password") },
            singleLine = true,
            visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
            trailingIcon = {
                IconButton(onClick = { showPassword = !showPassword }) {
                    Icon(
                        if (showPassword) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                        contentDescription = if (showPassword) "Hide password" else "Show password",
                    )
                }
            },
            supportingText = {
                Text(
                    when {
                        clearPassword -> "The saved password will be removed when you save."
                        hasPassword -> "A password is saved. Leave this blank to keep it."
                        else -> "Stored encrypted on this phone, never in plain text."
                    },
                )
            },
            shape = JalShapes.field,
            modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done),
        )

        if (hasPassword) {
            Row {
                if (clearPassword) {
                    TextButton(onClick = { clearPassword = false }) { Text("Keep the saved password") }
                } else {
                    TextButton(onClick = {
                        clearPassword = true
                        password = ""
                    }) { Text("Remove the saved password") }
                }
            }
        }

        InfoBanner(
            tone = Tone.INFO,
            title = "Plain HTTP on your own network",
            message = "The ESP32 speaks HTTP, which is not encrypted. Anyone on the same Wi-Fi could read the password. Use a network you trust and never expose the ESP32 to the internet.",
            icon = Icons.Filled.Lock,
        )

        TextButton(onClick = { advanced = !advanced }) {
            Text(if (advanced) "Hide advanced API paths" else "Advanced: API paths")
        }
        if (advanced) {
            Text(
                "Change these only if your firmware uses different routes. They must start with /.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            PathField("Status path", statusPath) { statusPath = it }
            PathField("Pump ON path", pumpOnPath) { pumpOnPath = it }
            PathField("Pump OFF path", pumpOffPath) { pumpOffPath = it }
        }

        JalOutlinedButton(
            text = if (test is TestUi.Running) "Testing..." else "Test connection",
            onClick = { onTest(buildInput()) },
            enabled = canSubmit && test !is TestUi.Running,
            modifier = Modifier.fillMaxWidth(),
        )

        when (test) {
            is TestUi.Idle -> Unit
            is TestUi.Running -> LinearProgressIndicator(Modifier.fillMaxWidth())
            is TestUi.Done -> TestResultBanner(test)
        }

        if (saveError != null) {
            InfoBanner(
                tone = Tone.DANGER,
                title = "Could not save",
                message = saveError,
                icon = Icons.Filled.Error,
            )
        }

        JalButton(
            text = saveLabel,
            onClick = { onSave(buildInput()) },
            enabled = canSubmit,
            modifier = Modifier.fillMaxWidth(),
        )
        Text(
            "You can save without a successful test, for example while the ESP32 is switched off.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(JalSpacing.lg))
    }
}

@Composable
private fun PathField(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = true,
        isError = !EndpointValidator.isValidPath(value),
        shape = JalShapes.field,
        modifier = Modifier.fillMaxWidth(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Next),
    )
}

@Composable
private fun TestResultBanner(result: TestUi.Done) {
    val tone = when (result.kind) {
        TestKind.OK -> Tone.SUCCESS
        TestKind.AUTH, TestKind.UNSUPPORTED -> Tone.WARNING
        TestKind.TIMEOUT, TestKind.UNREACHABLE, TestKind.INVALID, TestKind.HTTP -> Tone.DANGER
    }
    val title = when (result.kind) {
        TestKind.OK -> "Connected"
        TestKind.AUTH -> "Credentials needed"
        TestKind.UNSUPPORTED -> "Not recognised"
        TestKind.TIMEOUT -> "No answer"
        TestKind.UNREACHABLE -> "Cannot reach the device"
        TestKind.INVALID -> "Check the address"
        TestKind.HTTP -> "Unexpected reply"
    }
    val icon = when (tone) {
        Tone.SUCCESS -> Icons.Filled.CheckCircle
        Tone.WARNING -> Icons.Filled.Warning
        Tone.DANGER -> Icons.Filled.Error
        else -> Icons.Filled.Info
    }
    InfoBanner(
        tone = tone,
        title = title,
        message = if (result.detail != null) "${result.message}\n${result.detail}" else result.message,
        icon = icon,
    )
}
