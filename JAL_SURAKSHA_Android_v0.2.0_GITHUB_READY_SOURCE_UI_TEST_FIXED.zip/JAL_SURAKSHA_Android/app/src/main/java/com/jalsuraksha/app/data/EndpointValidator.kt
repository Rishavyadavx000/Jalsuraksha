package com.jalsuraksha.app.data

import java.net.InetAddress

/**
 * Accepts only local-network device addresses: private IPv4 literals (10/8, 172.16/12, 192.168/16,
 * 169.254/16) or mDNS-style names ending in ".local". Public hosts are refused so control requests
 * can never leave the local network. The same check runs again inside DeviceApi.
 */
object EndpointValidator {

    sealed interface Result {
        data class Valid(val host: String, val port: Int) : Result
        data class Invalid(val reason: String) : Result
    }

    const val DEFAULT_PORT = 80

    private val IPV4_SHAPE = Regex("""^\d{1,3}(\.\d{1,3}){3}$""")
    private val LOCAL_NAME =
        Regex("""^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?(\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)*\.local$""")

    fun parse(input: String): Result {
        var text = input.trim()
        if (text.isEmpty()) {
            return Result.Invalid("Enter the ESP32 address, for example 192.168.1.50.")
        }

        val schemeEnd = text.indexOf("://")
        if (schemeEnd >= 0) {
            val scheme = text.substring(0, schemeEnd).lowercase()
            if (scheme != "http") {
                return Result.Invalid("Only http:// is supported. The ESP32 serves plain local HTTP.")
            }
            text = text.substring(schemeEnd + 3)
        }

        if ('@' in text) {
            return Result.Invalid("Do not put a username or password in the address. Use the credential fields instead.")
        }

        val pathStart = text.indexOfFirst { it == '/' || it == '?' || it == '#' }
        if (pathStart >= 0) {
            if (text.substring(pathStart) != "/") {
                return Result.Invalid("Enter only the address and an optional port. API paths are set under Advanced.")
            }
            text = text.substring(0, pathStart)
        }

        if (text.startsWith("[")) {
            return Result.Invalid("IPv6 addresses are not supported.")
        }

        var port = DEFAULT_PORT
        val colon = text.lastIndexOf(':')
        if (colon >= 0) {
            port = text.substring(colon + 1).toIntOrNull()
                ?: return Result.Invalid("The port must be a number between 1 and 65535.")
            if (port !in 1..65535) {
                return Result.Invalid("The port must be a number between 1 and 65535.")
            }
            text = text.substring(0, colon)
        }

        val host = text.lowercase()
        if (host.isEmpty()) {
            return Result.Invalid("Enter the ESP32 address, for example 192.168.1.50.")
        }

        if (IPV4_SHAPE.matches(host)) {
            val octets = ipv4Octets(host)
                ?: return Result.Invalid("That is not a valid IPv4 address.")
            if (!isPrivate(octets)) {
                return Result.Invalid("$host is not a private network address. JAL-SURAKSHA only talks to devices on your local network.")
            }
            return Result.Valid(host, port)
        }

        if (!LOCAL_NAME.matches(host)) {
            return Result.Invalid("Use an IPv4 address such as 192.168.1.50, or a name ending in .local.")
        }
        return Result.Valid(host, port)
    }

    fun isAllowedHost(host: String): Boolean {
        val h = host.lowercase()
        return if (IPV4_SHAPE.matches(h)) isPrivateIpv4(h) else LOCAL_NAME.matches(h)
    }

    fun isPrivateIpv4(host: String): Boolean {
        val octets = ipv4Octets(host) ?: return false
        return isPrivate(octets)
    }

    /** Used by LocalOnlyDns to reject names that resolve to public addresses. */
    fun isLocalAddress(address: InetAddress): Boolean =
        address.isSiteLocalAddress || address.isLinkLocalAddress

    fun baseUrl(host: String, port: Int): String =
        if (port == DEFAULT_PORT) "http://$host" else "http://$host:$port"

    fun displayAddress(host: String, port: Int): String =
        if (port == DEFAULT_PORT) host else "$host:$port"

    /** Paths must be absolute, short and free of whitespace, query strings and fragments. */
    fun isValidPath(path: String): Boolean =
        path.length in 2..64 &&
            path.startsWith("/") &&
            path.none { it.isWhitespace() || it == '?' || it == '#' }

    private fun isPrivate(o: IntArray): Boolean = when {
        o[0] == 10 -> true
        o[0] == 172 && o[1] in 16..31 -> true
        o[0] == 192 && o[1] == 168 -> true
        o[0] == 169 && o[1] == 254 -> true
        else -> false
    }

    private fun ipv4Octets(host: String): IntArray? {
        if (!IPV4_SHAPE.matches(host)) return null
        val parts = host.split(".")
        val out = IntArray(4)
        for (i in 0 until 4) {
            val p = parts[i]
            if (p.length > 1 && p.startsWith("0")) return null
            val n = p.toIntOrNull() ?: return null
            if (n !in 0..255) return null
            out[i] = n
        }
        return out
    }
}
