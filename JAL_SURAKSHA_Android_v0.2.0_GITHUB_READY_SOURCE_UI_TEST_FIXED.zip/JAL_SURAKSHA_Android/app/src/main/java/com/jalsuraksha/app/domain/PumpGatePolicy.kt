package com.jalsuraksha.app.domain

import com.jalsuraksha.app.data.DeviceStatus
import com.jalsuraksha.app.data.FirmwarePumpPermission
import com.jalsuraksha.app.data.LinkState
import com.jalsuraksha.app.data.PumpState

/** One link of the interlock chain shown on the pump screen. */
data class GateCheck(val label: String, val passed: Boolean, val detail: String)

data class PumpControlAvailability(
    val canRequestOn: Boolean,
    val canRequestOff: Boolean,
    val onBlockedReason: String?,
    val offBlockedReason: String?,
    val checks: List<GateCheck>,
)

/**
 * Decides whether the UI may offer a pump request. This is a convenience gate only: the firmware
 * remains the sole authority (it re-checks pumpAvailable and its own limits on every request).
 *
 * Every request first needs the app-side switch (Settings > Pump requests), which stays OFF until the
 * person has verified the firmware API, because the API contract was not verified against the real sketch.
 * ON then also needs fresh data, firmware permission ENABLED and a known pump state.
 * OFF then needs fresh data and a pump not already reported OFF.
 */
object PumpGatePolicy {

    fun evaluate(
        link: LinkState,
        status: DeviceStatus?,
        commandInProgress: Boolean,
        requestsEnabled: Boolean,
    ): PumpControlAvailability {
        val fresh = link == LinkState.ONLINE && status != null
        val permission = status?.pumpPermission ?: FirmwarePumpPermission.UNKNOWN
        val pump = status?.pump ?: PumpState.UNKNOWN

        val checks = listOf(
            GateCheck(
                label = "App",
                passed = requestsEnabled,
                detail = if (requestsEnabled) "Requests on" else "Requests off",
            ),
            GateCheck(
                label = "Connection",
                passed = fresh,
                detail = if (fresh) "Fresh data" else Formats.linkLabel(link),
            ),
            GateCheck(
                label = "Firmware",
                passed = permission == FirmwarePumpPermission.ENABLED,
                detail = when (permission) {
                    FirmwarePumpPermission.ENABLED -> "Control enabled"
                    FirmwarePumpPermission.LOCKED -> "Control locked"
                    FirmwarePumpPermission.UNKNOWN -> "Permission unknown"
                },
            ),
            GateCheck(
                label = "Pump state",
                passed = pump != PumpState.UNKNOWN,
                detail = if (pump == PumpState.UNKNOWN) "State unknown" else "Reported ${pump.name}",
            ),
        )

        val onReason: String? = when {
            commandInProgress -> "A command is already in progress."
            !requestsEnabled ->
                "Pump requests are switched off in this app. Turn them on in Settings only after you have verified the firmware API and tested the pump on the bench."
            !fresh -> "Waiting for fresh data from the device."
            permission == FirmwarePumpPermission.LOCKED ->
                "Pump control is locked by the firmware. It cannot be unlocked from this app."
            permission == FirmwarePumpPermission.UNKNOWN ->
                "The firmware did not confirm that pump control is enabled."
            pump == PumpState.UNKNOWN ->
                "The pump state is unknown, so a start request could not be confirmed."
            pump == PumpState.ON -> "The device already reports the pump ON."
            else -> null
        }

        val offReason: String? = when {
            commandInProgress -> "A command is already in progress."
            !requestsEnabled ->
                "Pump requests are switched off in this app. Use the pump's physical switch or disconnect its power."
            !fresh -> "The device cannot be reached. Use the physical switch or disconnect pump power."
            pump == PumpState.OFF -> "The device already reports the pump OFF."
            else -> null
        }

        return PumpControlAvailability(
            canRequestOn = onReason == null,
            canRequestOff = offReason == null,
            onBlockedReason = onReason,
            offBlockedReason = offReason,
            checks = checks,
        )
    }
}
