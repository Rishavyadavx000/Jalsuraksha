package com.jalsuraksha.app.domain

import com.jalsuraksha.app.data.ApiError
import com.jalsuraksha.app.data.DeviceSnapshot
import com.jalsuraksha.app.data.LinkState
import org.junit.Assert.assertEquals
import org.junit.Test

class LinkDeriverTest {
    private val stale = 10_000L

    private fun snap(lastSuccess: Long?, failures: Int, error: ApiError? = null) =
        DeviceSnapshot(lastSuccessMs = lastSuccess, consecutiveFailures = failures, lastError = error)

    @Test
    fun notConfigured() {
        assertEquals(LinkState.NOT_CONFIGURED, LinkDeriver.derive(false, snap(null, 0), 0L, stale))
    }

    @Test
    fun waitingForFirstReadingIsConnecting() {
        assertEquals(LinkState.CONNECTING, LinkDeriver.derive(true, snap(null, 0), 5_000L, stale))
    }

    @Test
    fun neverConnectedWithFailuresIsOffline() {
        assertEquals(LinkState.OFFLINE, LinkDeriver.derive(true, snap(null, 2, ApiError.Timeout), 5_000L, stale))
    }

    @Test
    fun recentSuccessIsOnlineEvenAfterOneFailure() {
        assertEquals(LinkState.ONLINE, LinkDeriver.derive(true, snap(100_000L, 1, ApiError.Timeout), 105_000L, stale))
    }

    @Test
    fun oldSuccessWithFewFailuresIsStale() {
        assertEquals(LinkState.STALE, LinkDeriver.derive(true, snap(100_000L, 1, ApiError.Timeout), 120_000L, stale))
        assertEquals(LinkState.STALE, LinkDeriver.derive(true, snap(100_000L, 0), 120_000L, stale))
    }

    @Test
    fun oldSuccessWithManyFailuresIsOffline() {
        assertEquals(LinkState.OFFLINE, LinkDeriver.derive(true, snap(100_000L, 3, ApiError.Timeout), 130_000L, stale))
    }

    @Test
    fun authErrorOverridesFreshness() {
        assertEquals(LinkState.AUTH_REQUIRED, LinkDeriver.derive(true, snap(100_000L, 1, ApiError.AuthRequired), 101_000L, stale))
    }

    @Test
    fun badResponseIsUnsupported() {
        assertEquals(LinkState.UNSUPPORTED, LinkDeriver.derive(true, snap(null, 1, ApiError.BadResponse("x")), 1_000L, stale))
    }
}
