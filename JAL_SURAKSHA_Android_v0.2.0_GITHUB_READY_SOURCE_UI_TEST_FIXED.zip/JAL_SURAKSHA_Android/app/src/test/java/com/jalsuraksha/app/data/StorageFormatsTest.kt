package com.jalsuraksha.app.data

import com.jalsuraksha.app.domain.CsvExport
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Locale
import java.util.TimeZone

class StorageFormatsTest {

    @Test
    fun sampleCsvRoundTrips() {
        val s = Sample(1_700_000_000_000L, 1.234, 56.789, PumpState.ON, -61)
        val back = SampleCsv.parse(SampleCsv.line(s))!!
        assertEquals(s.tMs, back.tMs)
        assertEquals(1.234, back.flowLpm!!, 1e-9)
        assertEquals(56.789, back.totalLiters!!, 1e-9)
        assertEquals(PumpState.ON, back.pump)
        assertEquals(-61, back.rssiDbm)
    }

    @Test
    fun missingValuesStayMissingAfterARoundTrip() {
        val s = Sample(5L, null, null, PumpState.UNKNOWN, null)
        val back = SampleCsv.parse(SampleCsv.line(s))!!
        assertNull(back.flowLpm)
        assertNull(back.totalLiters)
        assertNull(back.rssiDbm)
        assertEquals(PumpState.UNKNOWN, back.pump)
    }

    @Test
    fun corruptLinesAreSkippedNotFatal() {
        assertNull(SampleCsv.parse(""))
        assertNull(SampleCsv.parse("abc,1,2,0,-50"))
        assertNull(SampleCsv.parse("1,2"))
    }

    @Test
    fun numbersAreWrittenWithADotWhateverThePhoneLocale() {
        val old = Locale.getDefault()
        try {
            Locale.setDefault(Locale.GERMANY)
            val line = SampleCsv.line(Sample(1L, 1.5, 2.25, PumpState.OFF, -50))
            assertTrue(line, line.contains("1.500") && line.contains("2.250"))
            assertTrue(!line.contains("1,500"))
        } finally {
            Locale.setDefault(old)
        }
    }

    @Test
    fun eventJsonSurvivesQuotesAndNewlines() {
        val e = EventRecord(7L, 99L, Severity.WARNING, EventType.HIGH_FLOW, "He said \"stop\"\nthen left, with a comma", true)
        val back = EventJson.parse(EventJson.toLine(e))
        assertEquals(e, back)
        assertTrue(!EventJson.toLine(e).contains('\n'))
    }

    @Test
    fun corruptEventLinesAreSkipped() {
        assertNull(EventJson.parse("not json"))
        assertNull(EventJson.parse("""{"id":1,"t":2,"sev":"NOPE","type":"HIGH_FLOW","msg":"x"}"""))
    }

    @Test
    fun csvExportScalesByTheCalibrationFactorAndQuotesMessages() {
        val tz = TimeZone.getTimeZone("UTC")
        val csv = CsvExport.samples(listOf(Sample(0L, 2.0, 10.0, PumpState.OFF, -50)), 1.5, tz)
        val lines = csv.trim().split("\n")
        assertEquals(2, lines.size)
        assertTrue(lines[0].startsWith("timestamp_local,epoch_ms,flow_lpm"))
        assertTrue(lines[1].contains(",3.000,15.000,OFF,-50,1.500"))

        val events = CsvExport.events(listOf(EventRecord(1L, 0L, Severity.INFO, EventType.PUMP_COMMAND, "a \"quoted\", message")), tz)
        assertTrue(events.contains("\"a \"\"quoted\"\", message\""))
    }

    @Test
    fun settingsAreClampedSoABrokenPreferenceCannotBreakPolling() {
        val s = AppSettings(pollIntervalSec = 0, port = 99_999, retentionDays = 1_000, weakSignalDbm = 10).sanitized()
        assertEquals(1, s.pollIntervalSec)
        assertEquals(65_535, s.port)
        assertEquals(90, s.retentionDays)
        assertEquals(-40, s.weakSignalDbm)
    }

    @Test
    fun calibrationIsAppliedOnlyWhenOptedInAndPlausible() {
        assertEquals(1.0, AppSettings(calFactor = 1.2, calApplied = false).calibrationFactorInUse, 1e-9)
        assertEquals(1.2, AppSettings(calFactor = 1.2, calApplied = true).calibrationFactorInUse, 1e-9)
        assertEquals(1.0, AppSettings(calFactor = 9.0, calApplied = true).calibrationFactorInUse, 1e-9)
    }
}
