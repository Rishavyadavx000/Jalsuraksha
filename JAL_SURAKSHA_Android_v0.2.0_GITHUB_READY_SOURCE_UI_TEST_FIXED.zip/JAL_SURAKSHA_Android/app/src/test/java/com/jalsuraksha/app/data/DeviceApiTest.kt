package com.jalsuraksha.app.data

import kotlinx.coroutines.runBlocking
import okhttp3.Credentials
import okhttp3.OkHttpClient
import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

/** Runs against a local MockWebServer. The host policy is relaxed only here, because loopback is not a LAN address. */
class DeviceApiTest {

    private lateinit var server: MockWebServer
    private val api = DeviceApi(client = OkHttpClient(), hostPolicy = { true })

    @Before
    fun setUp() {
        server = MockWebServer()
        server.start()
    }

    @After
    fun tearDown() {
        server.shutdown()
    }

    private fun endpoint(creds: DeviceCredentials? = null) =
        Endpoint(server.hostName, server.port, "/api/status", "/pump/on", "/pump/off", creds)

    @Test
    fun fetchStatusSendsBasicAuthAndParsesJson() {
        server.enqueue(MockResponse().setBody("""{"pump":false,"pumpAvailable":true,"flowLpm":1.5,"totalLiters":3.0}"""))
        val result = runBlocking { api.fetchStatus(endpoint(DeviceCredentials("admin", "secret"))) }
        assertTrue("was $result", result is ApiOutcome.Success)
        val request = server.takeRequest()
        assertEquals("GET", request.method)
        assertEquals("/api/status", request.path)
        assertEquals(Credentials.basic("admin", "secret"), request.getHeader("Authorization"))
    }

    @Test
    fun noAuthHeaderWhenCredentialsAreMissing() {
        server.enqueue(MockResponse().setBody("""{"pump":false,"pumpAvailable":false}"""))
        runBlocking { api.fetchStatus(endpoint(null)) }
        assertNull(server.takeRequest().getHeader("Authorization"))
    }

    @Test
    fun unauthorizedMapsToAuthRequired() {
        server.enqueue(MockResponse().setResponseCode(401).addHeader("WWW-Authenticate", "Basic realm=\"jal\""))
        val result = runBlocking { api.fetchStatus(endpoint(DeviceCredentials("a", "b"))) }
        assertTrue(result is ApiOutcome.Failure && result.error is ApiError.AuthRequired)
    }

    @Test
    fun serverErrorMapsToHttpError() {
        server.enqueue(MockResponse().setResponseCode(500).setBody("boom"))
        val result = runBlocking { api.fetchStatus(endpoint()) }
        assertTrue(result is ApiOutcome.Failure)
        val error = (result as ApiOutcome.Failure).error
        assertTrue(error is ApiError.HttpError && error.code == 500)
    }

    @Test
    fun garbageBodyMapsToBadResponse() {
        server.enqueue(MockResponse().setBody("<html>not the device</html>"))
        val result = runBlocking { api.fetchStatus(endpoint()) }
        assertTrue(result is ApiOutcome.Failure && result.error is ApiError.BadResponse)
    }

    @Test
    fun pumpOnIsAPostToTheConfiguredPath() {
        server.enqueue(MockResponse().setResponseCode(200))
        val result = runBlocking { api.sendPump(endpoint(DeviceCredentials("a", "b")), on = true) }
        assertTrue(result is ApiOutcome.Success)
        val request = server.takeRequest()
        assertEquals("POST", request.method)
        assertEquals("/pump/on", request.path)
    }

    @Test
    fun pumpRejectionIsReportedNotHidden() {
        server.enqueue(MockResponse().setResponseCode(403).setBody("pump control disabled"))
        val result = runBlocking { api.sendPump(endpoint(), on = true) }
        assertTrue(result is ApiOutcome.Failure)
        val error = (result as ApiOutcome.Failure).error
        assertTrue(error is ApiError.HttpError && error.code == 403)
    }

    @Test
    fun publicHostsAreRefusedBeforeAnyRequestIsMade() {
        val strict = DeviceApi(client = OkHttpClient())
        val ep = Endpoint("8.8.8.8", 80, "/api/status", "/pump/on", "/pump/off", null)
        val result = runBlocking { strict.fetchStatus(ep) }
        assertTrue(result is ApiOutcome.Failure && result.error is ApiError.InvalidEndpoint)
        assertEquals(0, server.requestCount)
    }

    @Test
    fun credentialsNeverAppearInToString() {
        val creds = DeviceCredentials("admin", "hunter2")
        assertTrue(!creds.toString().contains("hunter2"))
        assertTrue(!endpoint(creds).toString().contains("hunter2"))
    }
}
