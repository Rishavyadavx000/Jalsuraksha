package com.jalsuraksha.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class StatusParserTest {

    private fun ok(body: String): DeviceStatus {
        val r = StatusParser.parse(body, 1_000L)
        assertTrue("expected Ok but was $r", r is ParseResult.Ok)
        return (r as ParseResult.Ok).status
    }

    private fun invalid(body: String): String {
        val r = StatusParser.parse(body, 1_000L)
        assertTrue("expected Invalid but was $r", r is ParseResult.Invalid)
        return (r as ParseResult.Invalid).reason
    }

    @Test
    fun parsesAFullStatus() {
        val s = ok("""{"wifi":"Connected","ip":"192.168.1.50","rssi":-61,"pump":false,"pumpAvailable":true,"flowLpm":1.5,"totalLiters":12.5}""")
        assertEquals(PumpState.OFF, s.pump)
        assertEquals(FirmwarePumpPermission.ENABLED, s.pumpPermission)
        assertEquals(1.5, s.flowLpm!!, 1e-9)
        assertEquals(12.5, s.totalLiters!!, 1e-9)
        assertEquals(-61, s.rssiDbm)
        assertEquals("192.168.1.50", s.ip)
        assertEquals(1_000L, s.receivedAtMs)
        assertTrue(s.warnings.isEmpty())
    }

    @Test
    fun missingPumpIsUnknownNeverOff() {
        val s = ok("""{"pumpAvailable":true,"flowLpm":2.0}""")
        assertEquals(PumpState.UNKNOWN, s.pump)
        assertTrue(s.warnings.any { it.contains("pump is missing") })
    }

    @Test
    fun missingPumpAvailableMeansUnknownPermission() {
        val s = ok("""{"pump":false,"flowLpm":2.0}""")
        assertEquals(FirmwarePumpPermission.UNKNOWN, s.pumpPermission)
    }

    @Test
    fun missingFlowStaysNullAndIsNotZero() {
        val s = ok("""{"pump":false,"pumpAvailable":false,"totalLiters":3.0}""")
        assertNull(s.flowLpm)
        assertEquals(3.0, s.totalLiters!!, 1e-9)
    }

    @Test
    fun wrongTypesAreIgnoredWithWarnings() {
        val s = ok("""{"pump":"on","pumpAvailable":"yes","flowLpm":"1.5","rssi":"strong","wifi":5,"totalLiters":1.0}""")
        assertEquals(PumpState.UNKNOWN, s.pump)
        assertEquals(FirmwarePumpPermission.UNKNOWN, s.pumpPermission)
        assertNull(s.flowLpm)
        assertNull(s.rssiDbm)
        assertNull(s.wifi)
        assertTrue(s.warnings.size >= 5)
    }

    @Test
    fun negativeFlowIsIgnored() {
        val s = ok("""{"pump":false,"pumpAvailable":true,"flowLpm":-3.0}""")
        assertNull(s.flowLpm)
        assertTrue(s.warnings.any { it.contains("flowLpm") })
    }

    @Test
    fun jsonNullIsTreatedAsMissing() {
        val s = ok("""{"pump":null,"pumpAvailable":true,"flowLpm":null}""")
        assertEquals(PumpState.UNKNOWN, s.pump)
        assertNull(s.flowLpm)
    }

    @Test
    fun rssiOutsideRangeIsIgnored() {
        assertNull(ok("""{"pump":false,"pumpAvailable":true,"rssi":12}""").rssiDbm)
        assertNull(ok("""{"pump":false,"pumpAvailable":true,"rssi":-300}""").rssiDbm)
        assertEquals(-70, ok("""{"pump":false,"pumpAvailable":true,"rssi":-70}""").rssiDbm)
    }

    @Test
    fun pumpOnWhileLockedIsContradictoryAndUnknown() {
        val s = ok("""{"pump":true,"pumpAvailable":false,"flowLpm":0.0}""")
        assertEquals(PumpState.UNKNOWN, s.pump)
        assertTrue(s.contradictoryPump)
        assertEquals(FirmwarePumpPermission.LOCKED, s.pumpPermission)
    }

    @Test
    fun pumpOnWhileEnabledIsOn() {
        val s = ok("""{"pump":true,"pumpAvailable":true,"flowLpm":4.0}""")
        assertEquals(PumpState.ON, s.pump)
        assertFalse(s.contradictoryPump)
    }

    @Test
    fun notJsonIsInvalid() {
        assertTrue(invalid("<html>router login</html>").isNotEmpty())
        assertTrue(invalid("").isNotEmpty())
    }

    @Test
    fun jsonArrayIsInvalid() {
        assertTrue(invalid("[1,2,3]").isNotEmpty())
    }

    @Test
    fun objectWithoutKnownFieldsIsInvalid() {
        assertTrue(invalid("""{"hello":"world"}""").contains("expected status fields"))
    }

    @Test
    fun unsupportedApiVersionIsInvalid() {
        assertTrue(invalid("""{"apiVersion":99,"pump":false}""").contains("API version 99"))
    }

    @Test
    fun supportedApiVersionIsAccepted() {
        assertEquals(1, ok("""{"apiVersion":1,"pump":false,"pumpAvailable":true}""").apiVersion)
    }
}
