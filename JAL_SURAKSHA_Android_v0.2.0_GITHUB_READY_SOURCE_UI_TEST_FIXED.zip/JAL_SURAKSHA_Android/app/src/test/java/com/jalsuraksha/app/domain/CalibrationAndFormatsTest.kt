package com.jalsuraksha.app.domain

import com.jalsuraksha.app.data.LinkState
import com.jalsuraksha.app.data.VolumeUnit
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Locale

class CalibrationAndFormatsTest {

    @Test
    fun calibrationFactorAndSuggestedPulsesPerLitre() {
        val r = Calibration.compute(reportedLiters = 1.0, measuredLiters = 1.1, firmwarePulsesPerLiter = 450.0)!!
        assertEquals(1.1, r.factor, 1e-9)
        assertEquals(450.0 / 1.1, r.suggestedPulsesPerLiter, 1e-9)
        assertTrue(r.plausible)
    }

    @Test
    fun deviceThatOverReportsGetsAHigherPulsesPerLitre() {
        val r = Calibration.compute(1.25, 1.0, 450.0)!!
        assertEquals(0.8, r.factor, 1e-9)
        assertEquals(562.5, r.suggestedPulsesPerLiter, 1e-9)
    }

    @Test
    fun invalidCalibrationInputsGiveNull() {
        assertNull(Calibration.compute(0.0, 1.0, 450.0))
        assertNull(Calibration.compute(1.0, 0.0, 450.0))
        assertNull(Calibration.compute(1.0, 1.0, 0.0))
        assertNull(Calibration.compute(Double.NaN, 1.0, 450.0))
        assertNull(Calibration.compute(1.0, Double.POSITIVE_INFINITY, 450.0))
    }

    @Test
    fun hugeCorrectionIsFlaggedImplausible() {
        assertFalse(Calibration.compute(1.0, 3.0, 450.0)!!.plausible)
        assertFalse(Calibration.compute(3.0, 1.0, 450.0)!!.plausible)
    }

    @Test
    fun missingValuesAreDashesNotZero() {
        assertEquals("--", Formats.flow(null, VolumeUnit.LITERS))
        assertEquals("--", Formats.volume(null, VolumeUnit.LITERS))
    }

    @Test
    fun unitConversion() {
        assertEquals("1.00", Formats.flow(3.785411784, VolumeUnit.US_GALLONS, Locale.US))
        assertEquals("2.50", Formats.flow(2.5, VolumeUnit.LITERS, Locale.US))
        assertEquals("12.500", Formats.volume(12.5, VolumeUnit.LITERS, Locale.US))
        assertEquals("1500.0", Formats.volume(1500.0, VolumeUnit.LITERS, Locale.US))
        assertEquals("L/min", Formats.flowUnit(VolumeUnit.LITERS))
        assertEquals("gal", Formats.volumeUnit(VolumeUnit.US_GALLONS))
    }

    @Test
    fun ageAndDurationWording() {
        assertEquals("just now", Formats.age(400))
        assertEquals("5 s ago", Formats.age(5_000))
        assertEquals("2 min ago", Formats.age(125_000))
        assertEquals("45 s", Formats.duration(45_000))
        assertEquals("12 min 05 s", Formats.duration(725_000))
        assertEquals("1 h 05 min", Formats.duration(3_900_000))
    }

    @Test
    fun signalQualityBuckets() {
        assertEquals("Unknown", Formats.signalQuality(null))
        assertEquals("Excellent", Formats.signalQuality(-55))
        assertEquals("Good", Formats.signalQuality(-65))
        assertEquals("Fair", Formats.signalQuality(-75))
        assertEquals("Weak", Formats.signalQuality(-85))
    }

    @Test
    fun everyLinkStateHasALabel() {
        for (l in LinkState.values()) {
            assertNotNull(Formats.linkLabel(l))
        }
    }
}
