package com.jalsuraksha.app.domain

import com.jalsuraksha.app.data.DeviceStatus
import com.jalsuraksha.app.data.FirmwarePumpPermission
import com.jalsuraksha.app.data.LinkState
import com.jalsuraksha.app.data.PumpState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PumpGatePolicyTest {

    private fun status(
        pump: PumpState = PumpState.OFF,
        permission: FirmwarePumpPermission = FirmwarePumpPermission.ENABLED,
    ) = DeviceStatus(
        wifi = null, ip = null, rssiDbm = null,
        pump = pump, pumpPermission = permission,
        flowLpm = 0.0, totalLiters = 0.0,
        deviceId = null, apiVersion = null, receivedAtMs = 0L,
    )

    private fun eval(
        link: LinkState = LinkState.ONLINE,
        status: DeviceStatus? = status(),
        inProgress: Boolean = false,
        enabled: Boolean = true,
    ) = PumpGatePolicy.evaluate(link, status, inProgress, enabled)

    @Test
    fun onIsAllowedOnlyWithEveryGateMet() {
        val g = eval()
        assertTrue(g.canRequestOn)
        assertEquals(null, g.onBlockedReason)
        assertTrue(g.checks.all { it.passed })
        assertEquals(4, g.checks.size)
    }

    @Test
    fun theAppSideSwitchBlocksBothOnAndOffByDefault() {
        val g = eval(status = status(pump = PumpState.ON), enabled = false)
        assertFalse(g.canRequestOn)
        assertFalse(g.canRequestOff)
        assertTrue(g.onBlockedReason!!.contains("switched off in this app"))
        assertTrue(g.offBlockedReason!!.contains("physical switch"))
        assertFalse(g.checks.first { it.label == "App" }.passed)
    }

    @Test
    fun lockedFirmwareBlocksOnAndExplainsWhy() {
        val g = eval(status = status(permission = FirmwarePumpPermission.LOCKED))
        assertFalse(g.canRequestOn)
        assertTrue(g.onBlockedReason!!.contains("locked by the firmware"))
    }

    @Test
    fun unknownPermissionBlocksOn() {
        assertFalse(eval(status = status(permission = FirmwarePumpPermission.UNKNOWN)).canRequestOn)
    }

    @Test
    fun staleOfflineOrMissingDataBlocksOn() {
        for (link in listOf(LinkState.STALE, LinkState.OFFLINE, LinkState.CONNECTING, LinkState.AUTH_REQUIRED, LinkState.UNSUPPORTED, LinkState.NOT_CONFIGURED)) {
            assertFalse("ON must be blocked for $link", eval(link = link).canRequestOn)
        }
        assertFalse(eval(status = null).canRequestOn)
    }

    @Test
    fun unknownPumpStateBlocksOnButStillAllowsOff() {
        val g = eval(status = status(pump = PumpState.UNKNOWN))
        assertFalse(g.canRequestOn)
        assertTrue(g.canRequestOff)
    }

    @Test
    fun alreadyOnBlocksOnAndAllowsOff() {
        val g = eval(status = status(pump = PumpState.ON))
        assertFalse(g.canRequestOn)
        assertTrue(g.canRequestOff)
    }

    @Test
    fun alreadyOffBlocksOff() {
        val g = eval(status = status(pump = PumpState.OFF))
        assertFalse(g.canRequestOff)
        assertNotNull(g.offBlockedReason)
    }

    @Test
    fun offIsAvailableEvenWhenFirmwareReportsLockedAndPumpUnknown() {
        val g = eval(status = status(pump = PumpState.UNKNOWN, permission = FirmwarePumpPermission.LOCKED))
        assertTrue(g.canRequestOff)
    }

    @Test
    fun noRequestsWhileACommandIsInProgress() {
        val g = eval(status = status(pump = PumpState.ON), inProgress = true)
        assertFalse(g.canRequestOn)
        assertFalse(g.canRequestOff)
    }

    @Test
    fun offIsBlockedWhenTheDeviceCannotBeReached() {
        val g = eval(link = LinkState.OFFLINE, status = status(pump = PumpState.ON))
        assertFalse(g.canRequestOff)
        assertTrue(g.offBlockedReason!!.contains("physical switch"))
    }
}
