package com.jalsuraksha.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class EndpointValidatorTest {

    private fun valid(input: String): EndpointValidator.Result.Valid {
        val r = EndpointValidator.parse(input)
        assertTrue("expected Valid for '$input' but was $r", r is EndpointValidator.Result.Valid)
        return r as EndpointValidator.Result.Valid
    }

    private fun invalid(input: String) {
        val r = EndpointValidator.parse(input)
        assertTrue("expected Invalid for '$input' but was $r", r is EndpointValidator.Result.Invalid)
    }

    @Test
    fun acceptsPrivateIpv4() {
        assertEquals("192.168.1.50", valid("192.168.1.50").host)
        assertEquals(80, valid("192.168.1.50").port)
        assertEquals("10.0.0.7", valid("10.0.0.7").host)
        assertEquals("172.16.5.9", valid("172.16.5.9").host)
        assertEquals("169.254.4.4", valid("169.254.4.4").host)
    }

    @Test
    fun acceptsPortAndHttpSchemeAndTrailingSlash() {
        val v = valid(" http://192.168.43.100:8080/ ")
        assertEquals("192.168.43.100", v.host)
        assertEquals(8080, v.port)
    }

    @Test
    fun acceptsLocalNames() {
        assertEquals("jal-suraksha.local", valid("JAL-SURAKSHA.local").host)
    }

    @Test
    fun rejectsPublicAddresses() {
        invalid("8.8.8.8")
        invalid("172.32.0.1")
        invalid("172.15.0.1")
        invalid("192.169.1.1")
        invalid("example.com")
        invalid("localhost")
        invalid("127.0.0.1")
    }

    @Test
    fun rejectsMalformedInput() {
        invalid("")
        invalid("   ")
        invalid("192.168.1.300")
        invalid("192.168.1")
        invalid("192.168.001.5")
        invalid("192.168.1.5:0")
        invalid("192.168.1.5:99999")
        invalid("192.168.1.5:abc")
        invalid("[fe80::1]")
    }

    @Test
    fun rejectsHttpsCredentialsAndPaths() {
        invalid("https://192.168.1.5")
        invalid("admin:secret@192.168.1.5")
        invalid("http://192.168.1.5/api/status")
        invalid("192.168.1.5?x=1")
    }

    @Test
    fun hostPolicyMatchesParser() {
        assertTrue(EndpointValidator.isAllowedHost("192.168.0.2"))
        assertTrue(EndpointValidator.isAllowedHost("esp32.local"))
        assertFalse(EndpointValidator.isAllowedHost("1.1.1.1"))
        assertFalse(EndpointValidator.isAllowedHost("evil.example.com"))
    }

    @Test
    fun pathValidation() {
        assertTrue(EndpointValidator.isValidPath("/api/status"))
        assertFalse(EndpointValidator.isValidPath("api/status"))
        assertFalse(EndpointValidator.isValidPath("/a b"))
        assertFalse(EndpointValidator.isValidPath("/x?y=1"))
        assertFalse(EndpointValidator.isValidPath("/"))
    }

    @Test
    fun baseUrlOmitsDefaultPort() {
        assertEquals("http://192.168.1.5", EndpointValidator.baseUrl("192.168.1.5", 80))
        assertEquals("http://192.168.1.5:8080", EndpointValidator.baseUrl("192.168.1.5", 8080))
    }
}
