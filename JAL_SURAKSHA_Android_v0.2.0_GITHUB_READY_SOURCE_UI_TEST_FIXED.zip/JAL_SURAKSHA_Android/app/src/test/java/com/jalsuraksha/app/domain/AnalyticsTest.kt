package com.jalsuraksha.app.domain

import com.jalsuraksha.app.data.PumpState
import com.jalsuraksha.app.data.Sample
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.TimeZone

class AnalyticsTest {

    private val hour = 3_600_000L

    private fun s(t: Long, flow: Double?, total: Double?, pump: PumpState = PumpState.OFF) =
        Sample(t, flow, total, pump, -50)

    @Test
    fun volumeIsCountedOnlyAcrossSmallGaps() {
        val samples = listOf(
            s(0, 1.0, 10.0),
            s(10_000, 1.0, 11.0),
            s(20_000, 1.0, 12.0),
            s(500_000, 1.0, 50.0),
            s(510_000, 1.0, 51.0),
        )
        val st = Analytics.stats(samples, 30_000L)
        assertEquals(3.0, st.volumeLiters, 1e-9)
        assertEquals(30_000L, st.observedMs)
        assertEquals(5, st.sampleCount)
    }

    @Test
    fun aCounterGoingBackwardsIsAResetNotNegativeUsage() {
        val samples = listOf(s(0, 1.0, 100.0), s(10_000, 1.0, 5.0), s(20_000, 1.0, 6.0))
        val st = Analytics.stats(samples, 30_000L)
        assertEquals(1, st.counterResets)
        assertEquals(1.0, st.volumeLiters, 1e-9)
    }

    @Test
    fun pumpOnTimeNeedsBothEndsOn() {
        val samples = listOf(
            s(0, 1.0, 0.0, PumpState.OFF),
            s(10_000, 1.0, 0.0, PumpState.ON),
            s(20_000, 1.0, 0.0, PumpState.ON),
            s(30_000, 1.0, 0.0, PumpState.OFF),
        )
        assertEquals(10_000L, Analytics.stats(samples, 30_000L).pumpOnMs)
    }

    @Test
    fun peakAndAverageIgnoreMissingFlow() {
        val samples = listOf(s(0, 2.0, null), s(1_000, null, null), s(2_000, 4.0, null))
        val st = Analytics.stats(samples, 30_000L)
        assertEquals(4.0, st.peakFlowLpm!!, 1e-9)
        assertEquals(3.0, st.avgFlowLpm!!, 1e-9)
    }

    @Test
    fun emptyInputGivesNullsNotZeros() {
        val st = Analytics.stats(emptyList(), 30_000L)
        assertNull(st.peakFlowLpm)
        assertNull(st.avgFlowLpm)
        assertEquals(0, st.sampleCount)
    }

    @Test
    fun slotsWithoutObservationsAreNullNotZero() {
        val tz = TimeZone.getTimeZone("UTC")
        val samples = listOf(
            s(hour + 1_000, 1.0, 10.0),
            s(hour + 11_000, 1.0, 10.5),
            s(hour + 21_000, 1.0, 11.0),
        )
        val slots = Analytics.usageSlots(samples, BucketSize.HOUR, tz, 30_000L, 0L, 3 * hour)
        assertEquals(4, slots.size)
        assertNull(slots[0].liters)
        assertEquals(1.0, slots[1].liters!!, 1e-9)
        assertNull(slots[2].liters)
        assertNull(slots[3].liters)
    }

    @Test
    fun bucketStartsAlignToTheHourAndDay() {
        val tz = TimeZone.getTimeZone("UTC")
        assertEquals(hour, Analytics.bucketStart(hour + 123_456L, BucketSize.HOUR, tz))
        assertEquals(0L, Analytics.bucketStart(5 * hour + 99L, BucketSize.DAY, tz))
        assertEquals(listOf(0L, 24 * hour, 48 * hour), Analytics.bucketStarts(0L, 48 * hour, BucketSize.DAY, tz))
    }

    @Test
    fun flowSeriesLeavesGapsAsGapsAndReportsTheJoinLimit() {
        val samples = listOf(s(5_000, 2.0, null), s(95_000, 4.0, null))
        val series = Analytics.flowSeries(samples, 0L, 120_000L, 12)
        assertEquals(2, series.points.size)
        assertEquals(15_000L, series.maxGapMs)
        assertTrue(series.points[1].tMs - series.points[0].tMs > series.maxGapMs)
        assertEquals(2.0, series.points[0].value, 1e-9)
    }

    @Test
    fun flowSeriesAveragesSamplesInTheSameBucket() {
        val samples = listOf(s(1_000, 2.0, null), s(2_000, 4.0, null))
        val series = Analytics.flowSeries(samples, 0L, 120_000L, 12)
        assertEquals(1, series.points.size)
        assertEquals(3.0, series.points[0].value, 1e-9)
    }

    @Test
    fun onStreakIsClaimedOnlyWhenTheStartWasObserved() {
        val observed = listOf(
            s(0, 0.0, 0.0, PumpState.OFF),
            s(10_000, 1.0, 0.0, PumpState.ON),
            s(20_000, 1.0, 0.0, PumpState.ON),
        )
        assertEquals(10_000L, Analytics.observedOnStreakStartMs(observed, 30_000L))

        val notObserved = listOf(s(0, 1.0, 0.0, PumpState.ON), s(10_000, 1.0, 0.0, PumpState.ON))
        assertNull(Analytics.observedOnStreakStartMs(notObserved, 30_000L))

        val off = listOf(s(0, 0.0, 0.0, PumpState.ON), s(10_000, 0.0, 0.0, PumpState.OFF))
        assertNull(Analytics.observedOnStreakStartMs(off, 30_000L))
        assertNotNull(Analytics.observedOnStreakStartMs(observed, 30_000L))
    }
}
