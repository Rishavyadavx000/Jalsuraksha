# No custom rules yet. R8 is disabled for release builds in app/build.gradle.kts.
# When enabling it, keep okhttp3 consumer rules (shipped with the library) and re-test on a device.
