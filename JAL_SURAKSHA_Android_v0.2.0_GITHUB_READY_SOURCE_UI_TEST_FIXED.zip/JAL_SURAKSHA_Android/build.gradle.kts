// Version matrix carried over from the starter project (AGP 8.7.3 / Kotlin 2.0.21 / Compose BOM 2024.12.01).
// It is a coherent set on paper but has NOT been verified by a build in this delivery - see docs/TEST_REPORT.md.
plugins {
    id("com.android.application") version "8.7.3" apply false
    id("org.jetbrains.kotlin.android") version "2.0.21" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.0.21" apply false
}
